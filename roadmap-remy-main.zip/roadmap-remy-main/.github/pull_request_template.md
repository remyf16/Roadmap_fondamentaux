## Summary

<!-- 1-3 phrases décrivant le but de cette PR -->

## Changes

<!-- Liste détaillée des changements par zone -->

## Test plan

- [ ] Build passes (`npm run build`)
- [ ] Lint passes (`npm run lint`)
- [ ] Tests manuels effectués

## Release notes

<!-- Une ligne pour le changelog, ou "N/A" pour les changements internes -->

## Checklist

- [ ] Le code suit les conventions du projet
- [ ] Les commits suivent le format conventionnel
- [ ] Pas de `console.log` ou code de debug restant
- [ ] Les types TypeScript sont corrects (pas de `any`)
