---
description: Git Flow complet - branches, merges, commits, releases, tags, PRs
globs:
  - "**/*"
---

# Git Flow

## Branches principales

| Branche | Rôle | Protection |
|---------|------|------------|
| `main` | Production stable, toujours déployable | Pas de commit direct, uniquement via merge de `release/*` ou `hotfix/*` |
| `develop` | Intégration, prochaine release | Pas de commit direct, uniquement via merge de branches typées |

## Branches de travail

Toutes les branches de travail partent de `develop` (sauf hotfix).

Convention : `type/description-en-kebab-case`

| Préfixe | Base | Merge vers | Usage | Exemple |
|---------|------|------------|-------|---------|
| `feat/` | `develop` | `develop` | Nouvelle fonctionnalité | `feat/kanban-drag-drop` |
| `fix/` | `develop` | `develop` | Correction de bug | `fix/timeline-scroll` |
| `refactor/` | `develop` | `develop` | Refactoring | `refactor/store-slices` |
| `style/` | `develop` | `develop` | UI/CSS uniquement | `style/dark-mode-colors` |
| `perf/` | `develop` | `develop` | Optimisation perf | `perf/reduce-rerenders` |
| `test/` | `develop` | `develop` | Ajout de tests | `test/store-unit-tests` |
| `docs/` | `develop` | `develop` | Documentation | `docs/api-guide` |
| `chore/` | `develop` | `develop` | Maintenance/deps | `chore/update-deps` |
| `ci/` | `develop` | `develop` | CI/CD | `ci/github-actions` |

## Branches spéciales

| Préfixe | Base | Merge vers | Usage | Exemple |
|---------|------|------------|-------|---------|
| `release/` | `develop` | `main` + `develop` | Préparer une release | `release/v1.2.0` |
| `hotfix/` | `main` (ou dernier tag) | `main` + `develop` | Fix urgent en prod | `hotfix/crash-on-load` |

## Règles de nommage

- Toujours en kebab-case, tout en minuscules
- Descriptif et spécifique (pas `fix/bug` ou `feat/update`)
- Max 50 caractères après le préfixe
- Pas de caractères spéciaux (accents, espaces)

## Workflow des merges

### Feature / Fix / Chore (travail courant)
```
develop ──────────────────────── develop
   \                              /
    feat/ma-feature ─── commits ─ PR merge
```

### Release
```
develop ──────────────────────── develop (merge back)
   \                              /
    release/v1.2.0 ── bump ──── /
                          \
main ──────────────────── main (merge + tag v1.2.0)
```

### Hotfix
```
main ─────────────────────────── main (merge + tag v1.2.1)
   \                              /
    hotfix/crash-fix ── fix ─── /
                          \
develop ──────────────────────── develop (merge back)
```

## Commits

Format : `type(scope): description`

- **Types** : feat, fix, docs, style, refactor, perf, test, chore, ci, build, revert
- **Scopes** : ui, components, flow, dnd, store, config, deps, styles
- Sujet en minuscules, mode impératif, max 72 caractères
- Un `feat` = bump **minor**, un `fix` = bump **patch**
- Pour un bump **major** : ajouter `BREAKING CHANGE:` dans le body ou `!` après le type

## Releases

Workflow via `commit-and-tag-version` :

1. Créer branche `release/vX.Y.Z` depuis `develop`
2. `npm run release:dry` pour preview
3. `npm run release` pour bump + CHANGELOG + tag
4. Merger dans `main` via PR
5. Merger `main` back dans `develop`
6. `git push --follow-tags origin main`

## Tags

- Format : `vMAJOR.MINOR.PATCH` (ex: `v1.2.3`)
- Créés automatiquement par le process de release
- Ne jamais créer de tags manuellement

## Pull Requests

- Titre court (< 70 caractères), descriptif
- **Branches de travail** -> PR vers `develop`
- **release/** -> PR vers `main`
- **hotfix/** -> PR vers `main` (+ seconde PR vers `develop`)
- Labels automatiques :
  - `feat/*` -> `enhancement`
  - `fix/*`, `hotfix/*` -> `bug`
  - `docs/*` -> `documentation`
  - `refactor/*` -> `refactoring`
  - `chore/*` -> `maintenance`
  - `perf/*` -> `performance`
  - `release/*` -> `release`
