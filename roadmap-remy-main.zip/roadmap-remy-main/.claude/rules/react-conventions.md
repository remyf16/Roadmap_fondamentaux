---
paths: "src/**/*.tsx"
---

# React Conventions

- Utiliser des composants fonctionnels uniquement
- State management via Zustand (pas de Context pour le state global)
- Utiliser les hooks React 19 (use, useActionState, useOptimistic)
- Composants dans des fichiers séparés, un composant par fichier
- Props typées avec des interfaces TypeScript (pas de `any`)
- Préférer `clsx` pour la composition de classes Tailwind
