---
paths: "src/**/*.ts"
---

# TypeScript Conventions

- Strict mode activé
- Pas de `any` - utiliser `unknown` avec type guards
- Types explicites pour les fonctions publiques
- Imports groupés : external > internal > types
