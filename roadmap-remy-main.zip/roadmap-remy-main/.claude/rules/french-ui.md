# Français dans l'UI

## Règles typographiques

Tout texte visible par l'utilisateur DOIT respecter les règles du français.

### Accents

Toujours mettre les accents, y compris sur les majuscules :

- « À propos » et non « A propos »
- « État » et non « Etat »
- « Éléments » et non « Elements »
- « Été » et non « Ete »

### Casse (Sentence case)

Le français utilise le **sentence case** (seul le premier mot en majuscule), contrairement à l'anglais qui utilise le Title Case :

- « Nouvelle tâche » et non « Nouvelle Tâche »
- « En cours » et non « En Cours »
- « Paramètres du projet » et non « Paramètres Du Projet »
- Exception : noms propres, sigles (API, CI/CD)

### Ponctuation française

- Espace insécable avant `:` `!` `?` `;` → utiliser `\u00A0` ou `&nbsp;` en JSX
- Guillemets français « » pour les citations (pas "")
- Points de suspension : `…` (caractère unique) et non `...`

### Vocabulaire cohérent

Utiliser ces traductions de manière cohérente dans toute l'app :

| Anglais     | Français                    |
| ----------- | --------------------------- |
| Backlog     | Backlog (pas de traduction) |
| To do       | À faire                     |
| In progress | En cours                    |
| Review      | En revue                    |
| Done        | Terminé                     |
| Task        | Tâche                       |
| Sprint      | Sprint (pas de traduction)  |
| Team        | Équipe                      |
| Milestone   | Jalon                       |
| Dependency  | Dépendance                  |
| Timeline    | Chronologie                 |
| Settings    | Paramètres                  |
| Search      | Rechercher                  |
| Filter      | Filtrer                     |
| Delete      | Supprimer                   |
| Edit        | Modifier                    |
| Save        | Enregistrer                 |
| Cancel      | Annuler                     |

### Textes UI

- Labels de boutons : verbe à l'infinitif (« Créer », « Modifier », « Supprimer »)
- Placeholders : verbe à l'infinitif (« Rechercher… », « Saisir un titre… »)
- Messages de confirmation : phrase complète (« Voulez-vous supprimer cette tâche ? »)
- Messages de succès : passé composé (« Tâche créée avec succès »)
- Messages d'erreur : phrase claire (« Impossible de sauvegarder : le titre est requis »)

### Pas d'i18n pour l'instant

Les textes sont hardcodés en français dans les composants. Si l'internationalisation devient nécessaire, migrer vers `react-i18next` à ce moment-là.
