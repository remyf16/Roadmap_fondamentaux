---
description: Workflow Git entièrement automatique - Claude gère branches, commits, push et PR sans intervention
globs:
  - "**/*"
---

# Git Automatique

Tu gères le workflow Git de manière **complètement autonome**. L'utilisateur ne devrait jamais avoir à te dire de commit, push ou créer une PR.

## Changement de contexte (mid-conversation)

A chaque nouvelle demande de l'utilisateur, **évalue si c'est le même sujet** que la branche courante :

1. **Vérifie** la branche courante :
   ```bash
   git branch --show-current
   git status --short
   ```

2. **Décision** :

   | Branche courante | Nouvelle demande liée ? | Action |
   |-----------------|------------------------|--------|
   | `develop` / `main` | — | Créer une nouvelle branche (section "Avant de coder") |
   | `feat/dark-mode` | Oui (même feature) | Continuer sur la branche |
   | `feat/dark-mode` | Non (autre sujet) | **Finaliser** → switcher → nouvelle branche |

3. **Finaliser la branche en cours** (si changement de sujet) :
   - S'il y a des changements non committés → commit
   - Si la branche n'a pas de PR → push + créer la PR
   - Si la branche a déjà une PR → push les éventuels derniers commits
   - Puis : `git checkout develop && git pull origin develop 2>/dev/null || true`
   - Créer la nouvelle branche normalement

4. **Indices qu'un sujet est différent** :
   - L'utilisateur parle d'un composant/feature sans rapport avec le nom de branche
   - L'utilisateur dit explicitement "autre chose", "sinon", "au fait"
   - Le type de travail change (ex: branche `feat/` mais demande de fix)

5. **En cas de doute** : demander à l'utilisateur "Je suis sur `feat/dark-mode`, c'est lié ou c'est un nouveau sujet ?"

## Reprise de branche existante

Si au début d'une session (ou après un switch) tu es sur `develop` et l'utilisateur demande de continuer un travail :

1. Vérifier s'il y a des branches de travail avec des PR ouvertes :
   ```bash
   gh pr list --author=@me --state=open
   ```
2. Si une PR correspond au sujet → checkout la branche et continuer
3. Si aucune PR ne correspond → créer une nouvelle branche

## Avant de coder

Quand l'utilisateur te donne une tâche (feature, fix, refactor, etc.) et qu'il n'y a pas de branche en cours liée :

1. **Crée une branche** depuis `develop` avec la bonne convention :

   ```bash
   git checkout develop
   git pull origin develop 2>/dev/null || true
   git checkout -b <type>/<nom-descriptif>
   ```

   - `feat/` pour les features
   - `fix/` pour les bugs
   - `refactor/` pour le refactoring
   - `chore/` pour la maintenance
   - `docs/` pour la documentation
   - `style/` pour le CSS/UI
   - `perf/` pour les optimisations
   - `test/` pour les tests

2. Ne demande PAS confirmation pour créer la branche. Fais-le directement.

3. Si `develop` n'existe pas encore, crée-la depuis `main` :
   ```bash
   git checkout main
   git checkout -b develop
   git push -u origin develop
   ```

## Pendant le travail

- **Commit régulièrement** après chaque changement logique cohérent (pas un seul gros commit à la fin)
- Format : `type(scope): description` (conventional commits)
- Stage les fichiers spécifiques, jamais `git add -A`
- Ajoute `Co-Authored-By: Claude <noreply@anthropic.com>` dans le body
- Ne committe jamais `.env*`, `*.secret`, `node_modules/`

## Après avoir terminé

Quand la tâche est terminée :

1. **Vérifie** que tout est propre :

   ```bash
   npm run lint
   npm run build
   ```

2. **Commit** les derniers changements s'il en reste

3. **Push** la branche :

   ```bash
   git push -u origin HEAD
   ```

4. **Crée la PR** automatiquement vers la bonne base :
   - Branches de travail (`feat/`, `fix/`, `refactor/`, `chore/`, etc.) -> PR vers **`develop`**
   - `release/*` -> PR vers **`main`**
   - `hotfix/*` -> PR vers **`main`** (+ mentionner qu'il faudra merge back dans `develop`)

   ```bash
   gh pr create --base develop --title "<titre>" --body "<body structuré>"
   ```

   - Labels auto selon le type de branche
   - Body avec Summary, Changes, Test plan

5. **Affiche le résultat** : URL de la PR, branche, résumé

## Exceptions - Demande confirmation UNIQUEMENT pour :

- `git push --force` (interdit de toute façon)
- `git reset --hard`
- Supprimer une branche distante
- Merge dans `main` (uniquement via release ou hotfix)

## Ne PAS faire automatiquement :

- Merger la PR (l'utilisateur review et merge lui-même)
- Créer un release/tag (utiliser `/release` explicitement)
- Committer directement sur `main` ou `develop` (toujours via branche + PR)
