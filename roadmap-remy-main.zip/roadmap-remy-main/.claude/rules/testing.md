# Testing

## Regle d'or

Tout code produit DOIT etre teste. Pas de merge sans tests.

## Strategie en 2 phases

### Phase 1 : Tester la nouveaute

Apres chaque modification ou creation de fichier, lancer les tests specifiques :

```bash
npx vitest run src/path/to/file.test.ts
```

- Si le test n'existe pas encore, le creer AVANT de considerer la tache terminee
- Un fichier `foo.ts` doit avoir un `foo.test.ts` au meme niveau
- Un composant `Bar.tsx` doit avoir un `Bar.test.tsx` au meme niveau

### Phase 2 : Lancer la suite complete

Une fois les tests specifiques verts, lancer la suite entiere :

```bash
npm run test:run
```

Si un test existant casse → corriger AVANT de continuer.

## Quoi tester

| Type de code   | Ce qu'on teste                         | Exemple                    |
| -------------- | -------------------------------------- | -------------------------- |
| Store slice    | Actions, reducers, state transitions   | `taskSlice.test.ts`        |
| Hook custom    | Comportement, valeurs retournees       | `useFilteredTasks.test.ts` |
| Utilitaire/lib | Inputs/outputs, edge cases             | `storage.test.ts`          |
| Composant UI   | Rendu, interactions utilisateur, props | `TaskCard.test.tsx`        |

## Conventions

- Framework : **Vitest** + `@testing-library/react` + `@testing-library/user-event`
- Fichiers : `*.test.ts` ou `*.test.tsx` au meme niveau que le fichier teste
- Pattern : `describe` > `it` avec descriptions claires en anglais
- Pas de snapshots sauf justification
- Pas de mocks excessifs : tester le comportement reel quand possible
- Pour les stores Zustand : creer un store isole par test avec `create()`

## Ne JAMAIS

- Marquer une tache done sans tests
- Committer du code sans que `npm run test:run` passe
- Ignorer un test qui casse (`skip`, `todo`) sans justification documentee
