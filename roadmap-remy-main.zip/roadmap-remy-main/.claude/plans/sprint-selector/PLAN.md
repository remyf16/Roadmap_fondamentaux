# Plan : Sélecteur de sprint amélioré

## Overview

- **Feature** : [sprint-selector.md](../../.claude/features/sprint-selector.md)
- **Tâches** : 5 tâches
- **Status** : planning

## Task List

### Types & Interfaces

#### TASK-001 : Rendre sprintId optionnel sur Task

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/types/models.ts`
  - Modify : `src/hooks/useFilteredTasks.ts` (guard TS pour build)
- **Acceptance** :
  - [x] `Task.sprintId` est de type `ID | undefined` (optionnel `sprintId?: ID`)
  - [x] Le build passe sans erreur TypeScript
  - [x] Les données seed existantes restent valides (elles ont toutes un sprintId)
- **Depends** : none
- **Done** : 2026-02-12T14:12:00Z
- **Notes** : `Milestone.sprintId` reste requis (hors scope). Un guard minimal ajouté dans `useFilteredTasks.ts` pour que le build passe (`!task.sprintId ||` avant l'include check). Ce guard sera affiné dans TASK-003.

---

### Store

#### TASK-002 : Ajouter les actions CRUD au sprintSlice

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/store/slices/sprintSlice.ts`
  - Create : `src/store/slices/sprintSlice.test.ts`
- **Acceptance** :
  - [x] `addSprint` crée un sprint avec un ID généré et le retourne
  - [x] `updateSprint` met à jour un sprint par ID
  - [x] `deleteSprint` supprime un sprint par ID
  - [x] Tests unitaires couvrent les 3 nouvelles actions + `setSprints`
- **Depends** : none
- **Done** : 2026-02-12T14:15:00Z
- **Notes** : Pattern `topicSlice.ts` suivi. `addSprint(Omit<Sprint, "id">)` avec `crypto.randomUUID()`. 7 tests (init, set, add, update, update isolation, delete, delete non-existent).

---

### Guards & Adaptations

#### TASK-003 : Adapter le code existant au sprintId optionnel

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/hooks/useFilteredTasks.ts` (guard déjà ajouté en TASK-001)
  - Modify : `src/components/layout/Header.tsx`
- **Acceptance** :
  - [x] `useFilteredTasks` gère `task.sprintId` undefined (tâche sans sprint exclue si filtre sprint actif)
  - [x] `Header.handleAddTask` ne force plus un `sprintId` — laisse `undefined` si aucun sprint n'existe
  - [x] Les tests existants passent toujours
  - [x] Build et lint passent
- **Depends** : TASK-001
- **Done** : 2026-02-12T14:17:00Z
- **Notes** : Guard `useFilteredTasks` déjà en place depuis TASK-001. Header : `sprints[0]?.id ?? ""` → `sprints[0]?.id` (undefined si pas de sprint).

---

### Components

#### TASK-004 : Créer le composant SprintSelector

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Create : `src/components/tasks/SprintSelector.tsx`
- **Acceptance** :
  - [x] Affiche le sprint sélectionné ou « Aucun sprint » si pas de sprint
  - [x] Dropdown avec cases à cocher : « Aucun sprint » + liste des sprints
  - [x] Champ de recherche pour filtrer les sprints par nom
  - [x] Option « Créer » visible quand aucun sprint ne correspond à la recherche
  - [x] Formulaire de création inline : nom, numéro, plage de semaines, dates début/fin
  - [x] Click outside ferme le dropdown
  - [x] Le nouveau sprint est automatiquement sélectionné après création
- **Depends** : TASK-002
- **Done** : 2026-02-12T14:19:00Z
- **Notes** : Pattern TopicSelector adapté en sélection unique. Bouton trigger affiche sprint courant ou « Aucun sprint ». Check icon (lucide) pour l'élément sélectionné. Formulaire de création avec 5 champs (name, number, weekRange, startDate, endDate). Click-outside inline les setters directement dans le useEffect pour éviter le lint error react-hooks/immutability.

---

### Integration

#### TASK-005 : Intégrer SprintSelector dans TaskDetailPanel

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/components/tasks/TaskDetailPanel.tsx`
- **Acceptance** :
  - [x] Le `<select>` sprint est remplacé par `<SprintSelector>`
  - [x] Le composant reçoit le `taskId` en prop
  - [x] Sélectionner « Aucun sprint » met `sprintId` à `undefined` sur la tâche
  - [x] Sélectionner un sprint met à jour `sprintId` normalement
  - [x] Build et lint passent
- **Depends** : TASK-003, TASK-004
- **Done** : 2026-02-12T14:21:00Z
- **Notes** : Ancien `<select>` remplacé par `<SprintSelector taskId={task.id} />`. Import `sprints` retiré du composant (plus nécessaire, géré par SprintSelector).

---

## Dependency Graph

```
TASK-001 (types: sprintId optionnel)
   │
   ▼
TASK-003 (guards: useFilteredTasks, Header)
   │
   │    TASK-002 (store: CRUD sprintSlice)
   │       │
   │       ▼
   │    TASK-004 (component: SprintSelector)
   │       │
   ▼       ▼
TASK-005 (integration: TaskDetailPanel)
```

## Summary

| Groupe      | Tâches       | Status       |
| ----------- | ------------ | ------------ |
| Types       | 1 (TASK-001) | 1/1 done     |
| Store       | 1 (TASK-002) | 1/1 done     |
| Guards      | 1 (TASK-003) | 1/1 done     |
| Components  | 1 (TASK-004) | 1/1 done     |
| Integration | 1 (TASK-005) | 1/1 done     |
| **Total**   | **5**        | **5/5 done** |
