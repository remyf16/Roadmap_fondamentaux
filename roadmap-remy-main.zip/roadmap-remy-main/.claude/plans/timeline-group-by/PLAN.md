# Plan : Agrégat d'affichage timeline

## Overview

- **Feature** : [Spec](../../features/timeline-group-by.md)
- **Tâches** : 5 tâches
- **Status** : done

## Task List

### Types & Store

#### TASK-001 : Ajouter le type GroupByType et l'état groupBy dans le store

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/types/models.ts`
  - Modify : `src/store/slices/uiSlice.ts`
  - Modify : `src/store/slices/uiSlice.test.ts`
- **Acceptance** :
  - [x] Le type `GroupByType = "none" | "topic" | "role" | "month"` est exporté depuis `models.ts`
  - [x] Le `UiSlice` contient `groupBy: GroupByType` initialisé à `"none"`
  - [x] Le `UiSlice` contient `setGroupBy: (groupBy: GroupByType) => void`
  - [x] Les tests unitaires couvrent `groupBy` / `setGroupBy` / `resetFilters` (qui remet groupBy à `"none"`)
- **Depends** : none
- **Done** : 2025-02-13T08:44:00Z
- **Notes** : `resetFilters` remet aussi `groupBy` à `"none"`. 3 nouveaux tests ajoutés (9 tests uiSlice au total).

---

### Hooks

#### TASK-002 : Créer le hook useGroupedTasks

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Create : `src/hooks/useGroupedTasks.ts`
  - Create : `src/hooks/useGroupedTasks.test.ts`
- **Acceptance** :
  - [x] Le hook exporte `useGroupedTasks(tasks: Task[], groupBy: GroupByType)` retournant `TaskGroup[]`
  - [x] `TaskGroup` = `{ key: string, label: string, color?: string, tasks: Task[] }`
  - [x] Regroupement par thème : groupes triés alphabétiquement, « Sans thème » en dernier
  - [x] Regroupement par métier : groupes triés par ordre du type `Role`, labels français via `ROLE_LABELS`, « Sans métier » en dernier
  - [x] Regroupement par mois : groupes triés chronologiquement, format « Janvier 2025 »
  - [x] Mode `"none"` : retourne un seul groupe contenant toutes les tâches
  - [x] Tests unitaires pour chaque mode de regroupement + cas edge (tâches sans topic/role)
- **Depends** : TASK-001
- **Done** : 2025-02-13T08:47:00Z
- **Notes** : Signature ajustée avec 3e param `topics: Topic[]` pour le mode topic. 11 tests couvrant tous les modes + edge cases. `ROLE_LABELS` et `TaskGroup` exportés.

---

### Components

#### TASK-003 : Créer le composant GroupBySelector

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Create : `src/components/views/TimelineView/GroupBySelector.tsx`
- **Acceptance** :
  - [x] Toggle group avec 4 boutons : Aucun / Par thème / Par métier / Par mois
  - [x] L'option active est mise en surbrillance (style cohérent avec le sélecteur de vue du Header)
  - [x] Appelle `setGroupBy` du store au clic
  - [x] Texte en français, sentence case
- **Depends** : TASK-001
- **Done** : 2025-02-13T08:49:00Z
- **Notes** : Utilise icône Layers de lucide-react + label « Regrouper par ». Pattern toggle group repris du Header avec clsx.

---

#### TASK-004 : Créer le composant TimelineGroupHeader

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Create : `src/components/views/TimelineView/TimelineGroupHeader.tsx`
- **Acceptance** :
  - [x] Affiche le nom du groupe, le nombre de tâches entre parenthèses, et un indicateur coloré (pastille)
  - [x] Pleine largeur, style distinct des rangées de tâches (fond légèrement coloré)
  - [x] Props : `label: string`, `count: number`, `color?: string`, `width: number`
  - [x] Responsive à la largeur totale de la timeline
- **Depends** : none
- **Done** : 2025-02-13T08:51:00Z
- **Notes** : Exporte `GROUP_HEADER_HEIGHT = 32` pour le calcul des positions Y dans TimelineView. Pastille sticky left pour rester visible au scroll horizontal.

---

### Intégration

#### TASK-005 : Intégrer le groupement dans TimelineView

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/components/views/TimelineView/TimelineView.tsx`
- **Acceptance** :
  - [x] Le `GroupBySelector` est affiché au-dessus de la timeline (entre le header sticky et les tâches)
  - [x] Quand `groupBy !== "none"`, les tâches sont regroupées via `useGroupedTasks`
  - [x] Un `TimelineGroupHeader` est affiché avant chaque groupe de tâches
  - [x] Le calcul des positions Y tient compte des headers de groupe (offset additionnel)
  - [x] Les sprint bands et milestones s'adaptent à la nouvelle hauteur totale
  - [x] Le mode `"none"` affiche la timeline exactement comme avant (pas de régression)
- **Depends** : TASK-002, TASK-003, TASK-004
- **Done** : 2025-02-13T08:55:00Z
- **Notes** : Approche flat list avec calcul Y incrémental. `totalContentHeight` remplace `topLevelTasks.length * ROW_HEIGHT` pour sprint bands et milestones. GroupBySelector placé hors du scroll container pour rester toujours visible.

---

## Dependency Graph

```
TASK-001 (types + store)
   ├──→ TASK-002 (hook useGroupedTasks)
   │         └──→ TASK-005 (intégration TimelineView)
   └──→ TASK-003 (GroupBySelector)
              └──→ TASK-005

TASK-004 (TimelineGroupHeader) ──→ TASK-005
```

## Summary

| Groupe      | Tâches   | Status     |
| ----------- | -------- | ---------- |
| Types+Store | 1        | 1/1 done   |
| Hooks       | 1        | 1/1 done   |
| Components  | 2        | 2/2 done   |
| Intégration | 1        | 1/1 done   |
| **Total**   | **5**    | **5/5 done** |
