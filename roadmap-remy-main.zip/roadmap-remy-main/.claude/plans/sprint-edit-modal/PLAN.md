# Plan : Modale d'édition de sprint

## Overview

- **Feature** : [sprint-edit-modal.md](../../.claude/features/sprint-edit-modal.md)
- **Tâches** : 2 tâches
- **Status** : planning

## Task List

### Components

#### TASK-001 : Créer le composant SprintEditModal

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Create : `src/components/tasks/SprintEditModal.tsx`
- **Acceptance** :
  - [x] La modale reçoit un `sprintId` et un callback `onClose`
  - [x] Pré-remplit les champs avec les valeurs actuelles (nom, numéro, weekRange, dates)
  - [x] Bouton « Enregistrer » appelle `updateSprint` et ferme la modale
  - [x] Bouton « Annuler » et clic sur le backdrop ferment sans sauvegarder
  - [x] Touche Escape ferme la modale
  - [x] Rendue via `createPortal` dans `document.body`
- **Depends** : none
- **Done** : 2026-02-12T14:30:00Z
- **Notes** : Modale centrée avec z-[60]/z-[61] pour passer au-dessus du dropdown z-50. Backdrop semi-transparent. Formulaire 5 champs. Bouton X dans le header.

---

### Integration

#### TASK-002 : Intégrer l'icône modifier et la modale dans SprintSelector

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/components/tasks/SprintSelector.tsx`
- **Acceptance** :
  - [x] Chaque sprint dans le dropdown affiche une icône Pencil au survol
  - [x] Cliquer sur l'icône ouvre la modale `SprintEditModal` avec le bon `sprintId`
  - [x] Le clic sur l'icône ne sélectionne pas le sprint (`stopPropagation`)
  - [x] Après fermeture de la modale, le dropdown reste fonctionnel
  - [x] Build et lint passent
- **Depends** : TASK-001
- **Done** : 2026-02-12T14:33:00Z
- **Notes** : Icône Pencil visible au hover via `group`/`group-hover:opacity-100`. État `editingSprintId` (ID | null) contrôle l'ouverture. stopPropagation sur click et keydown.

---

## Dependency Graph

```
TASK-001 (component: SprintEditModal)
   │
   ▼
TASK-002 (integration: SprintSelector + icône)
```

## Summary

| Groupe      | Tâches       | Status       |
| ----------- | ------------ | ------------ |
| Components  | 1 (TASK-001) | 1/1 done     |
| Integration | 1 (TASK-002) | 1/1 done     |
| **Total**   | **2**        | **2/2 done** |
