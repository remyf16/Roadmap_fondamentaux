# Plan : Sprints dans l'entête de la timeline

## Overview

- **Feature** : [timeline-sprint-header.md](../../.claude/features/timeline-sprint-header.md)
- **Tâches** : 1 tâche
- **Status** : planning

## Task List

### Components

#### TASK-001 : Ajouter la ligne sprint dans l'entête du TimelineView

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/components/views/TimelineView/TimelineView.tsx`
- **Acceptance** :
  - [x] HEADER_HEIGHT augmenté de 60 à 88 (28px pour la ligne sprint)
  - [x] Une seconde ligne apparaît dans l'entête, sous les mois
  - [x] Chaque sprint est un bloc vert positionné horizontalement via `getX`/`getWidth`
  - [x] Le bloc affiche le nom du sprint et sa plage de semaines (weekRange)
  - [x] Les sprint bands, task rows et milestones utilisent le nouveau HEADER_HEIGHT
  - [x] Build et lint passent
- **Depends** : none
- **Done** : 2026-02-12T14:45:00Z
- **Notes** : HEADER_HEIGHT décomposé en MONTH_ROW_HEIGHT (60) + SPRINT_ROW_HEIGHT (28). Header restructuré en flex-col avec 2 lignes. Sprint bands utilisent `top: HEADER_HEIGHT` au lieu du hardcodé `top-[60px]`. Classes Tailwind `w-[200px]` remplacées par `w-50`.

---

## Dependency Graph

```
TASK-001 (component: TimelineView header sprint row)
```

## Summary

| Groupe     | Tâches       | Status       |
| ---------- | ------------ | ------------ |
| Components | 1 (TASK-001) | 1/1 done     |
| **Total**  | **1**        | **1/1 done** |
