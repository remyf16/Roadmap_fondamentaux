# Plan : Sélecteur et filtre de thématiques

## Overview

- **Feature** : [Spec](../../features/topic-selector-filter.md)
- **Tâches** : 7 tâches
- **Status** : done

## Task List

### Types & Interfaces

#### TASK-001 : Ajouter le type Topic et topicIds sur Task

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/types/models.ts`
  - Modify : `src/data/seed.ts` (ajout `topics: []` pour satisfaire le type)
  - Modify : `src/hooks/usePersistence.ts` (ajout `topics: []` dans save pour satisfaire le type)
- **Acceptance** :
  - [x] Interface `Topic` existe avec `id: ID`, `name: string`, `color: string`
  - [x] `Task` a un champ optionnel `topicIds?: ID[]`
  - [x] `AppData` inclut `topics: Topic[]`
- **Depends** : none
- **Done** : 2026-02-12T13:43:00Z
- **Notes** : Ajout minimal de `topics: []` dans seed.ts et usePersistence.ts pour que le build passe. Ces fichiers seront enrichis dans les tâches suivantes (TASK-002 pour seed, TASK-003 pour persistance complète).

---

### Store

#### TASK-002 : Créer topicSlice et l'intégrer au store

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Create : `src/store/slices/topicSlice.ts`
  - Create : `src/store/slices/topicSlice.test.ts`
  - Modify : `src/store/index.ts`
- **Acceptance** :
  - [x] `TopicSlice` expose `topics: Topic[]`, `setTopics`, `addTopic`, `updateTopic`, `deleteTopic`
  - [x] `addTopic` génère un `id` via `crypto.randomUUID()`
  - [x] Le slice est intégré dans `AppStore` et `useAppStore`
  - [x] Tests unitaires du slice passent (8 tests)
- **Depends** : TASK-001
- **Done** : 2026-02-12T13:45:00Z
- **Notes** : Palette de 10 couleurs avec `getNextColor()` exportée. `addTopic` retourne le topic créé pour permettre au composant de récupérer l'id immédiatement. 8 tests couvrent CRUD + rotation de couleurs.

---

#### TASK-003 : Ajouter topicIds aux filtres et à la persistance

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/store/slices/uiSlice.ts`
  - Modify : `src/hooks/useFilteredTasks.ts`
  - Modify : `src/hooks/usePersistence.ts`
  - Modify : `src/hooks/useFilteredTasks.test.ts`
  - Modify : `src/store/slices/uiSlice.test.ts`
- **Acceptance** :
  - [x] `Filters` contient `topicIds: ID[]` (défaut `[]`)
  - [x] `useFilteredTasks` filtre les tâches : si `topicIds` non vide, seules les tâches ayant au moins un topic correspondant sont affichées
  - [x] `usePersistence` charge et sauvegarde `topics` (via `setTopics`)
  - [x] Tests existants de `useFilteredTasks` et `uiSlice` restent verts
  - [x] Nouveaux tests pour le filtre par topicIds (4 tests topic + 3 tests uiSlice)
- **Depends** : TASK-002
- **Done** : 2026-02-12T13:48:00Z
- **Notes** : Filtre inclusif (OR). Les tâches sans topicIds ou avec topicIds vide sont exclues quand le filtre est actif. `usePersistence` utilise `source.topics ?? []` pour la rétrocompatibilité avec les données existantes sans topics.

---

### Components

#### TASK-004 : Créer le composant TopicSelector (combobox creatable)

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Create : `src/components/tasks/TopicSelector.tsx`
- **Acceptance** :
  - [x] Affiche les thématiques sélectionnées comme badges colorés avec bouton ×
  - [x] Champ input qui filtre les thématiques existantes en dropdown
  - [x] Option « Créer "{texte}" » apparaît si aucune correspondance exacte
  - [x] Cliquer sur « Créer » appelle `addTopic` et associe le nouveau topic à la tâche
  - [x] Le dropdown se ferme quand on clique à l'extérieur ou qu'on sélectionne
- **Depends** : TASK-002
- **Done** : 2026-02-12T13:50:00Z
- **Notes** : 155 lignes. Gestion clavier (Escape, Enter pour créer). Placeholder « Rechercher ou créer… ». Guillemets français « » pour l'option de création. Pastille colorée dans le dropdown.

---

#### TASK-005 : Intégrer TopicSelector dans TaskDetailPanel

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/components/tasks/TaskDetailPanel.tsx`
- **Acceptance** :
  - [x] Section « Thématiques » visible entre « Métiers » et « Sprint »
  - [x] Le `TopicSelector` est rendu avec le `taskId` de la tâche sélectionnée
  - [x] L'ajout/retrait de thématiques met à jour la tâche en temps réel
- **Depends** : TASK-004
- **Done** : 2026-02-12T13:51:00Z
- **Notes** : Import du TopicSelector + section avec label « Thématiques » ajoutée entre Métiers et Sprint. Même style de label que les autres sections.

---

#### TASK-006 : Ajouter le filtre thématiques dans la Sidebar

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/components/layout/Sidebar.tsx`
- **Acceptance** :
  - [x] Nouvelle section collapsible « Thématiques » avec icône `Tag` (lucide)
  - [x] Checkboxes avec pastille de couleur + nom de la thématique
  - [x] Toggle de filtre met à jour `filters.topicIds` dans le store
  - [x] Le bouton « Reset » prend en compte les `topicIds`
  - [x] La section n'apparaît que s'il y a au moins une thématique
- **Depends** : TASK-003
- **Done** : 2026-02-12T13:53:00Z
- **Notes** : Même pattern que équipes avec pastille de couleur. Section conditionnelle (`topics.length > 0`). `hasFilters` inclut `topicIds`.

---

#### TASK-007 : Afficher les badges thématiques sur les cartes Kanban

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/components/views/KanbanView/KanbanCard.tsx`
- **Acceptance** :
  - [x] Les thématiques de la tâche s'affichent comme des `Badge` colorés
  - [x] Les badges apparaissent dans la zone `flex-wrap` existante, après le badge équipe
  - [x] Pas de badge si la tâche n'a aucune thématique
- **Depends** : TASK-001
- **Done** : 2026-02-12T13:55:00Z
- **Notes** : Ajout de `topics` depuis le store, filtrage par `task.topicIds`, rendu via `Badge` avec couleur du topic. Placé entre badge équipe et badge sprint.

---

### Seed Data

> La seed data sera ajoutée dans TASK-002 (quelques topics d'exemple dans `seed.ts`) pour pouvoir tester visuellement dès le début. Quelques tâches existantes se verront attribuer des `topicIds` dans le seed.

---

## Dependency Graph

```
TASK-001 (Types)
  ├──> TASK-002 (topicSlice + store)
  │      ├──> TASK-003 (Filtres + persistance)
  │      │      └──> TASK-006 (Sidebar filtre)
  │      └──> TASK-004 (TopicSelector)
  │             └──> TASK-005 (Intégration TaskDetailPanel)
  └──> TASK-007 (Badges KanbanCard)
```

## Ordre d'implémentation recommandé

1. **TASK-001** — Types (prérequis de tout)
2. **TASK-002** — topicSlice + store + seed
3. **TASK-003** — Filtres, persistance, hook _(peut être parallélisé avec TASK-004)_
4. **TASK-004** — TopicSelector _(peut être parallélisé avec TASK-003)_
5. **TASK-005** — Intégration dans TaskDetailPanel
6. **TASK-006** — Sidebar filtre
7. **TASK-007** — Badges Kanban _(peut être fait dès après TASK-001, indépendant)_

## Summary

| Groupe     | Tâches | Status       |
| ---------- | ------ | ------------ |
| Types      | 1      | 1/1 done     |
| Store      | 2      | 2/2 done     |
| Components | 4      | 4/4 done     |
| **Total**  | **7**  | **7/7 done** |
