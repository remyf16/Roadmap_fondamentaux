# Plan : Sélecteur et filtre de métiers

## Overview

- **Feature** : [role-selector-filter](../../features/role-selector-filter.md)
- **Tâches** : 7 tâches
- **Status** : planning

## Task List

### Types & Interfaces

#### TASK-001 : Ajouter type Role et champ roles dans Task

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/types/models.ts`
- **Acceptance** :
  - [x] Type `Role` défini avec 7 valeurs : product_owner, product_manager, product_designer, product_marketing_manager, direction, e_learning, developer
  - [x] Champ `roles?: Role[]` ajouté à l'interface `Task` (optionnel)
  - [x] Export du type `Role` dans le fichier
- **Depends** : none
- **Done** : 2026-02-11T18:59:24Z
- **Notes** : Type `Role` ajouté après `TaskStatus` (ligne 20) pour regrouper les types liés aux tâches. Champ `roles` ajouté après `tags` dans l'interface `Task` (ligne 54) pour regrouper les métadonnées optionnelles.

---

### Store

#### TASK-002 : Ajouter filtre roles dans uiSlice

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/store/slices/uiSlice.ts`
- **Acceptance** :
  - [x] Champ `roles: Role[]` ajouté à l'interface `Filters`
  - [x] `defaultFilters` mis à jour avec `roles: []`
  - [x] Import du type `Role` depuis models.ts
- **Depends** : TASK-001
- **Done** : 2026-02-11T19:01:38Z
- **Notes** : Import `Role` ajouté à la ligne 2. Champ `roles: Role[]` ajouté dans l'interface `Filters` (ligne 9). `defaultFilters` mis à jour avec `roles: []` (ligne 31). Pattern strictement identique aux autres filtres (teamIds, sprintIds) pour cohérence.

---

### Hooks

#### TASK-003 : Mettre à jour useFilteredTasks pour filtrer par roles

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/hooks/useFilteredTasks.ts`
- **Acceptance** :
  - [x] Logique de filtrage par roles ajoutée dans le useMemo
  - [x] Affiche les tâches avec AU MOINS UN rôle filtré (logique OR)
  - [x] Les tâches sans roles ne sont pas filtrées (rétrocompatibilité)
  - [x] Le filtrage ne s'applique que si `filters.roles.length > 0`
- **Depends** : TASK-002
- **Done** : 2026-02-11T19:05:45Z
- **Notes** : Logique de filtrage ajoutée lignes 30-36. Utilise `task.roles?.some(role => filters.roles.includes(role))` pour vérifier si au moins un rôle correspond (logique OR). Les tâches sans roles (undefined ou []) ne sont pas filtrées pour rétrocompatibilité. Le filtrage ne s'active que si `filters.roles.length > 0`.

---

### Components

#### TASK-004 : Ajouter sélecteur de métiers dans TaskDetailPanel

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/components/tasks/TaskDetailPanel.tsx`
- **Acceptance** :
  - [x] Section "Métiers" ajoutée après le champ "Équipe"
  - [x] 7 checkboxes avec labels en français (Product owner, Product manager, etc.)
  - [x] Les checkboxes reflètent l'état `task.roles` actuel
  - [x] Toggle d'un checkbox met à jour le store via `updateTask`
  - [x] Labels cliquables et accessibles
- **Depends** : TASK-001
- **Done** : 2026-02-11T19:04:03Z
- **Notes** : Import `Role` ajouté (ligne 3). Tableau `roleOptions` créé (lignes 13-20) avec les 7 rôles et labels français. Fonction `toggleRole` implémentée (lignes 48-53) pour gérer le toggle des checkboxes. Section UI "Métiers" ajoutée entre Team et Sprint (lignes 155-172) avec checkboxes cliquables et accessibles.

---

#### TASK-005 : Ajouter section filtres métiers dans Sidebar

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Modify : `src/components/layout/Sidebar.tsx`
- **Acceptance** :
  - [x] Section "Métiers" collapsible ajoutée après "Sprints"
  - [x] 7 checkboxes pour les rôles avec labels en français
  - [x] Fonction `toggleRoleFilter` implémentée (pattern des autres filtres)
  - [x] État local `rolesOpen` pour collapse/expand
  - [x] Le bouton "Reset" réinitialise aussi les filtres roles
  - [x] Icône appropriée pour la section (ex: Briefcase)
- **Depends** : TASK-002
- **Done** : 2026-02-11T19:09:45Z
- **Notes** : Import `Role` et `Briefcase` ajoutés (lignes 3-10). Tableau `roleOptions` créé (lignes 12-19) avec labels français. État local `rolesOpen` ajouté (ligne 29). `hasFilters` mis à jour pour inclure `filters.roles.length > 0` (lignes 31-34). Fonction `toggleRoleFilter` implémentée (lignes 52-59) suivant le pattern exact des autres filtres. Section UI "Métiers" ajoutée après Sprints (lignes 146-168) avec icône Briefcase, pattern strictement identique à Teams/Sprints.

---

### Tests

#### TASK-006 : Tests pour useFilteredTasks avec filtrage roles

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Create : `src/hooks/useFilteredTasks.test.ts`
- **Acceptance** :
  - [x] Test : filtre par un seul rôle
  - [x] Test : filtre par plusieurs rôles (logique OR)
  - [x] Test : tâches sans roles ne sont pas filtrées
  - [x] Test : combinaison filtres roles + teams + sprints
- **Depends** : TASK-003
- **Done** : 2026-02-11T19:16:18Z
- **Notes** : Fichier de test créé (126 lignes) utilisant renderHook de @testing-library/react avec le store global. 4 tests créés couvrant : filtrage par un seul rôle, filtrage par plusieurs rôles (logique OR), backward compatibility (tâches sans roles ne sont pas filtrées), et combinaison de filtres multiples. Les tests vérifient que les tâches sans roles (undefined ou []) ne sont jamais filtrées pour assurer la rétrocompatibilité. Tous les tests passent (13/13 tests dans la suite complète).

---

#### TASK-007 : Tests pour uiSlice avec filtre roles

- **Status** : done
- **Stack** : frontend
- **Files** :
  - Create : `src/store/slices/uiSlice.test.ts`
- **Acceptance** :
  - [x] Test : setFilter('roles', [...]) met à jour filters.roles
  - [x] Test : resetFilters() réinitialise filters.roles à []
  - [x] Test : defaultFilters contient roles: []
- **Depends** : TASK-002
- **Done** : 2026-02-11T19:11:38Z
- **Notes** : Fichier de test créé (41 lignes) suivant strictement le pattern de taskSlice.test.ts. 3 tests créés couvrant l'initialisation, setFilter et resetFilters pour le champ roles. Tous les tests passent (9/9 tests passent dans la suite complète).

---

## Dependency Graph

```
TASK-001 (Types)
    ├── TASK-002 (Store uiSlice)
    │       ├── TASK-003 (Hook useFilteredTasks)
    │       │       └── TASK-006 (Tests hook)
    │       ├── TASK-005 (Sidebar)
    │       └── TASK-007 (Tests uiSlice)
    └── TASK-004 (TaskDetailPanel)
```

## Ordre d'implémentation recommandé

1. **TASK-001** (Types) - Fondation
2. **TASK-002** (Store) - Fondation
3. **TASK-004** (TaskDetailPanel) - UI sélecteur
4. **TASK-003** (Hook) - Logique filtrage
5. **TASK-005** (Sidebar) - UI filtre
6. **TASK-007** (Tests uiSlice) - Validation store
7. **TASK-006** (Tests hook) - Validation filtrage

## Summary

| Groupe     | Tâches | Status         |
| ---------- | ------ | -------------- |
| Types      | 1      | 1/1 done ✓     |
| Store      | 1      | 1/1 done ✓     |
| Hooks      | 1      | 1/1 done ✓     |
| Components | 2      | 2/2 done ✓     |
| Tests      | 2      | 2/2 done ✓     |
| **Total**  | **7**  | **7/7 done ✓** |

## Notes d'implémentation

### Labels français des métiers

```typescript
const roleOptions: { value: Role; label: string }[] = [
  { value: "product_owner", label: "Product owner" },
  { value: "product_manager", label: "Product manager" },
  { value: "product_designer", label: "Product designer" },
  { value: "product_marketing_manager", label: "Product marketing manager" },
  { value: "direction", label: "Direction" },
  { value: "e_learning", label: "E-learning" },
  { value: "developer", label: "Développeur" },
];
```

### Pattern de toggle pour les checkboxes (TaskDetailPanel)

```typescript
const toggleRole = (role: Role) => {
  const currentRoles = task.roles ?? [];
  const newRoles = currentRoles.includes(role)
    ? currentRoles.filter((r) => r !== role)
    : [...currentRoles, role];
  updateTask(task.id, { roles: newRoles });
};
```

### Pattern de toggle pour les filtres (Sidebar)

```typescript
const toggleRoleFilter = (role: Role) => {
  const current = filters.roles;
  setFilter(
    "roles",
    current.includes(role)
      ? current.filter((r) => r !== role)
      : [...current, role],
  );
};
```

### Icône suggérée pour la section Métiers

```typescript
import { Briefcase } from "lucide-react";
```
