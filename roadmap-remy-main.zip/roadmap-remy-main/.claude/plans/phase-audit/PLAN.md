# Phase Audit: Fix All Issues & Implement Recommendations

## Overview

- **Objective**: Corriger tous les issues identifiés dans AUDIT.md et implémenter les recommandations pour monter la maturité de 3/5 à 4/5
- **Source**: AUDIT.md (19/33 checks passed → target 30+/33)
- **Tasks**: 15 tasks réparties en 4 groupes
- **Prerequisites**: Aucun (phase initiale)
- **Completed**: 2026-02-11

## Task List

### Critical Fixes (Issues)

#### TASK-001: Corriger la clé racine de .mcp.json

- **Status**: done
- **Stack**: config
- **Docs**:
  - AUDIT.md ISSUE-1 (Clé "Servers" au lieu de "mcpServers")
  - AUDIT.md ISSUE-2 (Mismatch de nom de serveur)
- **Modify**: `.mcp.json`
- **Create**: -
- **Acceptance**:
  - [x] `.mcp.json` utilise `"mcpServers"` comme clé racine
  - [x] Le serveur est nommé `"miro"` (correspond à `enabledMcpjsonServers`)
  - [x] Le champ `"imports": []` est supprimé
  - [x] JSON valide et parseable
- **Depends**: none
- **Done**: 2026-02-11T15:00:00Z
- **Notes**: Renommé `"Servers"` → `"mcpServers"`, `"miro-mcp-beta"` → `"miro"`, supprimé `"imports"`

---

#### TASK-002: Installer Husky et initialiser les git hooks

- **Status**: done
- **Stack**: config
- **Docs**:
  - AUDIT.md ISSUE-3 (Pas de Husky installé)
  - AUDIT.md Section "Git Setup (MANDATORY)"
- **Modify**: `roadmap-app/package.json` (devDependencies + script prepare)
- **Create**: `.husky/pre-commit`, `.husky/commit-msg`
- **Acceptance**:
  - [x] `husky` est dans devDependencies
  - [x] Script `"prepare": "cd .. && husky"` existe dans package.json
  - [x] `.husky/pre-commit` existe et exécute `cd roadmap-app && npx lint-staged`
  - [x] `.husky/commit-msg` existe et exécute `cd roadmap-app && npx commitlint --edit $1`
  - [x] `npm run prepare` s'exécute sans erreur
- **Depends**: none
- **Done**: 2026-02-11T15:02:00Z
- **Notes**: Hooks créés à la racine git (pas dans roadmap-app/) car .git est au root. Script prepare adapté avec `cd ..`.

---

#### TASK-003: Installer et configurer lint-staged

- **Status**: done
- **Stack**: config
- **Docs**:
  - AUDIT.md ISSUE-4 (Pas de lint-staged)
- **Modify**: `roadmap-app/package.json` (devDependencies + config lint-staged)
- **Create**: -
- **Acceptance**:
  - [x] `lint-staged` est dans devDependencies
  - [x] Configuration `lint-staged` dans package.json avec règles pour `*.{ts,tsx}` et `*.{json,md,yml,yaml,css}`
  - [x] `npx lint-staged` s'exécute sans erreur sur un fichier propre
- **Depends**: TASK-002
- **Done**: 2026-02-11T15:02:00Z
- **Notes**: Installé en même temps que TASK-002. ESLint fix + Prettier write pour ts/tsx, Prettier write pour autres formats.

---

#### TASK-004: Installer et configurer commitlint

- **Status**: done
- **Stack**: config
- **Docs**:
  - AUDIT.md ISSUE-5 (Pas de commitlint)
- **Modify**: `roadmap-app/package.json` (devDependencies)
- **Create**: `roadmap-app/commitlint.config.js`
- **Acceptance**:
  - [x] `@commitlint/cli` et `@commitlint/config-conventional` sont dans devDependencies
  - [x] `commitlint.config.js` existe avec les règles conventionnelles
  - [x] `echo "feat: test" | npx commitlint` passe
  - [x] `echo "bad message" | npx commitlint` échoue
- **Depends**: TASK-002
- **Done**: 2026-02-11T15:02:00Z
- **Notes**: Scopes configurés : ui, components, flow, dnd, store, config, deps, styles. Vérifié : messages valides passent, invalides échouent.

---

#### TASK-005: Installer Prettier

- **Status**: done
- **Stack**: config
- **Docs**:
  - AUDIT.md WARN-7 (Pas de Prettier)
- **Modify**: `roadmap-app/package.json` (devDependencies)
- **Create**: -
- **Acceptance**:
  - [x] `prettier` est dans devDependencies
  - [x] `npx prettier --check "src/**/*.{ts,tsx}"` s'exécute
  - [x] lint-staged de TASK-003 utilise `prettier --write`
- **Depends**: TASK-003
- **Done**: 2026-02-11T15:02:00Z
- **Notes**: Installé en batch avec les autres deps. Pas de .prettierrc créé, les defaults Prettier suffisent. Invoqué via lint-staged.

---

### Settings & Configuration

#### TASK-006: Ajouter language et attribution dans settings.json

- **Status**: done
- **Stack**: config
- **Docs**:
  - AUDIT.md WARN-2 (language dans settings)
  - AUDIT.md WARN-3 (attribution Claude)
  - AUDIT.md QUICKWIN-1 et QUICKWIN-2
- **Modify**: `.claude/settings.json`
- **Create**: -
- **Acceptance**:
  - [x] `"language": "french"` présent dans settings.json
  - [x] `"attribution"` avec `"commit"` contenant `Co-Authored-By: Claude` présent
  - [x] JSON valide et parseable
- **Depends**: none
- **Done**: 2026-02-11T14:59:00Z
- **Notes**: Quick win appliqué.

---

#### TASK-007: Améliorer les permissions dans settings.json

- **Status**: done
- **Stack**: config
- **Docs**:
  - AUDIT.md Section "Améliorer les permissions"
  - AUDIT.md QUICKWIN-3 (Protéger fichiers sensibles)
- **Modify**: `.claude/settings.json`
- **Create**: -
- **Acceptance**:
  - [x] Permissions `allow` incluent git commands (status, diff, log, add, commit, branch)
  - [x] Permissions `allow` incluent npm commands (lint, build, tsc)
  - [x] Permissions `ask` incluent `Bash(git push *)`
  - [x] Permissions `deny` incluent `Write(.env*)` et `Write(**/*.secret)`
  - [x] JSON valide et parseable
- **Depends**: TASK-006
- **Done**: 2026-02-11T15:03:00Z
- **Notes**: Ajouté section `ask` pour git push. Protégé .env et .secret en deny.

---

### CLAUDE.md & Instructions

#### TASK-008: Optimiser CLAUDE.md (retirer documentation MCP)

- **Status**: done
- **Stack**: config
- **Docs**:
  - AUDIT.md WARN-1 (Trop documentaire, pas assez actionable)
- **Modify**: `CLAUDE.md`
- **Create**: -
- **Acceptance**:
  - [x] Section "Outils MCP Miro disponibles" (lignes 9-29) supprimée
  - [x] Section "Rôle" fusionnée en une ligne d'intro
  - [x] Section "Conventions" conservée intacte
  - [x] Instruction "Répondre en français" retirée (gérée par settings.json TASK-006)
  - [x] Fichier < 15 lignes (10 lignes)
- **Depends**: TASK-006
- **Done**: 2026-02-11T15:03:00Z
- **Notes**: CLAUDE.md réduit de 37 lignes à 10 lignes. Rôle et outils MCP retirés car redondants.

---

### Rules (Scoped Instructions)

#### TASK-009: Créer la rule React conventions

- **Status**: done
- **Stack**: config
- **Docs**:
  - AUDIT.md WARN-5 (Aucune règle scopée)
  - AUDIT.md Section "Créer des Rules scopées"
- **Modify**: -
- **Create**: `.claude/rules/react-conventions.md`
- **Acceptance**:
  - [x] Fichier existe avec frontmatter YAML `paths: 'roadmap-app/src/**/*.tsx'`
  - [x] Contient les conventions : composants fonctionnels, Zustand, hooks React 19, un composant par fichier, interfaces TypeScript, clsx
- **Depends**: none
- **Done**: 2026-02-11T14:59:00Z
- **Notes**: -

---

#### TASK-010: Créer la rule TypeScript conventions

- **Status**: done
- **Stack**: config
- **Docs**:
  - AUDIT.md WARN-5 (Aucune règle scopée)
  - AUDIT.md Section "Créer des Rules scopées"
- **Modify**: -
- **Create**: `.claude/rules/typescript-conventions.md`
- **Acceptance**:
  - [x] Fichier existe avec frontmatter YAML `paths: 'roadmap-app/src/**/*.ts'`
  - [x] Contient les conventions : strict mode, pas de `any`, types explicites, imports groupés
- **Depends**: none
- **Done**: 2026-02-11T14:59:00Z
- **Notes**: -

---

### Hooks

#### TASK-011: Ajouter le hook SessionStart dans settings.json

- **Status**: done
- **Stack**: config
- **Docs**:
  - AUDIT.md WARN-6 (Aucun hook configuré)
  - AUDIT.md Section "Ajouter un hook SessionStart"
- **Modify**: `.claude/settings.json`
- **Create**: -
- **Acceptance**:
  - [x] `"hooks"` présent dans settings.json
  - [x] Hook `SessionStart` configuré avec commande git status
  - [x] Timeout de 5 secondes configuré
  - [x] JSON valide et parseable
- **Depends**: TASK-007
- **Done**: 2026-02-11T15:03:00Z
- **Notes**: Injecte branche courante + nombre de fichiers modifiés au démarrage de session.

---

### Git Skills

#### TASK-012: Créer le skill /commit

- **Status**: done
- **Stack**: config
- **Docs**:
  - AUDIT.md Section "Git skills" (non définis)
- **Modify**: -
- **Create**: `.claude/skills/git/commit/SKILL.md`
- **Acceptance**:
  - [x] SKILL.md existe avec frontmatter valide (name, description)
  - [x] Nom en kebab-case < 64 caractères
  - [x] Instructions pour créer un commit conventionnel (type, scope, message)
  - [x] Inclut les étapes : git status, git diff, rédaction message, git add, git commit
- **Depends**: TASK-004
- **Done**: 2026-02-11T15:03:00Z
- **Notes**: Utilise les conventions commitlint (type, scope, subject rules).

---

#### TASK-013: Créer le skill /pr

- **Status**: done
- **Stack**: config
- **Docs**:
  - AUDIT.md Section "Git skills" (non définis)
- **Modify**: -
- **Create**: `.claude/skills/git/pr/SKILL.md`
- **Acceptance**:
  - [x] SKILL.md existe avec frontmatter valide (name, description)
  - [x] Nom en kebab-case < 64 caractères
  - [x] Instructions pour créer une PR (titre, description, labels)
  - [x] Utilise `gh pr create` avec format structuré
- **Depends**: none
- **Done**: 2026-02-11T14:59:00Z
- **Notes**: -

---

### Subagent

#### TASK-014: Créer l'agent miro-explorer (read-only)

- **Status**: done
- **Stack**: config
- **Docs**:
  - AUDIT.md WARN-4 (Aucun subagent défini)
- **Modify**: -
- **Create**: `.claude/agents/miro-explorer.md`
- **Acceptance**:
  - [x] Fichier agent existe avec instructions claires
  - [x] Limité aux outils read-only : `context_explore`, `context_get`, `board_list_items`, `image_get_url`
  - [x] Pas d'outils de création/modification
- **Depends**: TASK-001
- **Done**: 2026-02-11T15:03:00Z
- **Notes**: Agent read-only. Liste explicitement les outils interdits pour éviter tout risque.

---

### Validation

#### TASK-015: Validation finale et mise à jour AUDIT.md

- **Status**: done
- **Stack**: config
- **Docs**:
  - AUDIT.md (tous les checks)
- **Modify**: `PLAN.md`
- **Create**: -
- **Acceptance**:
  - [x] Tous les ISSUE (1-5) sont résolus
  - [x] Tous les WARN (1-7) sont adressés
  - [x] `npm run lint` passe dans roadmap-app/
  - [x] `npm run build` passe dans roadmap-app/
  - [x] Toutes les tasks marquées done dans PLAN.md
- **Depends**: TASK-001 through TASK-014
- **Done**: 2026-02-11T15:05:00Z
- **Notes**: lint et build passent. Tous les fichiers créés et vérifiés. Maturité estimée 4/5.

---

## Dependency Graph

```
TASK-001 (fix .mcp.json)          → done ✅
TASK-002 (husky)                  → done ✅
  ├── TASK-003 (lint-staged)      → done ✅
  │   └── TASK-005 (prettier)     → done ✅
  └── TASK-004 (commitlint)       → done ✅
      └── TASK-012 (/commit)      → done ✅
TASK-006 (language+attribution)   → done ✅
  ├── TASK-007 (permissions)      → done ✅
  │   └── TASK-011 (hook)         → done ✅
  └── TASK-008 (CLAUDE.md)        → done ✅
TASK-009 (rule react)             → done ✅
TASK-010 (rule typescript)        → done ✅
TASK-013 (/pr skill)              → done ✅
TASK-014 (miro-explorer agent)    → done ✅
TASK-015 (validation)             → done ✅
```

## Summary

| Groupe             | Tasks | Status |
| ------------------ | ----- | ------ |
| Critical Fixes     | 5     | 5/5 done |
| Settings & Config  | 2     | 2/2 done |
| CLAUDE.md          | 1     | 1/1 done |
| Rules              | 2     | 2/2 done |
| Hooks              | 1     | 1/1 done |
| Git Skills         | 2     | 2/2 done |
| Subagent           | 1     | 1/1 done |
| Validation         | 1     | 1/1 done |
| **Total**          | **15**| **15/15 done** |
