# Feature : Sélecteur et filtre de métiers

**Slug** : role-selector-filter
**Date** : 2026-02-11
**Status** : draft

## Contexte

Les tâches de la roadmap impliquent différents métiers (Product Owner, Product Manager, Designer, etc.). Il est nécessaire de pouvoir identifier quels métiers sont responsables de chaque tâche et de filtrer les tâches par métier pour avoir une vue organisée par rôle.

Cette feature ajoute :

1. Un sélecteur multi-métiers dans le panneau "Détail de la tâche"
2. Un filtre par métiers dans la sidebar

## Scope

### In scope

- Ajout d'un type `Role` avec 7 métiers prédéfinis
- Champ `roles` optionnel (array) dans l'interface `Task`
- Sélecteur multi-métiers dans `TaskDetailPanel` (checkboxes ou multi-select)
- Section "Métiers" dans la `Sidebar` avec filtres par checkboxes
- Mise à jour du hook `useFilteredTasks` pour filtrer par métiers
- Textes UI en français avec typographie correcte

### Out of scope

- Personnalisation des métiers par l'utilisateur (liste hardcodée)
- Attribution automatique de métiers basée sur l'équipe
- Statistiques ou analytics par métier
- Export/import des métiers
- Gestion des permissions par métier

## Requirements

- [ ] Le type `Role` contient exactement 7 valeurs : "product_owner", "product_manager", "product_designer", "product_marketing_manager", "direction", "e_learning", "developer"
- [ ] Une tâche peut avoir 0, 1 ou plusieurs métiers assignés
- [ ] Le champ `roles` est optionnel pour rétrocompatibilité avec les tâches existantes
- [ ] Le sélecteur de métiers est placé dans `TaskDetailPanel` après le champ "Équipe"
- [ ] Les labels en français : "Product owner", "Product manager", "Product designer", "Product marketing manager", "Direction", "E-learning", "Développeur"
- [ ] Le filtre "Métiers" dans la sidebar fonctionne comme les filtres Équipes/Sprints (checkboxes)
- [ ] Sélectionner plusieurs métiers dans le filtre affiche les tâches qui ont AU MOINS UN des métiers sélectionnés (logique OR)
- [ ] Les tâches sans métier assigné sont visibles quand aucun filtre métier n'est actif
- [ ] Le bouton "Reset" des filtres réinitialise aussi le filtre métiers
- [ ] La section "Métiers" est collapsible comme les autres sections de filtres

## Zones impactées

| Zone       | Fichiers                                   | Action   |
| ---------- | ------------------------------------------ | -------- |
| Types      | `src/types/models.ts`                      | Modifier |
| Components | `src/components/tasks/TaskDetailPanel.tsx` | Modifier |
| Components | `src/components/layout/Sidebar.tsx`        | Modifier |
| Store      | `src/store/slices/uiSlice.ts`              | Modifier |
| Hooks      | `src/hooks/useFilteredTasks.ts`            | Modifier |

## UX

### Dans TaskDetailPanel

Après le champ "Équipe", ajouter un champ "Métiers" :

```
┌─────────────────────────────┐
│ Équipe                      │
│ [Select équipe ▾]           │
└─────────────────────────────┘

┌─────────────────────────────┐
│ Métiers                     │
│ ☐ Product owner             │
│ ☐ Product manager           │
│ ☐ Product designer          │
│ ☐ Product marketing manager │
│ ☐ Direction                 │
│ ☐ E-learning                │
│ ☑ Développeur               │
└─────────────────────────────┘
```

- L'utilisateur peut cocher plusieurs métiers
- Les métiers cochés sont sauvegardés immédiatement dans le store
- Aucun métier coché = tâche sans métier assigné

### Dans la Sidebar (filtres)

Ajouter une section "Métiers" après "Sprints" :

```
FILTRES                    [Reset]

▾ ÉQUIPES
  ☑ Design
  ☐ Engineering

▾ SPRINTS
  ☑ Sprint 1
  ☐ Sprint 2

▾ MÉTIERS
  ☑ Product owner
  ☐ Product manager
  ☑ Développeur
  ☐ Product designer
  ☐ Product marketing manager
  ☐ Direction
  ☐ E-learning
```

- Comportement identique aux filtres Équipes/Sprints
- Cliquer sur un métier active/désactive le filtre
- Plusieurs métiers peuvent être sélectionnés (logique OR)
- Aucun métier sélectionné = afficher toutes les tâches

## Notes techniques

### Type Role

```typescript
export type Role =
  | "product_owner"
  | "product_manager"
  | "product_designer"
  | "product_marketing_manager"
  | "direction"
  | "e_learning"
  | "developer";
```

Valeurs en snake_case pour cohérence avec `TaskStatus` existant.

### Interface Task

```typescript
export interface Task {
  // ... champs existants
  roles?: Role[]; // Optionnel pour rétrocompatibilité
}
```

### Interface Filters (uiSlice)

```typescript
export interface Filters {
  teamIds: ID[];
  sprintIds: ID[];
  statuses: TaskStatus[];
  searchQuery: string;
  roles: Role[]; // Nouveau
}
```

### Logique de filtrage

Dans `useFilteredTasks`, ajouter :

```typescript
if (filters.roles.length > 0) {
  // Afficher la tâche si elle a AU MOINS UN métier parmi ceux filtrés
  // OU si elle n'a pas de métiers (pour ne pas masquer les anciennes tâches)
  const hasMatchingRole = task.roles?.some((role) =>
    filters.roles.includes(role),
  );
  if (!hasMatchingRole && task.roles && task.roles.length > 0) {
    return false;
  }
}
```

### Accessibilité

- Les checkboxes doivent avoir des labels cliquables (`<label>` wrapping)
- Ordre de tab logique dans TaskDetailPanel
- Pas de couleurs seules pour différencier (utiliser des icônes si nécessaire)

### Performance

- Le hook `useFilteredTasks` utilise `useMemo` (déjà en place)
- Pas d'impact performance attendu (liste de 7 métiers statique)

### Persistence

- Le champ `roles` sera automatiquement persisté via le système existant (`usePersistence`)
- Les filtres actifs dans `uiSlice` ne sont PAS persistés (comportement actuel)
