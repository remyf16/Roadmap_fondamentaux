# Feature : Sélecteur et filtre de thématiques

**Slug** : topic-selector-filter
**Date** : 2026-02-12
**Status** : implemented

## Contexte

Les tâches de la roadmap n'ont actuellement aucun moyen d'être catégorisées par thématique (ex : "Performance", "UX", "Sécurité", "Infrastructure"…). L'utilisateur a besoin de pouvoir associer une ou plusieurs thématiques à chaque tâche, et de filtrer la vue par thématique. Les thématiques sont créées dynamiquement par l'utilisateur (pas de liste prédéfinie).

## Scope

### In scope

- Ajout du concept de "thématique" (`Topic`) dans le modèle de données
- Sélecteur de thématiques dans le panneau de détail de tâche (`TaskDetailPanel`)
- Possibilité de créer une nouvelle thématique directement depuis le sélecteur (combobox/creatable)
- Filtre par thématiques dans la `Sidebar`
- Persistance des thématiques (stockées avec les `AppData`)
- Chaque thématique a un nom et une couleur

### Out of scope

- Gestion avancée des thématiques (page dédiée, édition, suppression, merge)
- Icônes personnalisées pour les thématiques
- Thématiques hiérarchiques (sous-thématiques)

## Requirements

- [ ] Le modèle `Task` possède un champ `topicIds: ID[]` (optionnel)
- [ ] Un nouveau type `Topic` existe avec `id`, `name`, `color`
- [ ] Un `topicSlice` Zustand gère la liste des thématiques (CRUD)
- [ ] Le `TaskDetailPanel` affiche un sélecteur multi-select de thématiques
- [ ] L'utilisateur peut créer une thématique depuis le sélecteur si elle n'existe pas
- [ ] La `Sidebar` contient une section filtre par thématiques (même pattern que équipes/sprints)
- [ ] Le hook `useFilteredTasks` filtre par thématiques sélectionnées
- [ ] L'interface `Filters` du `uiSlice` inclut `topicIds: ID[]`
- [ ] Les thématiques sont persistées dans `AppData` et sauvegardées en localStorage
- [ ] Les thématiques s'affichent sous forme de badges colorés dans les cartes Kanban

## Zones impactées

| Zone       | Fichiers                                         | Action   |
| ---------- | ------------------------------------------------ | -------- |
| Types      | `src/types/models.ts`                            | Modifier |
| Store      | `src/store/slices/topicSlice.ts`                 | Créer    |
| Store      | `src/store/slices/uiSlice.ts`                    | Modifier |
| Store      | `src/store/index.ts`                             | Modifier |
| Components | `src/components/tasks/TaskDetailPanel.tsx`       | Modifier |
| Components | `src/components/tasks/TopicSelector.tsx`         | Créer    |
| Components | `src/components/layout/Sidebar.tsx`              | Modifier |
| Components | `src/components/views/KanbanView/KanbanCard.tsx` | Modifier |
| Hooks      | `src/hooks/useFilteredTasks.ts`                  | Modifier |
| Data       | `src/hooks/usePersistence.ts`                    | Modifier |
| Data       | `src/data/seed.ts`                               | Modifier |

## UX

### Sélecteur dans le détail de tâche

- Section « Thématiques » dans le `TaskDetailPanel`, entre les rôles et le sprint
- Un champ de saisie avec dropdown qui affiche les thématiques existantes
- En tapant, les thématiques sont filtrées
- Si aucune thématique ne correspond, une option « Créer "{texte saisi}" » apparaît
- Les thématiques sélectionnées s'affichent comme des badges colorés avec un bouton × pour retirer
- Couleur assignée automatiquement à la création (palette prédéfinie tournante)

### Filtre dans la sidebar

- Nouvelle section « Thématiques » avec icône `Tag` (lucide), même pattern collapsible que les sections existantes
- Checkboxes avec pastille de couleur + nom de la thématique
- Filtre inclusif : affiche les tâches ayant AU MOINS une des thématiques sélectionnées

### Badges dans les cartes Kanban

- Les thématiques associées s'affichent en petits badges colorés sous le titre de la carte

## Notes techniques

- Le `TopicSelector` est un composant « combobox creatable » custom (pas de lib externe), basé sur un `input` + dropdown filtré
- Palette de couleurs prédéfinie (8-10 couleurs) pour attribution automatique à la création
- Le filtre thématiques suit exactement le même pattern que `teamIds` / `sprintIds` dans le store
- Le `topicSlice` suit le même pattern que `teamSlice` (set, add, update, delete)
- Les thématiques sans tâche associée restent dans la liste (pas de garbage collection)
