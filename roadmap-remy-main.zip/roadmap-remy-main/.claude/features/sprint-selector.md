# Feature : Sélecteur de sprint amélioré

**Slug** : sprint-selector
**Date** : 2026-02-12
**Status** : implemented

## Contexte

Le sélecteur de sprint actuel dans le panneau de détail des tâches est un simple `<select>` HTML. Il ne permet ni de désélectionner un sprint (« Aucun sprint »), ni de créer un nouveau sprint depuis le sélecteur. L'objectif est de remplacer ce `<select>` par un composant riche de type combobox avec cases à cocher, option « Aucun sprint » et création inline, similaire au pattern établi par `TopicSelector`.

## Scope

### In scope

- Option « Aucun sprint » pour désassocier une tâche d'un sprint
- Sélection du sprint via case à cocher (radio-like, un seul sprint à la fois)
- Création d'un nouveau sprint directement depuis le sélecteur
- Rendre `sprintId` optionnel sur le type `Task`
- Ajouter les actions CRUD au `sprintSlice`

### Out of scope

- Multi-sélection de sprints (une tâche = un sprint max)
- Modification ou suppression de sprints depuis le sélecteur
- Changement du filtre sprint dans la sidebar (reste tel quel)
- Gestion des dates automatique lors de la création de sprint

## Requirements

- [ ] `sprintId` est optionnel sur `Task` (`sprintId?: ID`)
- [ ] Le sélecteur affiche le sprint courant ou « Aucun sprint »
- [ ] Cliquer sur « Aucun sprint » retire l'association sprint de la tâche
- [ ] Chaque sprint est sélectionnable via une case à cocher (comportement radio)
- [ ] Un champ de recherche permet de filtrer les sprints par nom
- [ ] Un bouton « Créer » apparaît quand la recherche ne correspond à aucun sprint existant
- [ ] La création inline demande au minimum un nom et une plage de semaines
- [ ] Le nouveau sprint est automatiquement sélectionné après création
- [ ] L'application continue de fonctionner si `sprintId` est `undefined`

## Zones impactées

| Zone        | Fichiers                                         | Action   |
| ----------- | ------------------------------------------------ | -------- |
| Types       | `src/types/models.ts`                            | Modifier |
| Store       | `src/store/slices/sprintSlice.ts`                | Modifier |
| Store       | `src/store/index.ts`                             | Modifier |
| Components  | `src/components/tasks/SprintSelector.tsx`        | Créer    |
| Components  | `src/components/tasks/TaskDetailPanel.tsx`       | Modifier |
| Views       | `src/components/views/KanbanView/KanbanCard.tsx` | Modifier |
| Hooks       | `src/hooks/useFilteredTasks.ts`                  | Modifier |
| Data        | `src/data/seed.ts`                               | Vérifier |
| Persistence | `src/hooks/usePersistence.ts`                    | Vérifier |

## UX

1. Dans le panneau de détail, la section « Sprint » affiche le sprint sélectionné sous forme de badge (ou « Aucun sprint » en gris).
2. Un clic ouvre un dropdown avec :
   - Un champ de recherche en haut
   - L'option « Aucun sprint » avec case à cocher
   - La liste des sprints filtrés avec cases à cocher (le sprint actif est coché)
   - Si aucun résultat : un bouton « Créer « {texte} » »
3. La création inline ouvre un mini-formulaire avec : nom, numéro, plage de semaines, dates début/fin.
4. Après création, le dropdown se ferme et le nouveau sprint est associé à la tâche.
5. Clic en dehors du dropdown le ferme.

## Notes techniques

- Réutiliser le pattern de `TopicSelector.tsx` (click-outside, keyboard, dropdown) adapté en sélection unique.
- `sprintId` passant de requis à optionnel impacte potentiellement les endroits qui accèdent à `task.sprintId` sans vérification — audit nécessaire.
- La création de sprint nécessite des champs structurés (number, startDate, endDate, weekRange) contrairement aux topics qui n'ont qu'un nom. Le formulaire de création sera donc plus complexe.
- Le `sprintSlice` actuel n'a que `setSprints` — il faut ajouter `addSprint`, `updateSprint`, `deleteSprint`.
