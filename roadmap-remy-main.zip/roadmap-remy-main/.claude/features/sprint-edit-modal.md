# Feature : Modale d'édition de sprint

**Slug** : sprint-edit-modal
**Date** : 2026-02-12
**Status** : draft

## Contexte

Le sélecteur de sprint permet de choisir ou créer un sprint, mais pas de modifier un sprint existant. L'utilisateur doit pouvoir éditer les dates, le nom, le numéro et la plage de semaines d'un sprint directement depuis le sélecteur, via une icône de modification qui ouvre une modale.

## Scope

### In scope

- Icône « modifier » (Pencil) sur chaque sprint dans le dropdown du SprintSelector
- Modale d'édition avec tous les champs du sprint : nom, numéro, plage de semaines, dates début/fin
- Sauvegarde via `updateSprint` existant dans le store
- Fermeture de la modale par bouton « Annuler », clic sur le backdrop, ou touche Escape

### Out of scope

- Suppression de sprint depuis la modale
- Création de sprint via la modale (déjà géré par le formulaire inline du sélecteur)
- Modification de sprint depuis la sidebar ou d'autres vues

## Requirements

- [ ] Chaque sprint dans le dropdown affiche une icône Pencil au survol
- [ ] Cliquer sur l'icône ouvre une modale centrée avec backdrop
- [ ] La modale pré-remplit tous les champs avec les valeurs actuelles du sprint
- [ ] Le bouton « Enregistrer » appelle `updateSprint` et ferme la modale
- [ ] Le bouton « Annuler » ferme la modale sans sauvegarder
- [ ] Cliquer sur le backdrop ferme la modale
- [ ] La touche Escape ferme la modale
- [ ] Le clic sur l'icône ne sélectionne pas le sprint (stopPropagation)

## Zones impactées

| Zone       | Fichiers                                   | Action   |
| ---------- | ------------------------------------------ | -------- |
| Components | `src/components/tasks/SprintEditModal.tsx` | Créer    |
| Components | `src/components/tasks/SprintSelector.tsx`  | Modifier |

## UX

1. Dans le dropdown du SprintSelector, chaque ligne de sprint affiche une icône crayon (Pencil) à droite, visible au survol.
2. Cliquer sur le crayon ouvre une modale centrée avec un backdrop semi-transparent.
3. La modale contient :
   - Titre « Modifier le sprint »
   - Champs : nom, numéro, plage de semaines, date de début, date de fin
   - Boutons « Annuler » et « Enregistrer »
4. Après sauvegarde, la modale se ferme et le dropdown reste ouvert (le sprint mis à jour est visible).
5. L'icône crayon ne déclenche pas la sélection du sprint.

## Notes techniques

- L'action `updateSprint(id, updates)` existe déjà dans `sprintSlice`.
- La modale est un composant séparé `SprintEditModal` pour garder `SprintSelector` lisible.
- Utiliser un portail React (`createPortal`) pour rendre la modale au-dessus du dropdown sans conflit de z-index.
- Le pattern de modale est similaire au backdrop de `TaskDetailPanel` mais en version centrée.
