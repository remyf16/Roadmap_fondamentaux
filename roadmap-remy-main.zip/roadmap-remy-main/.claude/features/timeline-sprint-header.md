# Feature : Sprints dans l'entête de la timeline

**Slug** : timeline-sprint-header
**Date** : 2026-02-12
**Status** : draft

## Contexte

Dans la vue Timeline, les sprints sont actuellement affichés comme des bandes de couleur en arrière-plan des tâches, mais sans label ni indication claire de leur nom ou plage de semaines. L'utilisateur doit pouvoir identifier visuellement chaque sprint directement dans l'entête, sous la ligne des mois.

## Scope

### In scope

- Ajout d'une seconde ligne dans l'entête de la Timeline, sous les mois
- Chaque sprint est affiché comme un bloc coloré positionné selon ses dates (startDate/endDate)
- Le bloc affiche le nom du sprint et sa plage de semaines (weekRange)
- Le HEADER_HEIGHT est augmenté pour accueillir la seconde ligne

### Out of scope

- Interaction au clic sur les blocs sprint (édition, sélection)
- Affichage des sprints dans les vues Kanban ou Graph
- Tooltip ou popover au survol des sprints

## Requirements

- [ ] Une seconde ligne apparaît dans l'entête, sous les mois
- [ ] Chaque sprint est représenté par un bloc coloré positionné horizontalement selon ses dates
- [ ] Le bloc affiche le nom du sprint et sa plage de semaines (weekRange)
- [ ] Les blocs sprint ne se chevauchent pas visuellement si les sprints ne se chevauchent pas temporellement
- [ ] Le HEADER_HEIGHT est ajusté pour la nouvelle ligne
- [ ] Les bandes de fond (sprint bands) et les lignes de tâches s'alignent correctement avec le nouveau HEADER_HEIGHT
- [ ] Build et lint passent

## Zones impactées

| Zone       | Fichiers                                             | Action   |
| ---------- | ---------------------------------------------------- | -------- |
| Components | `src/components/views/TimelineView/TimelineView.tsx` | Modifier |

## UX

1. L'entête de la Timeline comporte deux lignes :
   - Ligne 1 (existante) : noms des mois positionnés selon les dates
   - Ligne 2 (nouvelle) : blocs sprint colorés positionnés selon leurs dates
2. Chaque bloc sprint affiche « Sprint N (SX-SY) » où N est le numéro et SX-SY la plage de semaines.
3. Les blocs utilisent une couleur verte douce (cohérente avec les bandes existantes) avec un texte sombre.
4. Le label « TÂCHES » dans la colonne de gauche reste aligné verticalement avec les deux lignes.

## Notes techniques

- Le `HEADER_HEIGHT` passe de 60 à ~90px pour accueillir la ligne sprint (~30px).
- Les sprints sont déjà dans le store (`useAppStore(s => s.sprints)`) et déjà utilisés dans le composant.
- Les fonctions `getX` et `getWidth` existantes peuvent être réutilisées pour positionner les blocs.
- Le `top` des sprint bands, task rows et milestones doit être mis à jour pour refléter le nouveau HEADER_HEIGHT.
- Un seul fichier est impacté : `TimelineView.tsx`.
