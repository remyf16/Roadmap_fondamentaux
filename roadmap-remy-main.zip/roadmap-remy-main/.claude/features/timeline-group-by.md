# Feature : Agrégat d'affichage timeline

**Slug** : timeline-group-by
**Date** : 2025-02-13
**Status** : draft

## Contexte

Actuellement la vue Timeline affiche les tâches dans une liste plate triée par ordre. L'utilisateur a besoin de regrouper visuellement les tâches selon différents axes pour mieux comprendre la répartition du travail : par thème (Topic), par métier (Role) ou par date (mois).

## Scope

### In scope

- Sélecteur d'agrégat au-dessus de la vue Timeline avec 4 options : Aucun / Par thème / Par métier / Par mois
- Regroupement visuel des tâches avec headers de groupe dans la Timeline
- Persistance du choix d'agrégat dans le store UI
- Option « Aucun » pour retrouver l'affichage plat actuel (défaut)

### Out of scope

- Agrégat sur les vues Kanban et Dépendances
- Agrégat par sprint (les sprints sont déjà visibles en bandes)
- Réordonnancement drag & drop des groupes
- Collapse/expand des groupes (v2 potentielle)

## Requirements

- [ ] Un sélecteur « Regrouper par » apparaît au-dessus de la vue Timeline uniquement
- [ ] L'option « Aucun » affiche la vue Timeline actuelle (comportement par défaut)
- [ ] L'option « Par thème » regroupe les tâches par Topic, avec un header coloré par groupe
- [ ] L'option « Par métier » regroupe les tâches par Role, avec un header par groupe
- [ ] L'option « Par mois » regroupe les tâches par mois de début, avec un header par groupe
- [ ] Les tâches sans thème/métier apparaissent dans un groupe « Sans thème » / « Sans métier »
- [ ] Le choix d'agrégat est stocké dans le uiSlice et persiste pendant la session
- [ ] Les groupes affichent un header avec le nom et le nombre de tâches

## Zones impactées

| Zone       | Fichiers                                          | Action   |
| ---------- | ------------------------------------------------- | -------- |
| Types      | `src/types/models.ts`                             | Modifier (ajouter `GroupByType`) |
| Store      | `src/store/slices/uiSlice.ts`                     | Modifier (ajouter `groupBy` + `setGroupBy`) |
| Components | `src/components/views/TimelineView/TimelineView.tsx` | Modifier (logique de groupement) |
| Components | `src/components/views/TimelineView/GroupBySelector.tsx` | Créer   |
| Components | `src/components/views/TimelineView/TimelineGroupHeader.tsx` | Créer   |
| Hooks      | `src/hooks/useGroupedTasks.ts`                    | Créer   |
| Tests      | `src/hooks/useGroupedTasks.test.ts`               | Créer   |
| Tests      | `src/store/slices/uiSlice.test.ts`                | Modifier |

## UX

### Sélecteur d'agrégat
- Barre de contrôle positionnée entre le header principal et la vue Timeline
- Visible uniquement quand la vue active est « Timeline »
- Apparence : groupe de boutons (toggle group) avec les options : `Aucun` | `Par thème` | `Par métier` | `Par mois`
- L'option active est mise en surbrillance (style similaire au sélecteur de vue dans le Header)

### Affichage groupé
- Chaque groupe a un header pleine largeur avec :
  - Un indicateur coloré (pastille pour thème, icône pour métier)
  - Le nom du groupe
  - Le nombre de tâches entre parenthèses
- Les tâches du groupe sont affichées normalement en dessous du header
- Les barres de tâches conservent leur position temporelle (axe X inchangé)
- Seul l'axe Y (ordre des rangées) change selon le regroupement

### Regroupement par thème
- Un groupe par Topic, trié alphabétiquement
- Couleur du header = couleur du Topic
- Les tâches ayant plusieurs topics apparaissent dans le premier topic (par ordre alphabétique)
- Groupe « Sans thème » en dernier

### Regroupement par métier
- Un groupe par Role, trié selon l'ordre défini dans le type Role
- Labels français : Product Owner, Product Manager, Product Designer, PMM, Direction, E-learning, Développeur
- Les tâches ayant plusieurs rôles apparaissent dans le premier rôle
- Groupe « Sans métier » en dernier

### Regroupement par mois
- Un groupe par mois de début de tâche
- Format : « Janvier 2025 », « Février 2025 », etc.
- Trié chronologiquement

## Notes techniques

- Le hook `useGroupedTasks` prend en entrée les tâches filtrées (de `useFilteredTasks`) et le `groupBy` du store, retourne un tableau de `{ key: string, label: string, color?: string, tasks: Task[] }`
- Le `TimelineView` doit adapter le calcul des positions Y pour inclure les headers de groupe (ajouter un offset par groupe)
- Le `GroupBySelector` utilise le pattern toggle group avec Tailwind (pas de lib externe)
- Performance : le regroupement se fait via `useMemo` pour éviter les recalculs inutiles
- Les rôles français sont mappés via un objet constant `ROLE_LABELS`
