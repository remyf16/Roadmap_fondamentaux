---
name: audit-claude
description: Proactively audit and optimize .claude/ configuration. Validates setup, identifies gaps, proposes major improvements, and detects Agent Teams opportunities. Use when checking configuration quality, wanting to maximize Claude Code capabilities, or deploying agent teams.
argument-hint: "[path] - add 'audit-only' to skip recommendations"
allowed-tools: Read, Grep, Glob, Bash, Task, WebFetch
---

# Audit Claude Configuration

**Proactive audit** of `.claude/` directory against official Claude Code documentation. This skill:

1. **Validates** existing configuration against official documentation
2. **Identifies** gaps, invalid fields, anti-patterns, and missing best practices
3. **Proposes** major improvements tailored to the project's tech stack and needs
4. **Detects** Agent Teams opportunities, proposes archetypes, and provides deployment-ready configurations
5. **Leverages** all Claude Code features (hooks, skills, agents, MCP, permissions, Agent Teams, etc.)

## Prerequisites

This skill requires:

- Standard Unix tools: `bash`, `grep`, `find` (available by default)
- Optional: `jq` for JSON validation (graceful fallback if absent)

No external dependencies required.

## Source of Truth

All audit criteria are based exclusively on the official documentation:

- Docs index: `https://code.claude.com/docs/en/claude_code_docs_map.md`
- Settings: `https://code.claude.com/docs/en/settings.md`
- Memory: `https://code.claude.com/docs/en/memory.md`
- Skills: `https://code.claude.com/docs/en/skills.md`
- Hooks: `https://code.claude.com/docs/en/hooks.md`
- MCP: `https://code.claude.com/docs/en/mcp.md`
- Subagents: `https://code.claude.com/docs/en/sub-agents.md`
- Agent Teams: `https://code.claude.com/docs/en/agent-teams.md`
- VSCode Extension: `https://code.claude.com/docs/en/vs-code`
- Plugins: `https://code.claude.com/docs/en/plugins.md`
- Best practices: `https://code.claude.com/docs/en/best-practices.md`

When in doubt, fetch the relevant page to verify a claim before flagging it.

## Workflow

### Phase 1: Discovery

1. Determine the target directory:

   - If `$ARGUMENTS` is provided, use it as the project root
   - Otherwise, use the current working directory
   - The `.claude/` directory should be at `<project_root>/.claude/`
   - Also check `~/.claude/` for user-level configuration

2. Inventory all files in `.claude/`:

   ```
   .claude/
   ├── CLAUDE.md           # Project instructions
   ├── settings.json       # Project settings (shared)
   ├── settings.local.json # Local settings (not committed)
   ├── skills/             # Skills directory
   ├── agents/             # Custom subagents
   ├── rules/              # Modular rules
   ├── hooks/              # Hook scripts
   └── .mcp.json           # MCP servers (project root)
   ```

3. Also check for:

   - `CLAUDE.md` at project root (outside `.claude/`)
   - `CLAUDE.local.md` at project root (should be gitignored)
   - `.mcp.json` at project root (NOT in `.claude/`)
   - Parent directory CLAUDE.md files (monorepo support)

4. Check for monorepo structure:
   - Look for parent directory CLAUDE.md files
   - Check if multiple `.claude/` directories exist in subdirectories
   - Verify package-specific configs don't conflict with root config
   - Ensure consistent naming conventions across packages

### Phase 2: Audit Each Component

Run each audit section from [audit-checklist.md](references/audit-checklist.md). For each component found, validate against the official documentation.

#### 2.1 CLAUDE.md Audit

Check all CLAUDE.md files found (project root, `.claude/`, parent dirs, `~/.claude/`):

- [ ] **Exists**: At least one CLAUDE.md is present
- [ ] **Length**: Not excessively long (risk of instructions being ignored)
- [ ] **Content quality**: Contains actionable instructions, not documentation
- [ ] **No duplication**: Rules not duplicated between CLAUDE.md and `.claude/rules/`
- [ ] **Import syntax**: `@path/to/file` imports are valid and targets exist
- [ ] **Conciseness**: Each line answers "Would removing this cause Claude to make mistakes?"
- [ ] **No obvious defaults**: Doesn't instruct Claude to do things it already does

#### 2.2 Settings Audit

Check `settings.json` and `settings.local.json`:

- [ ] **Valid JSON**: Parseable without errors
- [ ] **Valid fields**: Only recognized top-level keys (see [valid-fields.md](references/valid-fields.md))
- [ ] **Permission rules**: `permissions.allow`, `permissions.deny`, and `permissions.ask` use correct syntax
- [ ] **Permission evaluation**: Understand deny > ask > allow order
- [ ] **Hook configuration**: Hooks follow the official schema (event → matcher → hooks array)
- [ ] **Hook events**: Only valid events used (including `Setup`) (see [valid-fields.md](references/valid-fields.md))
- [ ] **Hook types**: Each hook has valid `type`: "command", "prompt", or "agent"
- [ ] **Hook fields**: Command hooks have `command`, prompt/agent hooks have `prompt`
- [ ] **Hook async**: Only command hooks can use `async: true`
- [ ] **No deprecated fields**: Flag deprecated patterns
- [ ] **Sandbox config**: `sandbox.enabled`, `sandbox.network.allowedDomains` valid (if present)
- [ ] **StatusLine config**: `statusLine.type` is "command", script exists (if present)
- [ ] **Attribution config**: Valid fields in `attribution` (if present)
- [ ] **Model field**: Valid model ID (if present)
- [ ] **settings.local.json not committed**: Check `.gitignore` includes it

#### 2.3 Skills Audit

For each skill in `skills/*/SKILL.md`:

- [ ] **SKILL.md exists**: Each skill directory has a SKILL.md file
- [ ] **Frontmatter present**: YAML frontmatter with `---` delimiters
- [ ] **Recommended fields**: `name` and `description` are present (highly recommended)
- [ ] **Name format**: kebab-case, max 64 characters (or defaults to directory name)
- [ ] **Description quality**: Specific enough for auto-invocation
- [ ] **Valid frontmatter fields**: Only recognized fields used (see [valid-fields.md](references/valid-fields.md))
- [ ] **user-invocable**: Boolean if present (hides from `/` menu when false)
- [ ] **model override**: Valid model name if present ("sonnet", "opus", "haiku")
- [ ] **File length**: SKILL.md under 500 lines (move details to reference files)
- [ ] **References exist**: All `[text](path)` links point to existing files
- [ ] **Side-effects flagged**: Skills with side-effects have `disable-model-invocation: true`
- [ ] **Tool restrictions**: Read-only skills use `allowed-tools`
- [ ] **String substitutions**: $ARGUMENTS, $N used correctly
- [ ] **Dynamic context**: Backtick command execution (e.g., backtick-command-backtick) uses safe commands

#### 2.4 Subagents Audit

For each agent in `agents/*.md`:

- [ ] **Frontmatter present**: YAML frontmatter with `---` delimiters
- [ ] **Required fields**: `name` and `description` are present
- [ ] **Name format**: lowercase letters and hyphens
- [ ] **Valid fields**: Only recognized frontmatter fields (see [valid-fields.md](references/valid-fields.md))
- [ ] **Model value**: If specified, is one of `sonnet`, `opus`, `haiku`, `inherit`
- [ ] **Permission mode**: If specified, is valid (`default`, `acceptEdits`, `dontAsk`, `bypassPermissions`, `plan`)
- [ ] **Tool names**: Tools listed in `tools` or `disallowedTools` are valid tool names
- [ ] **Hooks format**: If hooks defined, follow the standard hook schema
- [ ] **Skills references**: If `skills` field used, referenced skills exist

#### 2.5 Rules Audit

For each rule in `rules/*.md` or `rules/**/*.md`:

- [ ] **Standalone**: Each file is self-contained and reusable
- [ ] **No duplication**: Content not duplicated from CLAUDE.md
- [ ] **Path frontmatter**: If `paths` field used, glob patterns are valid
- [ ] **Single topic**: Each file covers one subject

#### 2.6 Hooks Audit

For hook scripts in `hooks/` and hook configuration in `settings.json`:

- [ ] **Scripts executable**: Hook scripts have execute permission (`chmod +x`)
- [ ] **Shebang present**: Scripts start with `#!/bin/bash` or equivalent
- [ ] **Exit codes correct**: Scripts use `exit 0` (success) or `exit 2` (block)
- [ ] **Input handling**: Scripts read from stdin with proper JSON parsing
- [ ] **Timeout awareness**: No long-running operations (default varies by hook type)
- [ ] **Environment variables**: Use `$CLAUDE_PROJECT_DIR` for project paths
- [ ] **Configuration valid**: Hook entries in settings.json follow correct schema
- [ ] **Hook types**: Valid type ("command", "prompt", or "agent")
- [ ] **Required fields**: Command hooks have `command`, prompt/agent hooks have `prompt`
- [ ] **Async limitations**: Only command hooks use `async: true`, not agent hooks
- [ ] **JSON responses**: Output matches event-specific pattern (PreToolUse, PostToolUse, etc.)
- [ ] **once field**: Only used in skill/agent hooks, not in settings.json

#### 2.7 MCP Audit

Check `.mcp.json` at project root (NOT in `.claude/` directory):

- [ ] **Valid JSON**: Parseable without errors
- [ ] **Correct structure**: Top-level `mcpServers` object
- [ ] **Correct location**: File is at project root, not in `.claude/`
- [ ] **Server format**: Each server has valid fields (`command`, `args`, `env`, `type`, `url`, `headers`)
- [ ] **Server types**: Valid `type` field: "http", "sse", or "stdio"
- [ ] **Stdio servers**: Have `command` field (required)
- [ ] **Remote servers**: Have `type` and `url` fields (required)
- [ ] **Environment expansion**: `${VAR}` or `${VAR:-default}` syntax used correctly
- [ ] **No secrets**: No hardcoded API keys or passwords
- [ ] **Settings.json MCP**: MCP servers in settings.json use correct format
- [ ] **Managed control**: `allowedMcpServers` and `deniedMcpServers` use valid patterns

#### 2.8 Plugins Audit

Check for plugin references in settings and local plugin directories:

- [ ] **Plugin paths valid**: Referenced plugins exist
- [ ] **Plugin structure**: Local plugins have `plugin.json` with valid structure
- [ ] **Plugin.json fields**: Has `name`, `version`, and other required fields
- [ ] **Plugin MCP servers**: Use `${CLAUDE_PLUGIN_ROOT}` for paths
- [ ] **Plugin hooks**: Use `${CLAUDE_PLUGIN_ROOT}` for script paths
- [ ] **Plugin skills**: Reference correct paths within plugin

#### 2.9 Agent Teams Audit

Check for Agent Teams configuration (experimental feature):

- [ ] **Feature flag**: If using agent teams, `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS` is set in `env`
- [ ] **Teammate mode**: `teammateMode` is valid value if present (`in-process`, `tmux`, or `auto`)
- [ ] **tmux availability**: If `teammateMode: "tmux"`, verify tmux is available (macOS/Linux)
- [ ] **iTerm2 setup**: If using iTerm2 split panes, `it2` CLI is installed and Python API enabled
- [ ] **Team cleanup awareness**: Users understand teams must be cleaned up by the lead
- [ ] **Token usage awareness**: Users understand agent teams use significantly more tokens
- [ ] **No orphaned teams**: Check `~/.claude/teams/` for stale team configs
- [ ] **No orphaned tasks**: Check `~/.claude/tasks/` for stale task lists
- [ ] **VSCode limitation**: If using VSCode extension, split pane mode is NOT supported

#### 2.10 VSCode Extension Audit (if applicable)

Check VSCode extension-specific configuration:

- [ ] **Permission mode**: `claudeCode.initialPermissionMode` uses valid value if set
- [ ] **Preferred location**: `claudeCode.preferredLocation` is "sidebar" or "panel" if set
- [ ] **CLI-only features**: Not relying on CLI-only features (split panes, "!" bash, tab completion)
- [ ] **MCP configuration**: MCP servers configured via CLI if needed in VSCode
- [ ] **VSCode version**: VSCode >= 1.98.0 requirement met

#### 2.11 Breaking Changes & Deprecations

Check for deprecated patterns that need migration:

- [ ] **Argument syntax**: No deprecated `$ARGUMENTS.N` syntax (use `$ARGUMENTS[N]` instead)
- [ ] **MCP @-mentions**: No @-mentions for MCP tools (use `/mcp enable` instead)
- [ ] **Installation method**: Not relying on deprecated npm installation
- [ ] **Permission wildcards**: No `Bash(*)` with shell operators (security vulnerability)
- [ ] **Hook once field**: No `once` field in settings.json hooks (only valid in skill/agent hooks)

#### 2.12 Git Setup Audit (MANDATORY)

**This check is MANDATORY for all projects.** Proper git hooks ensure "pixel perfect" commits fully managed by Claude.

- [ ] **Husky installed**: `husky` in devDependencies of package.json
- [ ] **Prepare script**: `"prepare": "husky"` in package.json scripts
- [ ] **Pre-commit hook**: `.husky/pre-commit` exists and runs `lint-staged`
- [ ] **Commit-msg hook**: `.husky/commit-msg` exists and runs `commitlint`
- [ ] **Commitlint config**: `commitlint.config.js` exists with project-specific scopes
- [ ] **Lint-staged config**: `lint-staged` section in package.json with appropriate file patterns
- [ ] **Linters available**: ESLint, Prettier, Ruff (Python), rustfmt (Rust) installed as needed
- [ ] **Claude attribution**: `attribution.commit` / `attribution.pr` set in settings.json
- [ ] **Git permissions**: Git commands properly scoped in permissions (allow safe, ask dangerous)
- [ ] **Git skills**: `/commit`, `/pr`, `/changelog` skills defined or referenced

**Severity**: Missing Husky setup is **Critical** - must be fixed before other recommendations.

**Template**: See Template 11 in suggestion-templates.md for complete setup.

### Phase 3: Cross-Cutting Concerns

- [ ] **Portability**: No hardcoded absolute paths (except in user-level `~/.claude/`)
- [ ] **Git hygiene**: `.gitignore` includes: settings.local.json, CLAUDE.local.md, .env*, *.secret
- [ ] **Consistency**: Naming conventions consistent across skills, agents, rules
- [ ] **No secrets**: No API keys, passwords, or tokens in any config file
- [ ] **No redundancy**: Same instruction not repeated across CLAUDE.md, rules, and skills
- [ ] **Config hierarchy**: Users understand priority (managed > CLI > local > shared > user)
- [ ] **Monorepo support**: Parent CLAUDE.md, multiple .claude/ dirs handled correctly
- [ ] **No conflicts**: No conflicting permissions between settings files
- [ ] **Hook scripts exist**: All referenced hook scripts actually exist
- [ ] **MCP servers reachable**: Referenced MCP servers are configured correctly

### Phase 4: Report

Generate a structured audit report:

```markdown
# Claude Code Configuration Audit

**Project**: [path]
**Date**: [date]
**Source**: Official Claude Code Documentation

## Summary

| Component                 | Status       | Issues | Warnings |
| ------------------------- | ------------ | ------ | -------- |
| CLAUDE.md                 | ✅/⚠️/❌     | N      | N        |
| settings.json             | ✅/⚠️/❌     | N      | N        |
| Skills                    | ✅/⚠️/❌     | N      | N        |
| Agents                    | ✅/⚠️/❌     | N      | N        |
| Rules                     | ✅/⚠️/❌     | N      | N        |
| Hooks                     | ✅/⚠️/❌     | N      | N        |
| MCP                       | ✅/⚠️/❌     | N      | N        |
| Plugins                   | ✅/⚠️/❌     | N      | N        |
| Agent Teams               | ✅/⚠️/❌     | N      | N        |
| VSCode Extension          | ✅/⚠️/❌/N/A | N      | N        |
| Breaking Changes          | ✅/⚠️/❌     | N      | N        |
| **Git Setup (MANDATORY)** | ✅/⚠️/❌     | N      | N        |

**Overall Score**: X/Y checks passed

## Issues (Must Fix)

### [ISSUE-1] Component: Description

- **Severity**: Critical / High / Medium
- **What**: Description of the problem
- **Why**: Why this matters (link to official docs)
- **Fix**: Specific action to resolve

## Warnings (Should Fix)

### [WARN-1] Component: Description

- **What**: Description of the concern
- **Why**: Best practice from official docs
- **Suggestion**: Recommended improvement

## Recommendations (Consider)

### [REC-1] Component: Description

- **What**: Missing feature or improvement opportunity
- **Benefit**: What this would enable
- **How**: Steps to implement

## Missing Components

List components that don't exist but would benefit the project:

- [ ] Component: Why it would help

## Documentation References

Links to relevant official documentation for each issue.
```

**After generating the report**: Always continue to Phase 5 (Proactive Recommendations).

To skip Phase 5, user must explicitly pass "audit-only" or "no-suggestions" in arguments.

### Phase 5: Proactive Recommendations (Default)

**This phase runs by default** to maximize the value of the audit. The goal is to propose improvements that leverage the full power of Claude Code for this specific project.

Based on audit results from Phases 1-4, provide contextual improvement suggestions.

#### 5.1 Detect Project Context

**Automatically analyze the project** to understand its needs:

1. **Tech Stack Detection** (check for presence of):

   - `package.json` → Node.js/npm ecosystem
   - `pyproject.toml` / `requirements.txt` → Python
   - `Cargo.toml` / `src-tauri/` → Rust/Tauri
   - `svelte.config.js` / `*.svelte` → Svelte/SvelteKit
   - `tsconfig.json` → TypeScript
   - `Dockerfile` / `docker-compose.yml` → Docker
   - `.github/workflows/` → GitHub Actions CI/CD

2. **Project Structure Detection**:

   - Monorepo? (multiple `package.json`, `lerna.json`, `pnpm-workspace.yaml`)
   - Frontend/Backend split?
   - Test directories (`tests/`, `__tests__/`, `*.test.*`)

3. **Existing Tooling**:

   - Linting: ESLint, Ruff, Biome, Prettier
   - Testing: Vitest, Jest, Pytest, Playwright
   - Build: Vite, Webpack, esbuild, PyInstaller

4. **Configuration Maturity Assessment**:
   | Level | Criteria |
   |-------|----------|
   | 1 - Beginner | Only CLAUDE.md exists |
   | 2 - Intermediate | CLAUDE.md + settings.json with permissions |
   | 3 - Advanced | + Skills or Agents defined |
   | 4 - Expert | + Hooks, MCP servers, rules |
   | 5 - Master | Full integration: hooks, skills, agents, MCP, plugins, Agent Teams |

5. **Agent Teams Opportunity Assessment**:

   Analyze the project to determine if Agent Teams would add value. Score each criterion (0-2):

   - **Stack complexity**: How many independent tech layers? (1 = 0pts, 2 = 1pt, 3+ = 2pts)
   - **Module independence**: Are there clear file ownership boundaries? (coupled = 0, some = 1, clear = 2)
   - **Review complexity**: Do PRs span multiple domains? (single = 0, multi-file = 1, cross-stack = 2)
   - **Debugging complexity**: Are bugs cross-layer? (simple = 0, multi-component = 1, cross-layer = 2)
   - **Team workflow**: Is parallel work common? (solo = 0, some = 1, frequent = 2)

   **Scoring**: 0-3 = not recommended, 4-7 = beneficial for specific tasks, 8-12 = strongly recommended.

   See [recommendations-guide.md](references/recommendations-guide.md) Section 5.2.6.1 for full scoring table.

#### 5.2 Propose Major Feature Additions

Based on detected context, propose **major improvements** that would transform the development experience:

See [references/recommendations-guide.md](references/recommendations-guide.md) for detailed tables:

- 5.2.1 Missing MCP Servers (by stack)
- 5.2.2 Missing Custom Skills (by workflow)
- 5.2.3 Missing Custom Agents (by role)
- 5.2.4 Missing Hooks (by event)
- 5.2.5 Missing Rules (by scope)
- 5.2.6 Agent Teams: Detection, Proposal & Deployment (archetypes, hooks, spawn prompts)

See [references/recommendations-guide.md](references/recommendations-guide.md) for:

- 5.3 Quick Wins & Contextual Suggestions (example formats)
- 5.4 Configuration Maturity Scoring
- 5.5 Prioritized Action Plan
- 5.6 Templates and Examples (11 templates in [suggestion-templates.md](references/suggestion-templates.md))
- 5.7 Output Format for Phase 5

## Severity Levels

- **Critical**: Configuration is invalid or broken (parse errors, missing required fields)
- **High**: Configuration works but has security or correctness issues
- **Medium**: Configuration is valid but doesn't follow best practices
- **Low**: Minor improvements, style issues, or missing optional features

## Important Notes

- This audit is read-only. No files are modified.
- When uncertain about a field or feature, fetch the official documentation to verify.
- Flag items as "unverified" if the documentation is ambiguous.
- Always provide the official docs URL for each finding.
