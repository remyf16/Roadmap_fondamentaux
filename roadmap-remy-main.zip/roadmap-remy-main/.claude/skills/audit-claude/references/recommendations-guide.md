# Proactive Recommendations Guide

Detailed tables for Phase 5 recommendations, extracted from SKILL.md.

---

## 5.2.1 Missing MCP Servers (by stack)

| Stack      | Recommended MCP Server         | Benefit                                    |
| ---------- | ------------------------------ | ------------------------------------------ |
| Svelte     | `svelte`                       | Svelte 5 runes, SvelteKit docs on demand   |
| Python     | `context7` (Pydantic, FastAPI) | Up-to-date library documentation           |
| Database   | `sqlite`, `postgres`           | Query execution, schema introspection      |
| GitHub     | `github`                       | PR/Issue management without leaving Claude |
| Filesystem | `filesystem`                   | Enhanced file operations                   |

## 5.2.2 Missing Custom Skills (by workflow)

| Workflow      | Suggested Skill                | Purpose                    |
| ------------- | ------------------------------ | -------------------------- |
| Git           | `/commit`, `/pr`, `/changelog` | Streamlined git operations |
| Testing       | `/test-run`, `/test-watch`     | Quick test execution       |
| Deployment    | `/deploy`, `/release`          | Automated deployment       |
| Code Review   | `/review`, `/security-scan`    | Quality gates              |
| Documentation | `/docs-update`, `/api-docs`    | Auto-documentation         |

## 5.2.3 Missing Custom Agents (by role)

| Role        | Suggested Agent      | Specialization                    |
| ----------- | -------------------- | --------------------------------- |
| Security    | `security-auditor`   | OWASP checks, dependency audit    |
| Performance | `perf-analyzer`      | Bundle size, render time analysis |
| Test Writer | `test-generator`     | Generate tests for new code       |
| Refactorer  | `refactor-helper`    | Safe code transformations         |
| Debugger    | `debug-investigator` | Trace issues through stack        |

## 5.2.4 Missing Hooks (by event)

| Event                      | Suggested Hook     | Purpose                               |
| -------------------------- | ------------------ | ------------------------------------- |
| `PreToolUse(Edit\|Write)`  | Lint check         | Catch errors before writes            |
| `PostToolUse(Edit\|Write)` | Run tests          | Verify changes immediately            |
| `Stop`                     | Commit reminder    | Prompt for commits after work         |
| `SessionStart`             | Git status context | Add current branch/changes to context |
| `UserPromptSubmit`         | Project context    | Inject relevant project info          |

## 5.2.5 Missing Rules (by scope)

| Scope                         | Suggested Rule           | Purpose                                   |
| ----------------------------- | ------------------------ | ----------------------------------------- |
| `paths: "src/**/*.ts"`        | `typescript-conventions` | TS-specific patterns, strict types        |
| `paths: "src/**/*.svelte"`    | `svelte-patterns`        | Runes, component structure, accessibility |
| `paths: "src_python/**/*.py"` | `python-standards`       | Pydantic 2, type hints, docstrings        |
| `paths: "src-tauri/**/*.rs"`  | `rust-tauri-patterns`    | IPC commands, error handling              |
| `paths: "tests/**/*"`         | `testing-guidelines`     | Test structure, mocking, assertions       |
| `paths: "*.config.*"`         | `config-conventions`     | Configuration file standards              |
| `paths: "docs/**/*.md"`       | `documentation-style`    | Markdown formatting, structure            |

**Rule Benefits**:

- Scoped instructions that only apply to matching files
- Reduce CLAUDE.md bloat by moving specialized rules out
- Automatic activation when working in specific directories
- Reusable across projects

## 5.2.6 Agent Teams: Detection, Proposal & Deployment

Agent Teams are an experimental feature enabling multiple independent Claude Code instances working in parallel with shared task lists and inter-agent messaging. This section guides the auditor through detecting opportunities, proposing configurations, and providing deployment-ready templates.

### 5.2.6.1 Detection Criteria

Analyze the project to determine if Agent Teams would add value. Score each criterion (0-2 points):

| Criterion                | 0 pts (No benefit)           | 1 pt (Moderate)                 | 2 pts (Strong fit)                             |
| ------------------------ | ---------------------------- | ------------------------------- | ---------------------------------------------- |
| **Stack complexity**     | Single language/framework    | 2 languages or frontend+backend | 3+ languages/layers (e.g., Svelte+Python+Rust) |
| **Module independence**  | Tightly coupled, single file | Some independent modules        | Clear module boundaries, separate dirs         |
| **Test coverage needs**  | Minimal tests                | Standard unit tests             | Multi-layer testing (unit+integration+e2e)     |
| **Review complexity**    | Simple PRs, single domain    | Multi-file PRs                  | Cross-stack PRs needing domain expertise       |
| **Debugging complexity** | Simple, reproducible bugs    | Multi-component issues          | Race conditions, cross-layer bugs              |
| **Team workflow**        | Solo developer, sequential   | Small team, some parallelism    | Multi-domain work, frequent parallel tasks     |

**Scoring:**

- **0-3 points**: Agent Teams not recommended (use subagents instead)
- **4-7 points**: Agent Teams beneficial for specific tasks (propose targeted use)
- **8-12 points**: Agent Teams strongly recommended (propose full setup)

### 5.2.6.2 Team Archetypes

Based on project analysis, propose one or more team archetypes:

#### Archetype A: Multi-Perspective Code Review

**Best for**: Cross-stack PRs, security-sensitive code, pre-release review

| Teammate      | Focus Area                             | File Ownership               |
| ------------- | -------------------------------------- | ---------------------------- |
| Security      | OWASP, PII handling, crypto, injection | All files (read-only review) |
| Performance   | Bundle size, render time, query perf   | All files (read-only review) |
| Test Coverage | Missing tests, edge cases, assertions  | All files (read-only review) |
| Compliance    | RGPD, AI Act, legal requirements       | All files (read-only review) |

**Spawn prompt example:**

```
Create an agent team to review the changes on this branch. Spawn reviewers:
- Security reviewer: check for OWASP top 10, PII leaks, crypto issues
- Performance reviewer: analyze render performance, bundle impact, query efficiency
- Test coverage reviewer: identify untested paths, missing edge cases
- Compliance reviewer: verify RGPD compliance, AI Act requirements
Have them share findings and challenge each other. Synthesize a final report.
```

#### Archetype B: Parallel Feature Development

**Best for**: New features spanning frontend + backend + tests

| Teammate    | Focus Area                      | File Ownership                |
| ----------- | ------------------------------- | ----------------------------- |
| Frontend    | UI components, routes, stores   | `src/` (Svelte/TS files)      |
| Backend     | API endpoints, models, services | `src_python/` or `src-tauri/` |
| Test Writer | Unit + integration tests        | `tests/` directory            |

**Spawn prompt example:**

```
Create an agent team to implement [feature]. Break it into:
- Frontend teammate: build the UI components and routes in src/
- Backend teammate: implement the API and models in src_python/
- Test teammate: write tests for both layers in tests/
Each teammate owns their directory. Coordinate via task list.
Wait for backend API to be done before frontend integrates.
```

#### Archetype C: Debugging Investigation

**Best for**: Complex bugs with unclear root cause, cross-layer issues

| Teammate         | Focus Area                          | File Ownership          |
| ---------------- | ----------------------------------- | ----------------------- |
| Hypothesis 1     | Frontend rendering / state issue    | Read-only investigation |
| Hypothesis 2     | Backend logic / data issue          | Read-only investigation |
| Hypothesis 3     | IPC / communication issue           | Read-only investigation |
| Devil's Advocate | Challenge other teammates' findings | Read-only investigation |

**Spawn prompt example:**

```
Users report [bug description]. Create a team to investigate:
- Teammate 1: investigate if this is a frontend state/rendering issue
- Teammate 2: investigate if this is a backend data/logic issue
- Teammate 3: investigate if this is an IPC communication issue
- Devil's advocate: actively challenge each theory with counter-evidence
Have them debate and converge on the root cause. Update findings.
```

#### Archetype D: Cross-Stack Refactoring

**Best for**: Large-scale refactoring spanning multiple layers

| Teammate     | Focus Area                        | File Ownership                |
| ------------ | --------------------------------- | ----------------------------- |
| Architect    | Plan changes, validate interfaces | Read-only (plan mode)         |
| Frontend Dev | Implement frontend changes        | `src/` files                  |
| Backend Dev  | Implement backend changes         | `src_python/` or `src-tauri/` |
| Test Updater | Update/create tests for new code  | `tests/` files                |

**Spawn prompt example:**

```
Refactor [module] across the stack. Create a team:
- Architect: plan the refactoring, define interfaces. Require plan approval.
- Frontend dev: implement frontend changes after architect approval
- Backend dev: implement backend changes after architect approval
- Test updater: update tests after implementations are done
Use task dependencies: architect plan → frontend+backend (parallel) → tests.
```

#### Archetype E: Documentation & Research

**Best for**: Library evaluation, architecture decisions, doc updates

| Teammate     | Focus Area                             | File Ownership |
| ------------ | -------------------------------------- | -------------- |
| Researcher 1 | Library/framework option A             | Read-only      |
| Researcher 2 | Library/framework option B             | Read-only      |
| Synthesizer  | Compare findings, write recommendation | `docs/` files  |

### 5.2.6.3 Configuration Checklist

When proposing Agent Teams, ensure all prerequisites are met:

| #   | Prerequisite                                   | Required | How to Check                               |
| --- | ---------------------------------------------- | -------- | ------------------------------------------ |
| C1  | Feature flag enabled in settings.json          | Yes      | `env.CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS` |
| C2  | `teammateMode` set appropriately               | Yes      | Match to user's terminal environment       |
| C3  | tmux installed (if using split panes)          | If tmux  | `which tmux`                               |
| C4  | iTerm2 Python API enabled (if using iTerm2)    | If iTerm | iTerm2 Settings → General → Magic          |
| C5  | Permissions pre-approved for common operations | Rec.     | Reduces permission prompt interruptions    |
| C6  | CLAUDE.md provides project context             | Rec.     | Teammates load CLAUDE.md automatically     |
| C7  | File ownership boundaries clearly defined      | Rec.     | Prevents two teammates editing same file   |
| C8  | Task dependencies identified                   | Rec.     | Enables proper task blocking/unblocking    |
| C9  | Quality gate hooks configured                  | Opt.     | TeammateIdle, TaskCompleted hooks          |
| C10 | Token budget awareness documented              | Rec.     | Each teammate uses separate context window |

### 5.2.6.4 Deployment Guidance

#### Task Sizing

| Size       | Description                  | Recommendation           |
| ---------- | ---------------------------- | ------------------------ |
| Too small  | < 5 min work, trivial change | Use single session       |
| Too large  | > 2 hours, many dependencies | Break into smaller tasks |
| Just right | 15-60 min, clear deliverable | Ideal for teammate       |

**Tip**: Aim for 5-6 tasks per teammate. This keeps everyone productive and lets the lead reassign work if someone gets stuck.

#### File Ownership Rules

- **Never** have two teammates edit the same file simultaneously
- Break work by directory/module, not by feature aspect
- Use read-only investigation for debugging teams
- Assign file ownership explicitly in spawn prompts

#### Quality Gate Hooks

Configure hooks to enforce quality when teammates finish work:

- **TeammateIdle**: Runs when a teammate finishes and idles. Exit code 2 sends feedback and keeps the teammate working.
- **TaskCompleted**: Runs when a task is marked complete. Exit code 2 blocks completion and sends feedback.

See Template 9 in suggestion-templates.md for hook configuration.

#### Cleanup Protocol

1. Ask teammates to shut down gracefully
2. Wait for all teammates to stop
3. Ask the lead to clean up: `Clean up the team`
4. **Always use the lead** for cleanup (teammates should not run cleanup)

### 5.2.6.5 Anti-Patterns (When NOT to Use Teams)

| Anti-Pattern                 | Why It Fails                                  | Use Instead         |
| ---------------------------- | --------------------------------------------- | ------------------- |
| Sequential dependent tasks   | Teammates block on each other, no parallelism | Single session      |
| Same-file concurrent edits   | Overwrites and conflicts                      | Subagents or serial |
| Simple, focused tasks        | Coordination overhead exceeds benefit         | Subagents           |
| Tasks needing lead's history | Teammates don't inherit lead's conversation   | Single session      |
| Cost-sensitive work          | Each teammate uses full context window        | Subagents (cheaper) |
| Nested team coordination     | Teammates can't spawn their own teams         | Flat team structure |

### 5.2.6.6 Report Format

When proposing Agent Teams in the audit report:

```markdown
### Agent Teams Assessment

**Score**: X/12 ([Not Recommended / Beneficial for Specific Tasks / Strongly Recommended])

**Detected Patterns**:

- [Pattern 1]: [Why teams help]
- [Pattern 2]: [Why teams help]

**Recommended Archetypes**:

1. [Archetype Name] - [When to use]
   - Teammates: [list]
   - Spawn prompt: [template reference]

**Prerequisites**:

- [ ] Feature flag enabled
- [ ] teammateMode configured
- [ ] Permissions pre-approved
- [ ] Quality gate hooks set up

**Estimated Token Impact**: [X teammates × context window = significantly more tokens]

**Template**: See Template 9 in suggestion-templates.md
```

**Note for VSCode users**: Agent Teams work in `in-process` mode only (no split panes).

---

## 5.3 Quick Wins & Contextual Suggestions

For each category, provide actionable recommendations with references to [suggestion-templates.md](suggestion-templates.md):

### Quick Wins (Impact: High, Effort: Low)

Example format:

```markdown
### [QUICKWIN-1] Enable sandbox for Bash commands

**Context**: You have 5 Bash permissions but no sandbox configuration
**Impact**: Improved security, prevent accidental destructive commands
**Effort**: 5 minutes
**Template**: See Template 4 in suggestion-templates.md
```

### Missing Beneficial Components

Example format:

```markdown
### [MISSING-1] No PreToolUse validation hooks

**Opportunity**: Add automatic validation before file modifications
**Benefit**: Catch errors (linting, type checking) before commits
**Template**: See Template 1 in suggestion-templates.md
```

### Advanced Patterns

Example format:

```markdown
### [PATTERN-1] Skills could benefit from context isolation

**Skills affected**: complex-analysis, multi-step-tasks
**Solution**: Use `context: fork` for isolation
**Template**: See Template 6 in suggestion-templates.md
```

### Stack-Specific Recommendations

Example format:

```markdown
### [STACK-1] Svelte project detected - Consider svelte MCP server

**Detected**: svelte.config.js, src/routes/, .svelte files
**Benefit**: Instant Svelte 5 documentation access
**Template**: See Template 7 in suggestion-templates.md
```

## 5.4 Configuration Maturity Scoring

Provide a maturity score (1-5) with next steps:

```markdown
## Configuration Maturity: [X]/5 ([Level])

**Levels**: 1=Beginner, 2=Intermediate, 3=Advanced, 4=Expert, 5=Master

### Current Strengths

- [List 3-5 strengths from audit]

### Next Level: [Level+1]

Prioritized improvements:

1. [High priority item] (Time: Xmin) - Template ref
2. [Medium priority item] (Time: Xmin) - Template ref
3. [Low priority item] (Time: Xmin) - Template ref

**Estimated time**: XX minutes
**Expected score after**: [X+1]/5
```

## 5.5 Prioritized Action Plan

Generate concrete action plan based on suggestions:

```markdown
## Recommended Action Plan

### This Week (High Impact)

- [Item 1] -> [time] -> [ref]
- [Item 2] -> [time] -> [ref]
  **Total**: XX min, [impact summary]

### Next Sprint (Medium Impact)

- [Item 3] -> [time] -> [ref]
  **Total**: XX min, [impact summary]

### Future (Low Priority)

- [Optional enhancements]
```

## 5.6 Templates and Examples

Reference ready-to-use templates from [suggestion-templates.md](suggestion-templates.md):

- Template 1: Lint-on-Edit Hook
- Template 2: Run Tests After Code Changes
- Template 3: Git Status StatusLine
- Template 4: Sandbox Configuration
- Template 5: Permission Patterns for Sensitive Operations
- Template 6: Skill with Context Isolation
- Template 7: Project-Specific MCP Server
- Template 8: Attribution for Git Commits
- Template 9: Agent Teams Configuration
- Template 10: Scoped Rules Configuration
- Template 11: Husky Git Integration (MANDATORY)

## 5.7 Output Format for Phase 5

Append to Phase 4 audit report:

```markdown
---

# Proactive Recommendations

*Based on project analysis and audit results*

## Project Context
- **Tech Stack**: [Detected: Svelte, Tauri, Python, etc.]
- **Configuration Maturity**: [X]/5 ([Level])
- **Environment**: [CLI / VSCode Extension]

## Git Setup (MANDATORY - Fix First)
[From 2.12 - if any G1-G4 checks failed, this section appears first]
**Template**: See Template 11 in suggestion-templates.md

## Major Additions Recommended

### MCP Servers to Add
[From 5.2.1 - stack-specific recommendations]

### Custom Skills to Create
[From 5.2.2 - workflow-specific recommendations]

### Custom Agents to Define
[From 5.2.3 - role-specific recommendations]

### Hooks to Implement
[From 5.2.4 - event-specific recommendations]

### Rules to Add
[From 5.2.5 - scope-specific conventions]

### Agent Teams Assessment
[From 5.2.6 - detection score, recommended archetypes, configuration, deployment prompts]

## Quick Wins
[High impact, low effort improvements]

## Maturity Roadmap
[From 5.4 - path to next level]

## Prioritized Action Plan
[From 5.5 - time-boxed implementation plan]

## Templates
See [suggestion-templates.md](suggestion-templates.md) for ready-to-use configurations.

---

_All suggestions based on official Claude Code documentation (Feb 2026)._
```
