# Audit Checklist

Complete checklist for auditing a `.claude/` directory. Each item references official documentation.

---

## 1. Project Structure

| #   | Check                                                                        | Severity | Source                                                                 |
| --- | ---------------------------------------------------------------------------- | -------- | ---------------------------------------------------------------------- |
| S1  | `.claude/` directory exists                                                  | Critical | [memory.md](https://code.claude.com/docs/en/memory.md)                 |
| S2  | At least one CLAUDE.md exists (root or `.claude/`)                           | High     | [memory.md](https://code.claude.com/docs/en/memory.md)                 |
| S3  | `.gitignore` includes: settings.local.json, CLAUDE.local.md, .env*, *.secret | High     | [best-practices.md](https://code.claude.com/docs/en/best-practices.md) |
| S4  | No sensitive files committed (`.env`, credentials, API keys)                 | Critical | [best-practices.md](https://code.claude.com/docs/en/best-practices.md) |
| S5  | Directory structure follows conventions                                      | Low      | [best-practices.md](https://code.claude.com/docs/en/best-practices.md) |

---

## 2. CLAUDE.md

| #   | Check                                                 | Severity | Source                                                                 |
| --- | ----------------------------------------------------- | -------- | ---------------------------------------------------------------------- |
| M1  | File is concise (not a documentation dump)            | High     | [best-practices.md](https://code.claude.com/docs/en/best-practices.md) |
| M2  | Contains actionable instructions (commands, rules)    | Medium   | [best-practices.md](https://code.claude.com/docs/en/best-practices.md) |
| M3  | No content Claude can infer from code                 | Medium   | [best-practices.md](https://code.claude.com/docs/en/best-practices.md) |
| M4  | No standard language conventions Claude already knows | Low      | [best-practices.md](https://code.claude.com/docs/en/best-practices.md) |
| M5  | `@path` imports point to existing files               | High     | [memory.md](https://code.claude.com/docs/en/memory.md)                 |
| M6  | No duplication with files in `.claude/rules/`         | Medium   | [memory.md](https://code.claude.com/docs/en/memory.md)                 |
| M7  | Instructions use imperative form                      | Low      | [best-practices.md](https://code.claude.com/docs/en/best-practices.md) |
| M8  | No file-by-file descriptions of the codebase          | Medium   | [best-practices.md](https://code.claude.com/docs/en/best-practices.md) |
| M9  | CLAUDE.local.md is in .gitignore (if exists)          | High     | [memory.md](https://code.claude.com/docs/en/memory.md)                 |

---

## 3. settings.json

| #   | Check                                                          | Severity | Source                                                     |
| --- | -------------------------------------------------------------- | -------- | ---------------------------------------------------------- |
| J1  | Valid JSON syntax                                              | Critical | [settings.md](https://code.claude.com/docs/en/settings.md) |
| J2  | Only recognized top-level keys                                 | High     | [settings.md](https://code.claude.com/docs/en/settings.md) |
| J3  | `permissions.allow` entries use valid syntax                   | High     | [settings.md](https://code.claude.com/docs/en/settings.md) |
| J4  | `permissions.deny` entries use valid syntax                    | High     | [settings.md](https://code.claude.com/docs/en/settings.md) |
| J5  | Bash permission patterns use correct format: `Bash(command:*)` | Medium   | [settings.md](https://code.claude.com/docs/en/settings.md) |
| J6  | Hook events are valid event names                              | High     | [hooks.md](https://code.claude.com/docs/en/hooks.md)       |
| J7  | Hook entries have correct structure (matcher, hooks array)     | High     | [hooks.md](https://code.claude.com/docs/en/hooks.md)       |
| J8  | Hook commands have `type` field (`"command"` or `"prompt"`)    | High     | [hooks.md](https://code.claude.com/docs/en/hooks.md)       |
| J9  | Command hooks have `command` field                             | High     | [hooks.md](https://code.claude.com/docs/en/hooks.md)       |
| J10 | Prompt hooks have `prompt` field                               | High     | [hooks.md](https://code.claude.com/docs/en/hooks.md)       |
| J11 | No deprecated hook fields (`decision`, `reason` in PreToolUse) | Medium   | [hooks.md](https://code.claude.com/docs/en/hooks.md)       |
| J12 | `env` field contains valid environment variable definitions    | Low      | [settings.md](https://code.claude.com/docs/en/settings.md) |
| J13 | `sandbox.enabled` is boolean (if present)                      | Medium   | [settings.md](https://code.claude.com/docs/en/settings.md) |
| J14 | `sandbox.network.allowedDomains` uses valid patterns           | Medium   | [settings.md](https://code.claude.com/docs/en/settings.md) |
| J15 | `statusLine.type` is "command" (if present)                    | High     | [settings.md](https://code.claude.com/docs/en/settings.md) |
| J16 | `statusLine.command` script exists (if present)                | High     | [settings.md](https://code.claude.com/docs/en/settings.md) |
| J17 | `attribution` config uses valid fields (if present)            | Low      | [settings.md](https://code.claude.com/docs/en/settings.md) |
| J18 | `model` field is valid model ID (if present)                   | Medium   | [settings.md](https://code.claude.com/docs/en/settings.md) |
| J19 | `permissions.defaultMode` is valid value (if present)          | Medium   | [settings.md](https://code.claude.com/docs/en/settings.md) |
| J20 | `permissions.ask` entries use valid syntax (if present)        | High     | [settings.md](https://code.claude.com/docs/en/settings.md) |

---

## 4. Skills

| #   | Check                                                                       | Severity | Source                                                 |
| --- | --------------------------------------------------------------------------- | -------- | ------------------------------------------------------ |
| K1  | Each skill directory contains `SKILL.md`                                    | Critical | [skills.md](https://code.claude.com/docs/en/skills.md) |
| K2  | SKILL.md has YAML frontmatter                                               | Critical | [skills.md](https://code.claude.com/docs/en/skills.md) |
| K3  | Frontmatter has `name` field                                                | Critical | [skills.md](https://code.claude.com/docs/en/skills.md) |
| K4  | Frontmatter has `description` field                                         | Critical | [skills.md](https://code.claude.com/docs/en/skills.md) |
| K5  | `name` is kebab-case, max 64 characters                                     | Medium   | [skills.md](https://code.claude.com/docs/en/skills.md) |
| K6  | `description` is specific enough for auto-invocation                        | Medium   | [skills.md](https://code.claude.com/docs/en/skills.md) |
| K7  | Only valid frontmatter fields used                                          | High     | [skills.md](https://code.claude.com/docs/en/skills.md) |
| K8  | SKILL.md is under 500 lines                                                 | Medium   | Best practice                                          |
| K9  | Internal file references (`[text](path)`) point to existing files           | High     | General                                                |
| K10 | Skills with side-effects have `disable-model-invocation: true`              | High     | [skills.md](https://code.claude.com/docs/en/skills.md) |
| K11 | Read-only skills restrict tools with `allowed-tools`                        | Medium   | [skills.md](https://code.claude.com/docs/en/skills.md) |
| K12 | `context: fork` used when skill needs isolated context                      | Low      | [skills.md](https://code.claude.com/docs/en/skills.md) |
| K13 | Hooks in skill frontmatter use valid events (PreToolUse, PostToolUse, Stop) | High     | [hooks.md](https://code.claude.com/docs/en/hooks.md)   |
| K14 | `user-invocable` field is boolean (if present)                              | Medium   | [skills.md](https://code.claude.com/docs/en/skills.md) |
| K15 | `model` field is valid model name (if present)                              | Medium   | [skills.md](https://code.claude.com/docs/en/skills.md) |
| K16 | String substitutions ($ARGUMENTS, $N) use correct syntax                    | Low      | [skills.md](https://code.claude.com/docs/en/skills.md) |
| K17 | Dynamic context (backtick command execution) uses safe commands             | Low      | [skills.md](https://code.claude.com/docs/en/skills.md) |

---

## 5. Subagents

| #   | Check                                                     | Severity | Source                                                         |
| --- | --------------------------------------------------------- | -------- | -------------------------------------------------------------- |
| A1  | Agent files have `.md` extension                          | Critical | [sub-agents.md](https://code.claude.com/docs/en/sub-agents.md) |
| A2  | YAML frontmatter present                                  | Critical | [sub-agents.md](https://code.claude.com/docs/en/sub-agents.md) |
| A3  | `name` field present (lowercase, hyphens)                 | Critical | [sub-agents.md](https://code.claude.com/docs/en/sub-agents.md) |
| A4  | `description` field present                               | Critical | [sub-agents.md](https://code.claude.com/docs/en/sub-agents.md) |
| A5  | Only valid frontmatter fields used                        | High     | [sub-agents.md](https://code.claude.com/docs/en/sub-agents.md) |
| A6  | `model` is valid: `sonnet`, `opus`, `haiku`, or `inherit` | High     | [sub-agents.md](https://code.claude.com/docs/en/sub-agents.md) |
| A7  | `permissionMode` is valid                                 | High     | [sub-agents.md](https://code.claude.com/docs/en/sub-agents.md) |
| A8  | Tools in `tools` field are valid tool names               | Medium   | [sub-agents.md](https://code.claude.com/docs/en/sub-agents.md) |
| A9  | Tools in `disallowedTools` are valid tool names           | Medium   | [sub-agents.md](https://code.claude.com/docs/en/sub-agents.md) |
| A10 | Skills in `skills` field reference existing skills        | High     | [sub-agents.md](https://code.claude.com/docs/en/sub-agents.md) |
| A11 | Hooks use valid events (PreToolUse, PostToolUse, Stop)    | High     | [sub-agents.md](https://code.claude.com/docs/en/sub-agents.md) |
| A12 | Body contains system prompt                               | Medium   | [sub-agents.md](https://code.claude.com/docs/en/sub-agents.md) |
| A13 | `bypassPermissions` used with caution and justified       | High     | [sub-agents.md](https://code.claude.com/docs/en/sub-agents.md) |

---

## 6. Rules

| #   | Check                                            | Severity | Source                                                 |
| --- | ------------------------------------------------ | -------- | ------------------------------------------------------ |
| R1  | Each file covers a single topic                  | Medium   | [memory.md](https://code.claude.com/docs/en/memory.md) |
| R2  | Files are self-contained and reusable            | Medium   | [memory.md](https://code.claude.com/docs/en/memory.md) |
| R3  | `paths` frontmatter uses valid glob patterns     | High     | [memory.md](https://code.claude.com/docs/en/memory.md) |
| R4  | No duplication with CLAUDE.md content            | Medium   | [memory.md](https://code.claude.com/docs/en/memory.md) |
| R5  | Files use `.md` extension                        | Low      | Convention                                             |
| R6  | No excessively long rule files                   | Low      | Best practice                                          |
| R7  | Glob patterns in `paths` are syntactically valid | Medium   | [memory.md](https://code.claude.com/docs/en/memory.md) |
| R8  | Glob patterns match at least one file in project | Low      | [memory.md](https://code.claude.com/docs/en/memory.md) |

---

## 7. Hooks

| #   | Check                                                           | Severity | Source                                                           |
| --- | --------------------------------------------------------------- | -------- | ---------------------------------------------------------------- |
| H1  | Hook scripts are executable (`chmod +x`)                        | Critical | [hooks.md](https://code.claude.com/docs/en/hooks.md)             |
| H2  | Scripts have shebang line (`#!/bin/bash` or similar)            | High     | [hooks.md](https://code.claude.com/docs/en/hooks.md)             |
| H3  | Scripts read input from stdin                                   | High     | [hooks.md](https://code.claude.com/docs/en/hooks.md)             |
| H4  | Scripts use exit code 0 (success) or 2 (block)                  | High     | [hooks.md](https://code.claude.com/docs/en/hooks.md)             |
| H5  | No network operations in validation hooks                       | Medium   | [hooks.md](https://code.claude.com/docs/en/hooks.md)             |
| H6  | Scripts complete within timeout (default 60s)                   | Medium   | [hooks.md](https://code.claude.com/docs/en/hooks.md)             |
| H7  | Scripts use `$CLAUDE_PROJECT_DIR` for project paths             | Medium   | [hooks.md](https://code.claude.com/docs/en/hooks.md)             |
| H8  | Error messages written to stderr                                | Medium   | [hooks.md](https://code.claude.com/docs/en/hooks.md)             |
| H9  | Scripts handle missing tools gracefully                         | Low      | Best practice                                                    |
| H10 | Hook `type` is valid: "command", "prompt", or "agent"           | High     | [hooks.md](https://code.claude.com/docs/en/hooks.md)             |
| H11 | Command hooks have `command` field                              | High     | [hooks.md](https://code.claude.com/docs/en/hooks.md)             |
| H12 | Prompt/agent hooks have `prompt` field                          | High     | [hooks.md](https://code.claude.com/docs/en/hooks.md)             |
| H13 | Agent hooks don't use `async: true` (not supported)             | Medium   | [hooks.md](https://code.claude.com/docs/en/hooks.md)             |
| H14 | Hook JSON output matches event-specific pattern                 | Medium   | [hooks-guide.md](https://code.claude.com/docs/en/hooks-guide.md) |
| H15 | `once: true` only used in skill/agent hooks (not settings.json) | Medium   | [hooks.md](https://code.claude.com/docs/en/hooks.md)             |

---

## 8. MCP Configuration

| #   | Check                                                          | Severity | Source                                                     |
| --- | -------------------------------------------------------------- | -------- | ---------------------------------------------------------- |
| P1  | `.mcp.json` is valid JSON                                      | Critical | [mcp.md](https://code.claude.com/docs/en/mcp.md)           |
| P2  | Top-level key is `mcpServers`                                  | Critical | [mcp.md](https://code.claude.com/docs/en/mcp.md)           |
| P3  | Each server has valid fields                                   | High     | [mcp.md](https://code.claude.com/docs/en/mcp.md)           |
| P4  | Stdio servers have `command` field                             | High     | [mcp.md](https://code.claude.com/docs/en/mcp.md)           |
| P5  | Remote servers have `type` and `url` fields                    | High     | [mcp.md](https://code.claude.com/docs/en/mcp.md)           |
| P6  | No hardcoded secrets in config                                 | Critical | [mcp.md](https://code.claude.com/docs/en/mcp.md)           |
| P7  | Environment variables use `${VAR}` or `${VAR:-default}` syntax | Medium   | [mcp.md](https://code.claude.com/docs/en/mcp.md)           |
| P8  | Server names follow naming conventions                         | Low      | Convention                                                 |
| P9  | `.mcp.json` is at project root (not in .claude/)               | Medium   | [mcp.md](https://code.claude.com/docs/en/mcp.md)           |
| P10 | MCP servers in settings.json use correct mcpServers format     | High     | [settings.md](https://code.claude.com/docs/en/settings.md) |
| P11 | `allowedMcpServers` uses valid filter patterns (if present)    | High     | [settings.md](https://code.claude.com/docs/en/settings.md) |
| P12 | `deniedMcpServers` uses valid filter patterns (if present)     | High     | [settings.md](https://code.claude.com/docs/en/settings.md) |
| P13 | Server `type` field is valid: "http", "sse", or "stdio"        | High     | [mcp.md](https://code.claude.com/docs/en/mcp.md)           |

---

## 9. Plugins

| #   | Check                                                     | Severity | Source                                                   |
| --- | --------------------------------------------------------- | -------- | -------------------------------------------------------- |
| L1  | Plugin directories have `plugin.json`                     | Critical | [plugins.md](https://code.claude.com/docs/en/plugins.md) |
| L2  | `plugin.json` has valid structure (name, version, etc.)   | High     | [plugins.md](https://code.claude.com/docs/en/plugins.md) |
| L3  | Plugin MCP servers use `${CLAUDE_PLUGIN_ROOT}` for paths  | Medium   | [plugins.md](https://code.claude.com/docs/en/plugins.md) |
| L4  | Plugin hooks use `${CLAUDE_PLUGIN_ROOT}` for script paths | Medium   | [plugins.md](https://code.claude.com/docs/en/plugins.md) |
| L5  | Plugin skills reference correct paths                     | High     | [plugins.md](https://code.claude.com/docs/en/plugins.md) |

---

## 10. Agent Teams (Experimental)

| #   | Check                                                                                   | Severity | Source                                                           |
| --- | --------------------------------------------------------------------------------------- | -------- | ---------------------------------------------------------------- |
| T1  | Feature flag set if using agent teams (`CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` in env) | High     | [agent-teams.md](https://code.claude.com/docs/en/agent-teams.md) |
| T2  | `teammateMode` is valid value if present (`in-process`, `tmux`, or `auto`)              | High     | [agent-teams.md](https://code.claude.com/docs/en/agent-teams.md) |
| T3  | tmux is available if `teammateMode: "tmux"` (macOS/Linux)                               | Medium   | [agent-teams.md](https://code.claude.com/docs/en/agent-teams.md) |
| T4  | iTerm2 Python API enabled if using iTerm2 split panes                                   | Medium   | [agent-teams.md](https://code.claude.com/docs/en/agent-teams.md) |
| T5  | No orphaned team configs in `~/.claude/teams/`                                          | Low      | [agent-teams.md](https://code.claude.com/docs/en/agent-teams.md) |
| T6  | No orphaned task lists in `~/.claude/tasks/`                                            | Low      | [agent-teams.md](https://code.claude.com/docs/en/agent-teams.md) |
| T7  | Users understand teams must be cleaned up by the lead                                   | Low      | [agent-teams.md](https://code.claude.com/docs/en/agent-teams.md) |
| T8  | Users understand agent teams use significantly more tokens                              | Low      | [agent-teams.md](https://code.claude.com/docs/en/agent-teams.md) |
| T9  | Split pane mode not used in unsupported terminals (VS Code, Windows Terminal, Ghostty)  | Medium   | [agent-teams.md](https://code.claude.com/docs/en/agent-teams.md) |

### 10b. Agent Teams Readiness & Opportunity Detection

| #   | Check                                                                                 | Severity | Source                                                           |
| --- | ------------------------------------------------------------------------------------- | -------- | ---------------------------------------------------------------- |
| T10 | Project has 2+ independent tech layers (frontend/backend/tests/infra)                 | Info     | Detection criteria (5.2.6.1)                                     |
| T11 | Project modules have clear file ownership boundaries (separate directories per layer) | Info     | Detection criteria (5.2.6.1)                                     |
| T12 | Quality gate hooks configured (TeammateIdle, TaskCompleted) if teams enabled          | Medium   | [hooks.md](https://code.claude.com/docs/en/hooks.md)             |
| T13 | Permissions pre-approved for common operations to reduce teammate interruptions       | Medium   | [agent-teams.md](https://code.claude.com/docs/en/agent-teams.md) |
| T14 | CLAUDE.md provides sufficient project context for teammates (loaded automatically)    | Medium   | [agent-teams.md](https://code.claude.com/docs/en/agent-teams.md) |
| T15 | Team archetype matches project patterns (review/feature/debug/refactor/research)      | Info     | Recommendations (5.2.6.2)                                        |

**Note**: T10-T11, T15 are informational checks that feed into the Agent Teams proposal in Phase 5. They do not produce errors or warnings, only data for recommendations.

---

## 11. VSCode Extension (if applicable)

| #   | Check                                                                         | Severity | Source                                                |
| --- | ----------------------------------------------------------------------------- | -------- | ----------------------------------------------------- |
| V1  | `claudeCode.initialPermissionMode` uses valid value if set                    | High     | [vs-code.md](https://code.claude.com/docs/en/vs-code) |
| V2  | `claudeCode.preferredLocation` is "sidebar" or "panel" if set                 | Low      | [vs-code.md](https://code.claude.com/docs/en/vs-code) |
| V3  | Not using CLI-only features in VSCode (split panes, "!" bash, tab completion) | Medium   | [vs-code.md](https://code.claude.com/docs/en/vs-code) |
| V4  | MCP servers configured via CLI if needed in VSCode                            | High     | [vs-code.md](https://code.claude.com/docs/en/vs-code) |
| V5  | VSCode extension version >= 1.98.0 requirement met                            | Critical | [vs-code.md](https://code.claude.com/docs/en/vs-code) |

---

## 12. Breaking Changes & Deprecations

| #   | Check                                                                    | Severity | Source                                               |
| --- | ------------------------------------------------------------------------ | -------- | ---------------------------------------------------- |
| B1  | No deprecated `$ARGUMENTS.N` syntax (use `$ARGUMENTS[N]` instead)        | High     | Changelog v2.1.19                                    |
| B2  | No MCP @-mentions in prompts (use `/mcp enable` instead)                 | Medium   | Changelog v2.1.6                                     |
| B3  | Not relying on deprecated npm installation method                        | Low      | Changelog v2.1.15                                    |
| B4  | No `Bash(*)` wildcard with shell operators (security fix v2.1.6)         | Critical | Changelog v2.1.6                                     |
| B5  | No `once` field in settings.json hooks (only valid in skill/agent hooks) | Medium   | [hooks.md](https://code.claude.com/docs/en/hooks.md) |

---

## 13. Git Setup (MANDATORY)

**This section is MANDATORY for all projects.** Proper git hooks ensure "pixel perfect" commits fully managed by Claude.

| #   | Check                                                                     | Severity     | Source                                                     |
| --- | ------------------------------------------------------------------------- | ------------ | ---------------------------------------------------------- |
| G1  | `husky` in devDependencies of package.json                                | **Critical** | Template 11                                                |
| G2  | `"prepare": "husky"` script in package.json                               | **Critical** | Template 11                                                |
| G3  | `.husky/pre-commit` exists and runs `lint-staged`                         | **Critical** | Template 11                                                |
| G4  | `.husky/commit-msg` exists and runs `commitlint`                          | **Critical** | Template 11                                                |
| G5  | `commitlint.config.js` exists with project-specific scopes                | High         | Template 11                                                |
| G6  | `lint-staged` config in package.json covers all source files              | High         | Template 11                                                |
| G7  | Linters installed: ESLint/Prettier (JS/TS), Ruff (Python), rustfmt (Rust) | High         | Template 11                                                |
| G8  | `attribution.commit` / `attribution.pr` set in settings.json              | Medium       | [settings.md](https://code.claude.com/docs/en/settings.md) |
| G9  | Git commands properly scoped in permissions (safe=allow, dangerous=ask)   | Medium       | Template 11                                                |
| G10 | Git skills (`/commit`, `/pr`, `/changelog`) defined or use built-in       | Low          | Template 11                                                |
| G11 | Pre-push hook runs tests (optional but recommended)                       | Low          | Template 11                                                |

**Note**: Missing G1-G4 blocks the audit. Fix these before proceeding with other recommendations.

---

## 14. Cross-Cutting Concerns

| #   | Check                                                                           | Severity | Source                                                                 |
| --- | ------------------------------------------------------------------------------- | -------- | ---------------------------------------------------------------------- |
| X1  | No hardcoded absolute paths in project-level configs                            | High     | Portability                                                            |
| X2  | No secrets in any committed config file                                         | Critical | Security                                                               |
| X3  | Consistent naming conventions across components                                 | Low      | Maintainability                                                        |
| X4  | No redundant instructions across CLAUDE.md, rules, skills                       | Medium   | [best-practices.md](https://code.claude.com/docs/en/best-practices.md) |
| X5  | Skills that need isolation use `context: fork` or agents                        | Low      | [best-practices.md](https://code.claude.com/docs/en/best-practices.md) |
| X6  | Hook scripts referenced in settings.json actually exist                         | Critical | [hooks.md](https://code.claude.com/docs/en/hooks.md)                   |
| X7  | MCP servers referenced in settings are reachable                                | Medium   | [mcp.md](https://code.claude.com/docs/en/mcp.md)                       |
| X8  | Config priority hierarchy is understood (managed > CLI > local > shared > user) | Low      | [settings.md](https://code.claude.com/docs/en/settings.md)             |
| X9  | Monorepo structure handled correctly (parent CLAUDE.md, multiple .claude/ dirs) | Low      | [memory.md](https://code.claude.com/docs/en/memory.md)                 |
| X10 | No conflicting permissions between settings files                               | Medium   | [settings.md](https://code.claude.com/docs/en/settings.md)             |

---

## Scoring

- **Pass**: Check passes completely
- **Warning**: Minor deviation or improvement opportunity
- **Fail**: Check fails, needs fixing

**Overall Score Calculation:**

- Total checks applicable to the project
- Number passed, warned, failed
- Percentage score: `passed / applicable * 100`

**Rating:**

- 90-100%: Excellent configuration
- 75-89%: Good, minor improvements needed
- 60-74%: Fair, several issues to address
- Below 60%: Needs significant work
