# Valid Configuration Fields

Reference of all valid configuration fields per the official Claude Code documentation.

Source: https://code.claude.com/docs/en/settings.md, https://code.claude.com/docs/en/skills.md, https://code.claude.com/docs/en/sub-agents.md, https://code.claude.com/docs/en/hooks.md, https://code.claude.com/docs/en/agent-teams.md, https://code.claude.com/docs/en/vs-code

---

## settings.json / settings.local.json

### Top-Level Fields

```json
{
  "model": "string",
  "alwaysThinkingEnabled": boolean,
  "language": "string",
  "outputStyle": "string",
  "autoUpdatesChannel": "string",
  "respectGitignore": boolean,
  "disableAllHooks": boolean,
  "apiKeyHelper": "string",
  "otelHeadersHelper": "string",
  "companyAnnouncements": [ ... ],
  "cleanupPeriodDays": number,
  "permissions": { ... },
  "sandbox": { ... },
  "statusLine": { ... },
  "fileSuggestion": { ... },
  "attribution": { ... },
  "hooks": { ... },
  "env": { ... },
  "mcpServers": { ... },
  "allowedMcpServers": [ ... ],
  "deniedMcpServers": [ ... ],
  "allowManagedHooksOnly": boolean,
  "disallowedTools": [ ... ],
  "teammateMode": "string",
  "spinnerVerbs": [ ... ],
  "showTurnDuration": boolean,
  "prefersReducedMotion": boolean,
  "plansDirectory": "string",
  "usePythonEnvironment": boolean,
  "forceLoginMethod": "string",
  "forceLoginOrgUUID": "string",
  "enableAllProjectMcpServers": boolean,
  "enabledMcpjsonServers": [ ... ],
  "disabledMcpjsonServers": [ ... ],
  "spinnerTipsEnabled": boolean,
  "terminalProgressBarEnabled": boolean,
  "awsAuthRefresh": "string",
  "awsCredentialExport": "string",
  "allowManagedPermissionRulesOnly": boolean,
  "enabledPlugins": { ... },
  "extraKnownMarketplaces": { ... }
}
```

**Complete field descriptions:**

| Field                             | Type    | Description                                               |
| --------------------------------- | ------- | --------------------------------------------------------- |
| `model`                           | string  | Default model ID (e.g., "claude-sonnet-4-5-20250929")     |
| `alwaysThinkingEnabled`           | boolean | Enable extended thinking mode                             |
| `language`                        | string  | Response language (e.g., "english", "french")             |
| `outputStyle`                     | string  | System prompt style                                       |
| `autoUpdatesChannel`              | string  | "stable" or "latest"                                      |
| `respectGitignore`                | boolean | Use .gitignore in file picker                             |
| `disableAllHooks`                 | boolean | Disable all hooks globally                                |
| `apiKeyHelper`                    | string  | Script path for API keys                                  |
| `otelHeadersHelper`               | string  | Script for OpenTelemetry headers                          |
| `companyAnnouncements`            | array   | Startup announcements                                     |
| `cleanupPeriodDays`               | number  | Days before cleaning inactive sessions                    |
| `permissions`                     | object  | Tool permissions configuration                            |
| `sandbox`                         | object  | Sandboxing configuration                                  |
| `statusLine`                      | object  | Custom status line configuration                          |
| `fileSuggestion`                  | object  | Custom @ autocomplete                                     |
| `attribution`                     | object  | Git commit/PR attribution                                 |
| `hooks`                           | object  | Event handlers                                            |
| `env`                             | object  | Environment variables                                     |
| `mcpServers`                      | object  | MCP server definitions                                    |
| `allowedMcpServers`               | array   | Managed MCP allowlist                                     |
| `deniedMcpServers`                | array   | Managed MCP denylist                                      |
| `allowManagedHooksOnly`           | boolean | Restrict to managed hooks only                            |
| `disallowedTools`                 | array   | Globally denied tools                                     |
| `teammateMode`                    | string  | Agent teams display mode: "in-process", "tmux", or "auto" |
| `spinnerVerbs`                    | array   | Custom spinner verbs (e.g., ["Thinking", "Working"])      |
| `showTurnDuration`                | boolean | Show duration of each turn                                |
| `prefersReducedMotion`            | boolean | Reduce/disable UI animations for accessibility            |
| `plansDirectory`                  | string  | Custom directory for plan files                           |
| `usePythonEnvironment`            | boolean | Use Python environment for Python execution               |
| `forceLoginMethod`                | string  | Restrict login to "claudeai" or "console"                 |
| `forceLoginOrgUUID`               | string  | Specify organization UUID to auto-select                  |
| `enableAllProjectMcpServers`      | boolean | Auto-approve all MCP servers in project `.mcp.json`       |
| `enabledMcpjsonServers`           | array   | List of specific MCP servers to approve                   |
| `disabledMcpjsonServers`          | array   | List of specific MCP servers to reject                    |
| `spinnerTipsEnabled`              | boolean | Show tips in spinner (default: true)                      |
| `terminalProgressBarEnabled`      | boolean | Enable terminal progress bar (default: true)              |
| `awsAuthRefresh`                  | string  | Custom script modifying .aws directory                    |
| `awsCredentialExport`             | string  | Custom script outputting JSON with AWS credentials        |
| `allowManagedPermissionRulesOnly` | boolean | (Managed only) Prevent user/project permission rules      |
| `enabledPlugins`                  | object  | Map of "plugin-name@marketplace-name": true/false         |
| `extraKnownMarketplaces`          | object  | Defines additional plugin marketplaces for the repository |

### permissions

```json
{
	"permissions": {
		"allow": [
			"Read",
			"Glob",
			"Grep",
			"Bash(npm run lint)",
			"Bash(npm run test:*)",
			"Edit",
			"Write",
			"WebFetch",
			"WebSearch",
			"mcp__servername__toolname"
		],
		"deny": ["Task(Explore)", "Task(my-custom-agent)", "MCPSearch", "WebFetch"],
		"ask": ["Bash(git push *)"],
		"defaultMode": "acceptEdits",
		"additionalDirectories": ["../docs/"]
	}
}
```

**Patterns supported in allow/deny/ask:**

- Exact tool name: `Read`, `Write`, `Edit`, `Bash`, `Glob`, `Grep`, `WebFetch`, `WebSearch`
- Bash with command prefix: `Bash(npm run lint)`, `Bash(git commit:*)`
- Domain-specific: `WebFetch(domain:github.com)`, `WebFetch(domain:*.npmjs.org)`
- Path patterns: `Read(./secrets/**)`, `Write(**/*.config.js)`
- Subagent denial: `Task(agent-name)`
- MCP tools: `mcp__server__tool`

**Evaluation Order** (first match wins):

1. **Deny** rules checked first ❌
2. **Ask** rules checked second ❓
3. **Allow** rules checked third ✅
4. If no match, use `defaultMode` or built-in default

**Default Behavior** (when `defaultMode` not specified):

- Read-only tools (Read, Glob, Grep): Auto-allowed
- Write tools (Write, Edit): Ask permission
- Bash: Always ask

**Valid defaultMode values:**

- `default` - Standard permission dialogs
- `acceptEdits` - Auto-accept Edit tool
- `dontAsk` - Auto-allow most operations (use with caution)
- `bypassPermissions` - Skip all permission checks (admin only)
- `plan` - Plan mode behavior

### sandbox

```json
{
	"sandbox": {
		"enabled": true,
		"autoAllowBashIfSandboxed": true,
		"network": {
			"allowedDomains": ["github.com", "*.npmjs.org"]
		}
	}
}
```

**Sandbox fields:**

- `enabled` (boolean) - Enable sandboxing for Bash commands
- `autoAllowBashIfSandboxed` (boolean) - Auto-allow Bash when sandboxed
- `excludedCommands` (array) - Commands running outside sandbox
- `allowUnsandboxedCommands` (boolean) - Allow `dangerouslyDisableSandbox` (default: true)
- `network.allowedDomains` (array) - Allowed domains for network access (supports wildcards)
- `network.allowUnixSockets` (array) - Unix socket paths accessible in sandbox
- `network.allowAllUnixSockets` (boolean) - Allow all Unix socket connections (default: false)
- `network.allowLocalBinding` (boolean) - Allow binding to localhost ports on macOS (default: false)
- `network.httpProxyPort` (number) - HTTP proxy port
- `network.socksProxyPort` (number) - SOCKS5 proxy port
- `enableWeakerNestedSandbox` (boolean) - Enable weaker sandbox for Docker (Linux/WSL2, default: false)

---

### statusLine

```json
{
	"statusLine": {
		"type": "command",
		"command": "~/.claude/statusline.sh",
		"timeout": 5000
	}
}
```

**StatusLine fields:**

- `type` - Must be `"command"`
- `command` (string) - Shell command to execute
- `timeout` (number, optional) - Milliseconds before timeout (default: 5000)

---

### attribution

```json
{
	"attribution": {
		"commit": "Co-Authored-By: Claude <noreply@anthropic.com>",
		"pr": "Generated with Claude Code"
	}
}
```

**Attribution fields:**

- `commit` (string) - Attribution for git commits (trailers). Empty string hides it.
- `pr` (string) - Attribution for PR descriptions. Empty string hides it.

> **Note:** The deprecated `includeCoAuthoredBy` boolean field is superseded by `attribution`.

---

### hooks

Valid hook events:

- `SessionStart` - Session begins or resumes
- `SessionEnd` - Session terminates
- `UserPromptSubmit` - User submits a prompt
- `PreToolUse` - Before tool execution
- `PermissionRequest` - When permission dialog appears
- `PostToolUse` - After tool succeeds
- `PostToolUseFailure` - After tool fails
- `SubagentStart` - When spawning a subagent
- `SubagentStop` - When subagent finishes
- `Stop` - Claude finishes responding
- `PreCompact` - Before context compaction
- `Notification` - Claude Code sends notifications
- `Setup` - Invoked with `--init`, `--init-only`, or `--maintenance`
- `TeammateIdle` - Agent Teams: teammate finishes work and idles
- `TaskCompleted` - Agent Teams: task completed notification

Hook configuration structure:

```json
{
	"hooks": {
		"EventName": [
			{
				"matcher": "ToolPattern",
				"hooks": [
					{
						"type": "command",
						"command": "your-command-here",
						"timeout": 60,
						"statusMessage": "Running validation...",
						"async": false,
						"once": true
					}
				]
			}
		]
	}
}
```

**Hook types:**

- `"command"` - Bash script execution (most common)
- `"prompt"` - LLM single-turn evaluation (best for `Stop` and `SubagentStop`)
- `"agent"` - Subagent with full tool access (for complex analysis)

**Common fields (all hook types):**

- `timeout` (number) - Seconds before canceling (default varies by type)
- `statusMessage` (string) - Custom spinner message
- `once` (boolean) - Run only once per session (skills only, default: false)

**Command hook fields:**

- `command` (string, required) - Shell command to execute
- `async` (boolean) - Run in background (default: false)

**Prompt/Agent hook fields:**

- `prompt` (string, required) - Description or question for Claude
- `model` (string) - Model override: "sonnet", "opus", "haiku"

**Async Limitations:**

- Only available for `command` type
- Cannot be used with `agent` type
- Exit code still matters (0 = success, 2 = block)
- Stdout/stderr captured when process completes

**Matcher patterns (for PreToolUse, PermissionRequest, PostToolUse):**

- Exact match: `Write`, `Bash`, `Read`
- Regex: `Edit|Write`, `Notebook.*`, `mcp__memory__.*`
- All tools: `*` or `""`

**Matcher patterns for Notification:**

- `permission_prompt`
- `idle_prompt`
- `auth_success`
- `elicitation_dialog`

**Matcher patterns for PreCompact:**

- `manual`
- `auto`

**Matcher patterns for Setup:**

- `init` - Triggered by --init or --init-only
- `maintenance` - Triggered by --maintenance

**Matcher patterns for SessionEnd:**

- `clear` - After /clear command
- `logout` - User logged out
- `prompt_input_exit` - User exited prompt input
- `bypass_permissions_disabled` - Bypass permissions was disabled
- `other` - Other reasons

**Matcher patterns for SessionStart:**

- `startup` - Fresh session start
- `resume` - Resume existing session
- `clear` - After /clear command
- `compact` - After context compaction

**Hook exit codes:**

- `0` - Success (stdout shown in verbose mode; for UserPromptSubmit/SessionStart, stdout added as context)
- `2` - Blocking error (stderr shown to Claude)
- Other - Non-blocking error

**Environment variables available in hooks:**

- `$CLAUDE_PROJECT_DIR` - Absolute path to project root
- `$CLAUDE_CODE_REMOTE` - `"true"` in web environment, empty in CLI
- `$CLAUDE_ENV_FILE` - File path for persisting env vars (SessionStart and Setup only)
- `${CLAUDE_PLUGIN_ROOT}` - Plugin directory (plugin hooks only)

**JSON Response Patterns by Event:**

_PreToolUse (blocking):_

```json
{
  "hookSpecificOutput": {
    "permissionDecision": "allow" | "deny" | "ask"
  }
}
```

_PostToolUse / Stop (blocking):_

```json
{
	"decision": "block",
	"reason": "Tests failed with 3 errors"
}
```

_PermissionRequest:_

```json
{
  "hookSpecificOutput": {
    "decision": {
      "behavior": "allow" | "deny"
    }
  }
}
```

_UserPromptSubmit / SessionStart (add context):_

```json
{
	"additionalContext": "Current branch: main\nUncommitted changes: 5 files"
}
```

_SubagentStart (modify agent):_

```json
{
	"hookSpecificOutput": {
		"additionalInstructions": "Focus on security issues only"
	}
}
```

---

## SKILL.md Frontmatter

```yaml
---
name: skill-name # Optional: defaults to directory name
description: When to use # Recommended: triggers auto-invocation
argument-hint: '[args]' # Optional: autocomplete help text
disable-model-invocation: true # Optional: user-only invocation
user-invocable: false # Optional: hide from / menu (Claude-only)
allowed-tools: Read, Grep # Optional: restrict available tools
model: haiku # Optional: override model for this skill
context: fork # Optional: run in subagent
agent: Explore # Optional: subagent type
hooks: # Optional: lifecycle hooks
  PreToolUse:
    - matcher: 'Bash'
      hooks:
        - type: command
          command: './script.sh'
          once: true # Optional: run only once per session (skills only)
---
```

**Required fields:**

- None (all fields optional, but `name` and `description` highly recommended)

**Recommended fields:**

- `name` - kebab-case, max 64 characters (defaults to directory name if omitted)
- `description` - When/why to use the skill (enables auto-invocation)

**Optional fields:**

- `argument-hint` - Help text shown in autocomplete (e.g., "[filename]", "[path to project]")
- `disable-model-invocation` - If `true`, only invocable via `/name` (use for side-effects)
- `user-invocable` - If `false`, hidden from `/` menu (Claude can still auto-invoke)
- `allowed-tools` - Comma-separated list of allowed tools (restricts what skill can do)
- `model` - Override model: "sonnet", "opus", "haiku"
- `context` - Set to `fork` to run in isolated subagent context
- `agent` - Subagent type when `context: fork` (e.g., `Explore`, `Plan`, custom agent name)
- `hooks` - Lifecycle hooks (PreToolUse, PostToolUse, Stop)

**String Substitutions** (available in skill body):

- `$ARGUMENTS` - All passed arguments as string
- `$ARGUMENTS[N]` or `$N` - Specific argument by index (0-based)
- `${CLAUDE_SESSION_ID}` - Current session ID
- Backtick with exclamation prefix (e.g., `!command`) - Dynamic context (execute command and inject output)

**Example with substitutions:**

```markdown
Processing file: $1

Current git status:
(backtick with ! prefix: git status --short)

Session: ${CLAUDE_SESSION_ID}
```

---

## Agent Frontmatter (.claude/agents/\*.md)

```yaml
---
name: agent-name # Required: lowercase letters and hyphens
description: When to use # Required: delegation trigger
tools: Read, Grep, Glob # Optional: allowed tools (inherits all if omitted)
disallowedTools: Write, Edit # Optional: denied tools
model: sonnet # Optional: sonnet, opus, haiku, inherit (default: inherit)
permissionMode: default # Optional: default, acceptEdits, delegate, dontAsk, bypassPermissions, plan
skills: # Optional: skills to preload
  - api-conventions
  - error-handling
hooks: # Optional: lifecycle hooks
  PreToolUse:
    - matcher: 'Bash'
      hooks:
        - type: command
          command: './validate.sh'
---
```

**Required fields:**

- `name` - Lowercase letters and hyphens
- `description` - When Claude should delegate to this agent

**Optional fields:**

- `tools` - Comma-separated or list of allowed tools
- `disallowedTools` - Tools to deny
- `model` - Model to use: `sonnet`, `opus`, `haiku`, `inherit`
- `permissionMode` - Permission behavior: `default`, `acceptEdits`, `delegate`, `dontAsk`, `bypassPermissions`, `plan`
- `maxTurns` - Maximum agentic turns before stopping
- `skills` - List of skill names to preload
- `mcpServers` - MCP servers available to this agent
- `memory` - Persistent memory scope: `user`, `project`, or `local`
- `hooks` - Lifecycle hooks (PreToolUse, PostToolUse, Stop)

---

## .mcp.json

```json
{
	"mcpServers": {
		"server-name": {
			"command": "/path/to/server",
			"args": ["--flag", "value"],
			"env": {
				"API_KEY": "${API_KEY}",
				"URL": "${BASE_URL:-https://default.com}"
			}
		}
	}
}
```

For remote servers:

```json
{
	"mcpServers": {
		"server-name": {
			"type": "http",
			"url": "https://api.example.com/mcp",
			"headers": {
				"Authorization": "Bearer ${API_TOKEN}"
			}
		}
	}
}
```

**Server fields:**

- `command` - Executable path (stdio servers)
- `args` - Command arguments array (stdio servers)
- `env` - Environment variables object
- `type` - `"http"`, `"sse"`, or `"stdio"` (for remote servers)
- `url` - Server URL (remote servers)
- `headers` - HTTP headers object (remote servers)

**Environment variable syntax:**

- `${VAR}` - Required variable
- `${VAR:-default}` - Variable with default value
- `${CLAUDE_PLUGIN_ROOT}` - Plugin root directory (plugin MCP)

---

## Rules Frontmatter (.claude/rules/\*.md)

```yaml
---
paths: 'src/api/**/*.ts' # Optional: apply only to matching files
---
```

- `paths` - Glob pattern to scope the rule to specific files

---

## Available Tool Names

Internal tools that can be referenced in `tools`, `allowed-tools`, `disallowedTools`, `permissions`:

- `Read` - Read files
- `Write` - Write/create files
- `Edit` - Edit existing files
- `Bash` - Execute shell commands
- `Glob` - File pattern matching
- `Grep` - Content search
- `WebFetch` - Fetch web content
- `WebSearch` - Search the web
- `Task` - Spawn subagents
- `TodoWrite` - Manage todo lists
- `NotebookEdit` - Edit Jupyter notebooks
- `MCPSearch` - Search MCP tools (when tool search enabled)
- `mcp__<server>__<tool>` - MCP server tools (pattern: `mcp__servername__toolname`)

---

## Agent Teams (Experimental)

Agent teams are experimental and disabled by default. Enable by setting `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1`.

### teammateMode

Controls how teammates are displayed:

```json
{
	"teammateMode": "in-process"
}
```

**Valid values:**

- `"auto"` - Use split panes if already in tmux, otherwise in-process (default)
- `"in-process"` - All teammates in main terminal (Shift+Up/Down to navigate)
- `"tmux"` - Each teammate in its own split pane (requires tmux or iTerm2)

### Environment Variable for Feature Flag

```json
{
	"env": {
		"CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1"
	}
}
```

### Agent Teams Architecture

| Component       | Role                                                                      |
| --------------- | ------------------------------------------------------------------------- |
| **Team lead**   | The main session that creates the team, spawns teammates, and coordinates |
| **Teammates**   | Separate Claude Code instances working on assigned tasks                  |
| **Task list**   | Shared list stored at `~/.claude/tasks/{team-name}/`                      |
| **Mailbox**     | Messaging system for inter-agent communication                            |
| **Team config** | Stored at `~/.claude/teams/{team-name}/config.json`                       |

### Key Differences: Subagents vs Agent Teams

| Aspect        | Subagents                             | Agent Teams                                 |
| ------------- | ------------------------------------- | ------------------------------------------- |
| Context       | Own context, results return to caller | Fully independent context                   |
| Communication | Report to main agent only             | Teammates message each other                |
| Coordination  | Main agent manages                    | Shared task list, self-coordination         |
| Best for      | Focused tasks, results only           | Complex work needing collaboration          |
| Token cost    | Lower                                 | Higher (each teammate is separate instance) |

### Limitations

- No session resumption with in-process teammates
- One team per session
- No nested teams (teammates can't spawn their own teams)
- Lead is fixed for team lifetime
- Split panes not supported in VS Code terminal, Windows Terminal, or Ghostty

---

## VSCode Extension

The VSCode extension provides a graphical interface for Claude Code. Some features differ from the CLI.

### VSCode Extension Settings

These settings are configured in VSCode's settings.json (not `~/.claude/settings.json`):

```json
{
	"claudeCode.selectedModel": "default",
	"claudeCode.useTerminal": false,
	"claudeCode.initialPermissionMode": "default",
	"claudeCode.preferredLocation": "panel",
	"claudeCode.autosave": true,
	"claudeCode.useCtrlEnterToSend": false,
	"claudeCode.enableNewConversationShortcut": true,
	"claudeCode.hideOnboarding": false,
	"claudeCode.respectGitIgnore": true,
	"claudeCode.environmentVariables": [],
	"claudeCode.disableLoginPrompt": false,
	"claudeCode.allowDangerouslySkipPermissions": false,
	"claudeCode.claudeProcessWrapper": ""
}
```

| Setting                           | Type    | Default   | Description                                                                    |
| --------------------------------- | ------- | --------- | ------------------------------------------------------------------------------ |
| `selectedModel`                   | string  | `default` | Model for new conversations                                                    |
| `useTerminal`                     | boolean | `false`   | Use terminal mode instead of graphical panel                                   |
| `initialPermissionMode`           | string  | `default` | Default permission mode: `default`, `plan`, `acceptEdits`, `bypassPermissions` |
| `preferredLocation`               | string  | `panel`   | Where Claude opens: `sidebar` or `panel`                                       |
| `autosave`                        | boolean | `true`    | Auto-save files before Claude reads/writes                                     |
| `useCtrlEnterToSend`              | boolean | `false`   | Use Ctrl/Cmd+Enter instead of Enter to send                                    |
| `enableNewConversationShortcut`   | boolean | `true`    | Enable Cmd/Ctrl+N for new conversation                                         |
| `hideOnboarding`                  | boolean | `false`   | Hide onboarding checklist                                                      |
| `respectGitIgnore`                | boolean | `true`    | Exclude .gitignore patterns from searches                                      |
| `disableLoginPrompt`              | boolean | `false`   | Skip auth prompts (for third-party providers)                                  |
| `allowDangerouslySkipPermissions` | boolean | `false`   | Bypass all permission prompts                                                  |

### VSCode vs CLI Feature Comparison

| Feature                        | CLI   | VSCode Extension       |
| ------------------------------ | ----- | ---------------------- |
| All `/` commands               | Yes   | Subset only            |
| MCP server configuration       | Yes   | No (configure via CLI) |
| `!` bash shortcut              | Yes   | No                     |
| Tab completion                 | Yes   | No                     |
| Agent Teams split panes (tmux) | Yes   | **Not supported**      |
| Background task visibility     | Full  | Limited                |
| Checkpoints/Rewind             | Yes   | Yes                    |
| Visual diff review             | No    | Yes                    |
| @-mentions with line ranges    | Basic | Enhanced               |
| Multiple conversation tabs     | No    | Yes                    |
| Remote sessions from claude.ai | No    | Yes (OAuth users)      |
| `/usage` command               | No    | Yes                    |

### VSCode-Only Features

- **Checkpoints**: Track Claude's file edits and rewind to previous states
- **Visual Diffs**: Side-by-side comparison of proposed changes
- **@-mention line ranges**: Reference specific lines with `@file.ts#5-10`
- **Multiple tabs**: Open multiple conversations in separate tabs/windows
- **Remote sessions**: Resume sessions from claude.ai (OAuth users)
- **Browser automation**: Connect to Chrome for web testing (`@browser`)
- **Permission mode selector**: Click mode indicator in prompt box

### VSCode Keyboard Shortcuts

| Command          | Mac             | Windows/Linux    |
| ---------------- | --------------- | ---------------- |
| Toggle Focus     | `Cmd+Esc`       | `Ctrl+Esc`       |
| Open in New Tab  | `Cmd+Shift+Esc` | `Ctrl+Shift+Esc` |
| New Conversation | `Cmd+N`         | `Ctrl+N`         |
| Insert @-Mention | `Option+K`      | `Alt+K`          |

---

## Common Environment Variables

Environment variables that can be set in `env` section of settings.json:

```json
{
	"env": {
		"CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1",
		"CLAUDE_CODE_ENABLE_TASKS": "false",
		"CLAUDE_CODE_DISABLE_BACKGROUND_TASKS": "1",
		"CLAUDE_CODE_TMPDIR": "/custom/path",
		"FORCE_AUTOUPDATE_PLUGINS": "1",
		"CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS": "1",
		"CLAUDE_CODE_ADDITIONAL_DIRECTORIES_CLAUDE_MD": "1"
	}
}
```

| Variable                                       | Description                              |
| ---------------------------------------------- | ---------------------------------------- |
| `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS`         | Enable Agent Teams feature (set to `1`)  |
| `CLAUDE_CODE_ENABLE_TASKS`                     | Set to `false` to use legacy task system |
| `CLAUDE_CODE_DISABLE_BACKGROUND_TASKS`         | Disable background tasks (set to `1`)    |
| `CLAUDE_CODE_TMPDIR`                           | Override temporary directory path        |
| `FORCE_AUTOUPDATE_PLUGINS`                     | Auto-update plugins (set to `1`)         |
| `CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS`       | Disable experimental beta features       |
| `CLAUDE_CODE_ADDITIONAL_DIRECTORIES_CLAUDE_MD` | Load CLAUDE.md from --add-dir paths      |

---

## Breaking Changes & Deprecations

### Skill Argument Syntax Change (v2.1.19)

**Old syntax (deprecated):**

```
$ARGUMENTS.0
$ARGUMENTS.1
```

**New syntax (required):**

```
$ARGUMENTS[0]
$ARGUMENTS[1]
```

### npm Installation Deprecated (v2.1.15)

Run `claude install` or use alternative installation methods.
See: https://docs.anthropic.com/en/docs/claude-code/getting-started

### MCP Tool @-Mentions Removed (v2.1.6)

Use `/mcp enable <name>` instead of @-mentioning MCP tools.
