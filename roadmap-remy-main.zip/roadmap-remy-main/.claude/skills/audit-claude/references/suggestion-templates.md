# Ready-to-Use Templates for Claude Code

Templates de configuration prêts à l'emploi pour améliorer votre setup Claude Code.

---

## Template 1: Lint-on-Edit Hook

Linting automatique avant chaque modification de fichier.

**File**: `.claude/hooks/lint-on-edit.sh`

```bash
#!/bin/bash
set -e

TOOL_INPUT=$(cat)
FILE_PATH=$(echo "$TOOL_INPUT" | jq -r '.tool_input.file_path // empty')

case "$FILE_PATH" in
  *.py)
    # Python: ruff
    if command -v ruff &>/dev/null; then
      ruff check "$FILE_PATH" 2>&1 || exit 2
    fi
    ;;
  *.ts|*.js|*.svelte)
    # TypeScript/JavaScript/Svelte: eslint
    if command -v npx &>/dev/null; then
      npx eslint "$FILE_PATH" 2>&1 || exit 2
    fi
    ;;
  *.json)
    # JSON: jq validation
    if command -v jq &>/dev/null; then
      jq empty "$FILE_PATH" 2>&1 || exit 2
    fi
    ;;
esac

exit 0
```

**Configuration** (add to settings.json):

```json
{
	"hooks": {
		"PreToolUse": [
			{
				"matcher": "Edit|Write",
				"hooks": [
					{
						"type": "command",
						"command": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/lint-on-edit.sh\"",
						"statusMessage": "Linting file...",
						"timeout": 10
					}
				]
			}
		]
	}
}
```

**Benefit**: Catch syntax errors and linting issues before files are modified.

---

## Template 2: Run Tests After Code Changes

Automatically run tests after successful Edit/Write operations.

**File**: `.claude/hooks/run-tests.sh`

```bash
#!/bin/bash
set -e

TOOL_INPUT=$(cat)
TOOL_RESULT=$(echo "$TOOL_INPUT" | jq -r '.tool_result // empty')

# Only run if Edit/Write succeeded
if [[ -z "$TOOL_RESULT" ]]; then
  exit 0
fi

# Detect and run appropriate test suite
if [[ -f "pyproject.toml" ]] && command -v pytest &>/dev/null; then
  # Python: pytest
  pytest tests/ -x --tb=short -q 2>&1 || {
    echo '{"decision":"block","reason":"Tests failed - check output above"}' >&2
    exit 2
  }
elif [[ -f "package.json" ]] && command -v npm &>/dev/null; then
  # Node.js: npm test
  npm test 2>&1 || {
    echo '{"decision":"block","reason":"Tests failed - check output above"}' >&2
    exit 2
  }
fi

exit 0
```

**Configuration** (add to settings.json):

```json
{
	"hooks": {
		"PostToolUse": [
			{
				"matcher": "Edit|Write",
				"hooks": [
					{
						"type": "command",
						"command": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/run-tests.sh\"",
						"statusMessage": "Running tests...",
						"timeout": 120
					}
				]
			}
		]
	}
}
```

**Benefit**: Immediate feedback when code changes break tests. Blocks commits if tests fail.

---

## Template 3: Git Status StatusLine

Display git branch and uncommitted changes in the status line.

**File**: `~/.claude/statusline.sh` (or `.claude/hooks/statusline.sh`)

```bash
#!/bin/bash

# Exit gracefully if not in a git repo
if ! git rev-parse --is-inside-work-tree &>/dev/null; then
  echo "Not a git repo"
  exit 0
fi

BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null)
UNCOMMITTED=$(git status --short 2>/dev/null | wc -l | tr -d ' ')

echo "[$BRANCH] $UNCOMMITTED uncommitted"
```

**Configuration** (add to settings.json):

```json
{
	"statusLine": {
		"type": "command",
		"command": "bash ~/.claude/statusline.sh",
		"timeout": 2000
	}
}
```

**Benefit**: At-a-glance project status (branch, uncommitted changes).

---

## Template 4: Sandbox Configuration

Enable sandboxed Bash execution with network restrictions.

**Configuration** (add to settings.json):

```json
{
	"sandbox": {
		"enabled": true,
		"autoAllowBashIfSandboxed": true,
		"network": {
			"allowedDomains": ["github.com", "*.npmjs.org", "pypi.org", "*.python.org"]
		}
	}
}
```

**Benefit**:

- Auto-allow Bash commands (safer than unrestricted)
- Network access limited to specified domains
- Prevents accidental destructive operations

---

## Template 5: Permission Patterns for Sensitive Operations

Require explicit permission for potentially dangerous operations.

**Configuration** (add to settings.json):

```json
{
	"permissions": {
		"allow": ["Read", "Glob", "Grep", "Edit", "Write"],
		"ask": ["Bash(git push *)", "Bash(rm *)", "Bash(npm publish *)", "Bash(docker *)"],
		"deny": ["Write(.env*)", "Write(**/*.secret)", "Edit(.env*)"]
	}
}
```

**Benefit**:

- Allow safe operations automatically
- Ask before potentially destructive commands
- Block modifications to sensitive files

---

## Template 6: Skill with Context Isolation

Create a skill that runs in isolated context (fork).

**File**: `.claude/skills/deep-analysis/SKILL.md`

```yaml
---
name: deep-analysis
description: Perform deep codebase analysis requiring isolated context. Use when exploring complex architectural patterns or researching implementation details.
context: fork
agent: Explore
allowed-tools: Read, Grep, Glob, WebFetch
model: sonnet
---

# Deep Codebase Analysis

Analyze the codebase in isolated context to prevent memory pollution.

## Workflow

1. Understand the research question
2. Explore relevant files using Glob and Grep
3. Read key files in detail
4. Synthesize findings
5. Return structured report

## Usage

```

/deep-analysis "How is authentication implemented?"
/deep-analysis "Find all database models and their relationships"

```

```

**Benefit**:

- Clean context for complex analysis
- No pollution of main conversation
- Can run in parallel with other work

---

## Template 7: Project-Specific MCP Server

Example: Add Svelte documentation MCP server for Svelte projects.

**File**: `.mcp.json` (project root)

```json
{
	"mcpServers": {
		"svelte": {
			"command": "npx",
			"args": ["-y", "@modelcontextprotocol/server-svelte"]
		},
		"filesystem": {
			"command": "npx",
			"args": ["-y", "@modelcontextprotocol/server-filesystem", "/path/to/project"]
		}
	}
}
```

**Configuration** (add to settings.json to control access):

```json
{
	"allowedMcpServers": ["svelte", "filesystem"]
}
```

**Benefit**:

- Instant access to Svelte 5 documentation
- Context-aware file operations
- Specialized tools for your stack

---

## Template 8: Attribution for Git Commits

Add Claude as co-author in git commits.

**Configuration** (add to settings.json):

```json
{
	"attribution": {
		"commit": "Co-Authored-By: Claude <noreply@anthropic.com>",
		"pr": "Generated with Claude Code"
	}
}
```

**Benefit**:

- Transparent attribution in commit history and PRs
- Track which changes involved AI assistance
- Complies with team/org AI usage policies
- Use empty string `""` to hide attribution for commits or PRs

---

## Combining Templates

You can combine multiple templates for a complete setup:

```json
{
	"sandbox": { "enabled": true, "autoAllowBashIfSandboxed": true },
	"statusLine": { "type": "command", "command": "bash ~/.claude/statusline.sh" },
	"attribution": { "commit": "Co-Authored-By: Claude <noreply@anthropic.com>", "pr": "" },
	"permissions": {
		"allow": ["Read", "Glob", "Grep", "Edit", "Write"],
		"ask": ["Bash(git push *)"],
		"deny": ["Write(.env*)"]
	},
	"hooks": {
		"PreToolUse": [
			{
				"matcher": "Edit|Write",
				"hooks": [
					{
						"type": "command",
						"command": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/lint-on-edit.sh\""
					}
				]
			}
		],
		"PostToolUse": [
			{
				"matcher": "Edit|Write",
				"hooks": [
					{
						"type": "command",
						"command": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/run-tests.sh\"",
						"timeout": 120
					}
				]
			}
		]
	}
}
```

This combination gives you:

- ✅ Sandboxed Bash execution
- ✅ Git status in status line
- ✅ Claude attribution in commits
- ✅ Smart permissions (allow/ask/deny)
- ✅ Automatic linting before edits
- ✅ Automatic test running after changes

---

## Template 9: Agent Teams Configuration & Deployment

Enable, configure, and deploy Agent Teams for parallel multi-agent work.

### 9.1 Base Configuration

**Configuration** (add to settings.json):

```json
{
	"env": {
		"CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1"
	},
	"teammateMode": "auto"
}
```

**Valid teammateMode values:**

- `"auto"` - Use split panes if in tmux, otherwise in-process (default)
- `"in-process"` - All teammates in main terminal (Shift+Up/Down to navigate)
- `"tmux"` - Each teammate in own split pane (requires tmux or iTerm2)

**CLI override** (per-session):

```bash
claude --teammate-mode in-process
```

### 9.2 Quality Gate Hooks

Enforce quality standards when teammates finish work or complete tasks.

**File**: `.claude/hooks/teammate-quality-gate.sh`

```bash
#!/bin/bash
set -e

HOOK_INPUT=$(cat)
HOOK_EVENT=$(echo "$HOOK_INPUT" | jq -r '.hook_event // empty')

case "$HOOK_EVENT" in
  "TeammateIdle")
    TEAMMATE=$(echo "$HOOK_INPUT" | jq -r '.teammate_name // "unknown"')
    # Check if the teammate's work passes basic quality checks
    # Example: verify no uncommitted debug code
    if grep -r "console\.log\|print(\|debugger" --include="*.ts" --include="*.py" --include="*.svelte" src/ src_python/ 2>/dev/null | grep -v "node_modules" | head -5; then
      echo "Teammate $TEAMMATE: debug statements found in code. Please remove before finishing." >&2
      exit 2
    fi
    ;;
  "TaskCompleted")
    TASK=$(echo "$HOOK_INPUT" | jq -r '.task_description // "unknown"')
    # Example: verify tests pass before marking task complete
    if [[ -f "package.json" ]] && command -v bun &>/dev/null; then
      bun run check 2>&1 || {
        echo "Type check failed. Fix errors before marking task '$TASK' complete." >&2
        exit 2
      }
    fi
    ;;
esac

exit 0
```

**Hook configuration** (add to settings.json hooks):

```json
{
	"hooks": {
		"TeammateIdle": [
			{
				"matcher": "",
				"hooks": [
					{
						"type": "command",
						"command": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/teammate-quality-gate.sh\"",
						"statusMessage": "Checking teammate quality...",
						"timeout": 30
					}
				]
			}
		],
		"TaskCompleted": [
			{
				"matcher": "",
				"hooks": [
					{
						"type": "command",
						"command": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/teammate-quality-gate.sh\"",
						"statusMessage": "Validating task completion...",
						"timeout": 60
					}
				]
			}
		]
	}
}
```

### 9.3 Pre-Approved Permissions for Teams

Reduce permission prompt interruptions by pre-approving common operations:

```json
{
	"permissions": {
		"allow": [
			"Read",
			"Glob",
			"Grep",
			"Edit",
			"Write",
			"Bash(bun run check)",
			"Bash(bun run lint:*)",
			"Bash(pytest tests/ *)",
			"Bash(ruff check *)",
			"Bash(git status)",
			"Bash(git diff *)",
			"Bash(git log *)"
		],
		"ask": ["Bash(git push *)", "Bash(git commit *)"],
		"deny": ["Write(.env*)", "Write(**/*.secret)"]
	}
}
```

### 9.4 Team Archetype Spawn Prompts

Ready-to-use spawn prompts adapted to common project patterns.

#### 9.4.1 Multi-Perspective Code Review Team

```
Create an agent team to review the current branch changes. Spawn reviewers:
- Security reviewer: check for OWASP top 10 vulnerabilities, PII leaks in logs,
  crypto implementation issues, and injection vectors
- Performance reviewer: analyze render performance, bundle size impact,
  database query efficiency, and memory usage
- Test coverage reviewer: identify untested code paths, missing edge cases,
  and assertion quality
Have each reviewer share findings. Challenge each other's conclusions.
Synthesize a final report with severity ratings.
```

#### 9.4.2 Parallel Feature Development Team

```
Create an agent team to implement [FEATURE_NAME]. Break into:
- Frontend teammate: build UI components and routes in src/
  (Svelte 5 runes, Tailwind CSS, bits-ui components)
- Backend teammate: implement API endpoints and models in src_python/
  (Pydantic 2 models, JSON-RPC handlers)
- Test teammate: write tests for both layers
  (pytest for Python, vitest if applicable for TS)

File ownership:
- Frontend owns: src/lib/components/, src/routes/
- Backend owns: src_python/services/, src_python/models/
- Tests owns: tests/

Task dependencies:
1. Backend API definition (backend teammate) → blocks frontend integration
2. Frontend + Backend implementation (parallel) → blocks test writing
3. Tests verify both layers

Wait for all teammates to finish before synthesizing results.
```

#### 9.4.3 Debugging Investigation Team

```
Bug report: [DESCRIPTION]

Create a team of investigators to find the root cause:
- Hypothesis A: [frontend/state issue] - investigate src/ components and stores
- Hypothesis B: [backend/data issue] - investigate src_python/ services and models
- Hypothesis C: [IPC/communication issue] - investigate JSON-RPC calls between layers
- Devil's advocate: actively challenge each theory, propose counter-evidence

Rules:
- All investigators are read-only (no file modifications)
- Share findings after each investigation round
- Debate and converge on the most likely root cause
- Provide reproduction steps and a fix proposal
```

#### 9.4.4 Cross-Stack Refactoring Team

```
Refactor [MODULE] across the full stack. Create a team:
- Architect teammate: analyze current code, plan refactoring strategy,
  define new interfaces. Require plan approval before anyone implements.
- Frontend dev: implement frontend changes after architect approval
  (owns src/ files only)
- Backend dev: implement backend changes after architect approval
  (owns src_python/ files only)
- Test updater: update and create tests after implementations complete
  (owns tests/ files only)

Quality gates:
- Architect plan must be approved before implementation starts
- Type checks must pass before marking implementation tasks complete
- All existing tests must still pass after refactoring
```

#### 9.4.5 Documentation & Research Team

```
Research [TOPIC] for the project. Spawn researchers:
- Researcher A: investigate [approach/library A], document pros/cons
- Researcher B: investigate [approach/library B], document pros/cons
- Synthesizer: compare findings, write a recommendation document

Each researcher should:
1. Read official documentation
2. Check compatibility with our stack (Svelte 5, Python 3.12, Tauri 2)
3. Evaluate performance, security, and maintenance implications
4. Report findings to the synthesizer

Synthesizer writes final recommendation to docs/decisions/
```

### 9.5 Delegate Mode

For complex orchestration, use delegate mode to prevent the lead from implementing tasks itself:

```
# After creating the team, press Shift+Tab to enter delegate mode
# Or tell the lead explicitly:
Focus only on coordination. Do not implement any tasks yourself.
Break the work into tasks, assign to teammates, and synthesize results.
```

### 9.6 Plan Approval for Teammates

Require teammates to plan before implementing (useful for risky changes):

```
Spawn an architect teammate to refactor the authentication module.
Require plan approval before they make any changes.
Only approve plans that include test coverage and backward compatibility.
```

### 9.7 Cleanup Protocol

**Always follow this sequence:**

1. Ask teammates to shut down:
   ```
   Ask all teammates to shut down gracefully
   ```
2. Wait for confirmation that all teammates stopped
3. Clean up team resources:
   ```
   Clean up the team
   ```

**Important**: Only the lead should run cleanup. Teammates should not run cleanup.

**Orphaned sessions**: If tmux sessions persist after cleanup:

```bash
tmux ls
tmux kill-session -t <session-name>
```

### 9.8 When to Use vs. Alternatives

| Scenario                         | Recommendation | Why                                  |
| -------------------------------- | -------------- | ------------------------------------ |
| Quick code review, single focus  | Subagent       | Lower token cost, simpler            |
| Multi-perspective review         | **Agent Team** | Teammates challenge each other       |
| Sequential dependent tasks       | Single session | No parallelism benefit               |
| Parallel independent modules     | **Agent Team** | True parallel execution              |
| Same-file concurrent edits       | Single session | Avoid file conflicts                 |
| Complex debugging, unclear cause | **Agent Team** | Competing hypotheses converge faster |
| Simple bug fix                   | Single session | Coordination overhead not justified  |
| Cross-stack feature              | **Agent Team** | Each layer owned by specialist       |
| Cost-sensitive work              | Subagent       | Teams use significantly more tokens  |
| Research with debate             | **Agent Team** | Researchers challenge assumptions    |

### 9.9 Limitations Awareness

Document these limitations when proposing Agent Teams:

- No session resumption with in-process teammates (`/resume` won't restore them)
- One team per session (clean up before starting a new team)
- No nested teams (teammates can't spawn their own teams)
- Lead is fixed for the team's lifetime
- Split panes not supported in: VS Code terminal, Windows Terminal, Ghostty
- Task status can lag (teammates may not mark tasks complete promptly)
- All teammates start with the lead's permission settings

**Benefit**:

- Parallel exploration of complex problems
- Independent investigators challenge each other's findings
- Faster convergence on correct solutions
- Better coverage of multi-faceted tasks
- Quality gates enforce standards across all teammates

---

## Template 10: Scoped Rules Configuration

Create scoped rules for language/framework-specific conventions.

**File Structure**: `.claude/rules/`

```
.claude/rules/
├── typescript-conventions.md
├── svelte-patterns.md
├── python-standards.md
├── rust-tauri-patterns.md
├── testing-guidelines.md
└── documentation-style.md
```

**Example**: `.claude/rules/typescript-conventions.md`

```markdown
---
paths: 'src/**/*.ts'
---

# TypeScript Conventions

## Strict Type Requirements

- Enable strict mode in tsconfig.json
- No `any` types - use `unknown` with type guards
- Explicit return types for public functions
- Use branded types for domain IDs (e.g., `UserId`, `DocumentId`)

## Import Patterns

- Use absolute imports from `$lib/`
- Group: external → internal → types → styles
- No barrel exports (`index.ts`) - direct imports only

## Naming

- Interfaces: `IUserService` or `UserService` (prefer latter)
- Types: PascalCase (`DocumentStatus`, `ApiResponse<T>`)
- Constants: SCREAMING_SNAKE_CASE

## Async Patterns

- Always handle errors with try/catch or .catch()
- Use `Promise.all()` for parallel operations
- Prefer async/await over .then() chains

## Anti-patterns

- ❌ `// @ts-ignore` without justification
- ❌ Type assertions (`as Type`) without runtime checks
- ❌ Optional chaining abuse (`a?.b?.c?.d`)
```

**Example**: `.claude/rules/svelte-patterns.md`

```markdown
---
paths: 'src/**/*.svelte'
---

# Svelte 5 Patterns

## Runes Usage

- Use `$state()` for reactive state
- Use `$derived()` for computed values (not `$:`)
- Use `$effect()` for side effects (not `$:`)
- Use `$props()` to destructure component props

## Component Structure

1. `<script>` - imports, state, logic
2. Markup - template with minimal logic
3. `<style>` - scoped CSS (or Tailwind)

## Accessibility

- All interactive elements need focus states
- Images need alt text
- Forms need labels and aria attributes
- Use semantic HTML (`<button>`, not `<div onclick>`)

## Performance

- Use `{#key}` for forced re-renders sparingly
- Lazy load heavy components with `{#await}`
- Prefer CSS transitions over JS animations

## Anti-patterns

- ❌ Stores in Svelte 5 (use `$state.raw()` for shared state)
- ❌ `bind:this` unless absolutely necessary
- ❌ Inline styles (use Tailwind classes)
```

**Example**: `.claude/rules/python-standards.md`

```markdown
---
paths: 'src_python/**/*.py'
---

# Python Standards

## Type Hints (Python 3.12+)

- All public functions must have type annotations
- Use `list[str]` not `List[str]` (PEP 585)
- Use `X | None` not `Optional[X]` (PEP 604)
- Use `typing.Self` for return type of class methods

## Pydantic 2.x

- All models inherit from `pydantic.BaseModel`
- Use `model_validator` not `root_validator`
- Use `field_validator` not `validator`
- Use `model_dump()` not `.dict()`

## Docstrings

- Google style docstrings for all public functions
- Include Args, Returns, Raises sections
- Example usage for complex functions

## Error Handling

- Custom exceptions inherit from project base exception
- Always include context in exception messages
- Log errors with structured logging (structlog)

## Anti-patterns

- ❌ `from module import *`
- ❌ Mutable default arguments
- ❌ Bare `except:` clauses
- ❌ Magic numbers without constants
```

**Example**: `.claude/rules/testing-guidelines.md`

```markdown
---
paths: 'tests/**/*'
---

# Testing Guidelines

## Structure

- Mirror source structure: `tests/unit/`, `tests/integration/`
- One test file per source module
- Test file naming: `test_<module_name>.py`

## Naming

- Test functions: `test_<method>_<scenario>_<expected>`
- Example: `test_detect_entities_with_iban_returns_exclude_method`

## Fixtures

- Use pytest fixtures for reusable setup
- Scope appropriately: `function` (default), `class`, `module`, `session`
- Clean up resources in fixture teardown

## Assertions

- One assertion per concept (can be multiple asserts)
- Use descriptive assertion messages
- Use `pytest.raises` for exception testing

## Mocking

- Mock at boundaries (external APIs, databases, time)
- Use `pytest-mock` or `unittest.mock`
- Verify mock calls when behavior matters

## Coverage

- Minimum 80% line coverage
- 100% for critical paths (crypto, detection, pseudonymization)
- Exclude generated code and type stubs
```

**Benefit**:

- Scoped conventions only activate for matching files
- Reduces CLAUDE.md bloat with modular rules
- Language-specific patterns enforced automatically
- Reusable across projects with similar tech stack

---

## Template 11: Husky Git Integration (MANDATORY)

**This template is MANDATORY for all projects.** It ensures "pixel perfect" git operations fully managed by Claude.

### Why Mandatory?

Git hygiene is non-negotiable for AI-assisted development:

- Prevents accidental commits of broken code
- Enforces conventional commits for changelog generation
- Enables Claude to manage git operations autonomously
- Creates audit trail with proper attribution

### Installation

```bash
# Install dependencies
npm install -D husky lint-staged @commitlint/cli @commitlint/config-conventional

# Initialize Husky
npx husky init

# Create hooks
echo 'npx lint-staged' > .husky/pre-commit
echo 'npx commitlint --edit $1' > .husky/commit-msg
```

### Required Files

**File 1**: `commitlint.config.js`

```javascript
export default {
	extends: ['@commitlint/config-conventional'],
	rules: {
		// Allowed commit types
		'type-enum': [
			2,
			'always',
			[
				'feat', // New feature
				'fix', // Bug fix
				'docs', // Documentation
				'style', // Formatting (no code change)
				'refactor', // Code restructure (no behavior change)
				'perf', // Performance improvement
				'test', // Add/update tests
				'chore', // Maintenance tasks
				'ci', // CI/CD changes
				'build', // Build system changes
				'revert' // Revert previous commit
			]
		],
		// Project-specific scopes (customize per project)
		'scope-enum': [
			1,
			'always',
			[
				// Core
				'core',
				'config',
				'deps',
				'tooling',
				// Frontend
				'ui',
				'components',
				'routes',
				'stores',
				'styles',
				// Backend
				'api',
				'db',
				'auth',
				'crypto',
				// Testing
				'test',
				'e2e',
				// Documentation
				'docs',
				'readme',
				// Release
				'release',
				'changelog'
			]
		],
		// Enforce lowercase subject
		'subject-case': [2, 'always', 'lower-case'],
		// Max header length for readability
		'header-max-length': [2, 'always', 72],
		// No period at end
		'subject-full-stop': [2, 'never', '.']
	}
};
```

**File 2**: `package.json` (add these sections)

```json
{
	"scripts": {
		"prepare": "husky"
	},
	"lint-staged": {
		"*.{ts,tsx,js,jsx}": ["eslint --fix", "prettier --write"],
		"*.svelte": ["eslint --fix", "prettier --write"],
		"*.py": ["ruff check --fix", "ruff format"],
		"*.rs": ["rustfmt"],
		"*.{json,md,yml,yaml}": ["prettier --write"]
	}
}
```

**File 3**: `.husky/pre-commit`

```bash
npx lint-staged
```

**File 4**: `.husky/commit-msg`

```bash
npx commitlint --edit $1
```

**File 5** (optional): `.husky/pre-push`

```bash
#!/bin/bash
set -e

echo "Running tests before push..."

# Run appropriate test suite
if [[ -f "package.json" ]]; then
  npm run test -- --run 2>/dev/null || npm test 2>/dev/null || true
fi

if [[ -f "pyproject.toml" ]]; then
  pytest tests/ -x --tb=short -q 2>/dev/null || true
fi

echo "Pre-push checks complete."
```

### Claude Code Integration

Add to `settings.json` for full Claude git management:

```json
{
	"attribution": {
		"commit": "Co-Authored-By: Claude <noreply@anthropic.com>",
		"pr": ""
	},
	"permissions": {
		"allow": [
			"Bash(git status)",
			"Bash(git diff *)",
			"Bash(git log *)",
			"Bash(git add *)",
			"Bash(git commit *)",
			"Bash(git branch *)",
			"Bash(git checkout *)",
			"Bash(git merge *)",
			"Bash(git rebase *)",
			"Bash(git stash *)",
			"Bash(gh pr *)",
			"Bash(gh issue *)"
		],
		"ask": [
			"Bash(git push *)",
			"Bash(git push --force*)",
			"Bash(git reset --hard*)",
			"Bash(git clean *)"
		],
		"deny": ["Bash(git push --force origin main*)", "Bash(git push --force origin master*)"]
	}
}
```

### Git Skills for Claude

Create `.claude/skills/git/` with these skills:

**Skill 1**: `.claude/skills/git/commit/SKILL.md`

```yaml
---
name: commit
description: Quick commit with conventional commit message. Auto-stages, validates, and commits.
argument-hint: "[message] - e.g., 'fix(ui): button alignment'"
allowed-tools: Bash, Read, Grep
---

# Git Commit Skill

Quick commit workflow:

1. Run `git status` to see changes
2. Stage relevant files (avoid .env, secrets)
3. Generate conventional commit message
4. Commit with Claude co-author attribution

## Commit Message Format

```

<type>(<scope>): <subject>

[optional body]

[optional footer]

Co-Authored-By: Claude <noreply@anthropic.com>

```

## Rules

- Subject: imperative mood, lowercase, no period, max 72 chars
- Body: wrap at 72 chars, explain "why" not "what"
- If $ARGUMENTS provided, use as commit message
- If no arguments, analyze staged changes and generate message
```

**Skill 2**: `.claude/skills/git/pr/SKILL.md`

````yaml
---
name: create-pr
description: Create pull request with auto-generated title and description from commits.
argument-hint: "[base-branch] - defaults to main"
allowed-tools: Bash, Read, Grep
---

# Create PR Skill

1. Ensure all changes committed
2. Push current branch to origin
3. Generate PR title from branch name or commits
4. Generate PR body with:
   - Summary of changes (from commit messages)
   - Test plan checklist
   - Claude attribution
5. Create PR using `gh pr create`

## PR Body Template

```markdown
## Summary
- [Bullet points from commits]

## Changes
- [Files changed with brief description]

## Test Plan
- [ ] Unit tests pass
- [ ] E2E tests pass
- [ ] Manual testing completed

---
🤖 Generated with Claude Code
````

````

**Skill 3**: `.claude/skills/git/changelog/SKILL.md`

```yaml
---
name: changelog
description: Generate CHANGELOG.md from conventional commits since last tag.
argument-hint: "[version] - e.g., 'v1.2.0'"
allowed-tools: Bash, Read, Write
---

# Changelog Generator

Generate CHANGELOG.md from git history using conventional commits.

## Process

1. Get last tag: `git describe --tags --abbrev=0`
2. Get commits since tag: `git log <tag>..HEAD --oneline`
3. Group by type (feat, fix, etc.)
4. Format as Keep a Changelog format
5. Write/update CHANGELOG.md

## Output Format

```markdown
# Changelog

## [X.Y.Z] - YYYY-MM-DD

### Added
- feat(scope): description

### Fixed
- fix(scope): description

### Changed
- refactor(scope): description

### Security
- security(scope): description
````

```

### Audit Checklist for Git Setup

| Check | Required | Severity |
|-------|----------|----------|
| Husky installed in devDependencies | Yes | Critical |
| `prepare` script runs husky | Yes | Critical |
| `.husky/pre-commit` exists and runs lint-staged | Yes | High |
| `.husky/commit-msg` exists and runs commitlint | Yes | High |
| `commitlint.config.js` exists with project scopes | Yes | High |
| `lint-staged` config in package.json | Yes | High |
| Claude attribution in settings.json | Recommended | Medium |
| Git permissions properly scoped | Recommended | Medium |
| Git skills (`/commit`, `/pr`) defined | Recommended | Low |

### Benefit

- ✅ **Zero broken commits**: Pre-commit lint catches errors
- ✅ **Consistent history**: Commitlint enforces conventional commits
- ✅ **Auto changelog**: Structured commits enable automation
- ✅ **Claude autonomy**: Claude can commit without manual intervention
- ✅ **Safe operations**: Dangerous commands require confirmation
- ✅ **Audit trail**: Co-author attribution tracks AI involvement
```
