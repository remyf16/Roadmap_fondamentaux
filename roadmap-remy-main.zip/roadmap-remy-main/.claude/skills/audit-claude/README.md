# Audit Claude

Read-only audit of a `.claude/` directory against the official Claude Code documentation. Reports invalid fields, missing best practices, security issues, and improvement opportunities.

## Quick Start

### Audit Only (Fast)

```
/audit-claude
```

Audits the current project's `.claude/` directory. To audit a different project:

```
/audit-claude /path/to/project
```

### Audit + Suggestions (Comprehensive)

Get contextual improvement recommendations based on audit results:

```
/audit-claude with suggestions
/audit-claude suggest improvements
/audit-claude and recommend optimizations
```

This skill is **read-only** -- it never modifies files. Suggestions are text-only recommendations.

## What It Checks

The audit covers 10 areas with 100+ individual checks, each linked to official documentation.

| Area                  | What's Validated                                                                                                            | Checks |
| --------------------- | --------------------------------------------------------------------------------------------------------------------------- | ------ |
| **Project Structure** | `.claude/` exists, `.gitignore` covers sensitive files, no committed secrets, monorepo support                              | S1-S5  |
| **CLAUDE.md**         | Conciseness, actionable content, no duplication with rules, valid `@path` imports, CLAUDE.local.md in .gitignore            | M1-M9  |
| **settings.json**     | Valid JSON, all top-level fields, permission syntax (allow/deny/ask), hook types, sandbox/statusLine/attribution config     | J1-J20 |
| **Skills**            | Frontmatter fields, name format, description quality, user-invocable, model override, string substitutions, dynamic context | K1-K17 |
| **Subagents**         | Required fields, valid model/permissionMode values, tool names, hook format                                                 | A1-A13 |
| **Rules**             | Single topic per file, self-contained, valid `paths` globs, glob pattern validation                                         | R1-R8  |
| **Hooks**             | Executable permission, shebang, exit codes, hook types (command/prompt/agent), JSON responses, async limitations            | H1-H15 |
| **MCP**               | Valid `.mcp.json` at root, server types (http/sse/stdio), allowedMcpServers/deniedMcpServers, no secrets                    | P1-P13 |
| **Plugins**           | plugin.json structure, ${CLAUDE_PLUGIN_ROOT} usage, valid paths                                                             | L1-L5  |
| **Cross-Cutting**     | No absolute paths, config hierarchy, monorepo support, no conflicts between settings                                        | X1-X10 |

Full checklist with severity levels: [references/audit-checklist.md](references/audit-checklist.md)

## Audit Workflow

```
Phase 1: Discovery
    ↓
Phase 2: Component Audit
    ↓
Phase 3: Cross-Cutting
    ↓
Phase 4: Report
    ↓
Phase 5: Proactive Recommendations (optional - if "suggestions" requested)
```

1. **Discovery** -- Inventory all files in `.claude/`, check root-level `CLAUDE.md`, `.mcp.json`, and `~/.claude/` user config
2. **Component Audit** -- Validate each component (CLAUDE.md, settings, skills, agents, rules, hooks, MCP, plugins) against official docs
3. **Cross-Cutting** -- Check portability, git hygiene, consistency, secrets, redundancy
4. **Report** -- Generate structured audit report with score, issues, warnings, and recommendations

## Output Format

The audit produces a structured report:

```
# Claude Code Configuration Audit

**Project**: /path/to/project

## Summary

| Component     | Status | Issues | Warnings |
|---------------|--------|--------|----------|
| CLAUDE.md     | ✅     | 0      | 1        |
| settings.json | ⚠️     | 1      | 2        |
| Skills        | ✅     | 0      | 0        |
| ...           |        |        |          |

**Overall Score**: 52/58 checks passed (90%)

## Issues (Must Fix)

### [J6] settings.json: Invalid hook event name
- **Severity**: High
- **What**: Hook event "BeforeToolUse" is not recognized
- **Fix**: Change to "PreToolUse"

## Warnings (Should Fix)
...

## Recommendations (Consider)
...
```

## Severity Levels

| Level        | Meaning                                          | Examples                                                                       |
| ------------ | ------------------------------------------------ | ------------------------------------------------------------------------------ |
| **Critical** | Config is broken or has security holes           | Invalid JSON, missing required fields, hardcoded secrets                       |
| **High**     | Config works but has correctness/security issues | Invalid field names, wrong permission syntax, exposed secrets                  |
| **Medium**   | Valid config that doesn't follow best practices  | CLAUDE.md too long, redundant instructions, missing `disable-model-invocation` |
| **Low**      | Minor style or optional improvements             | Naming conventions, missing optional features                                  |

## Score Ratings

| Score     | Rating                          |
| --------- | ------------------------------- |
| 90-100%   | Excellent configuration         |
| 75-89%    | Good, minor improvements needed |
| 60-74%    | Fair, several issues to address |
| Below 60% | Needs significant work          |

## Source of Truth

All checks reference the official Claude Code documentation:

| Topic              | URL                                               |
| ------------------ | ------------------------------------------------- |
| Settings           | https://code.claude.com/docs/en/settings.md       |
| Memory (CLAUDE.md) | https://code.claude.com/docs/en/memory.md         |
| Skills             | https://code.claude.com/docs/en/skills.md         |
| Hooks              | https://code.claude.com/docs/en/hooks.md          |
| MCP                | https://code.claude.com/docs/en/mcp.md            |
| Subagents          | https://code.claude.com/docs/en/sub-agents.md     |
| Plugins            | https://code.claude.com/docs/en/plugins.md        |
| Best practices     | https://code.claude.com/docs/en/best-practices.md |

When uncertain, the skill fetches the relevant documentation page to verify before flagging.

## File Structure

```
audit-claude/
├── SKILL.md                        # Skill definition (5-phase workflow, opt-in Phase 5)
├── README.md                       # This file
└── references/
    ├── audit-checklist.md          # 115 checks with severity and doc links
    ├── valid-fields.md             # All valid fields for settings, skills, agents, MCP
    └── suggestion-templates.md     # Ready-to-use templates for Phase 5 recommendations
```

## References

- [Audit checklist](references/audit-checklist.md) -- complete check table with IDs, severity, and source links
- [Valid fields](references/valid-fields.md) -- all recognized configuration fields per component type
- [Suggestion templates](references/suggestion-templates.md) -- ready-to-use templates for Phase 5 recommendations
