---
name: create-pr
description: Create a pull request with auto-detected base branch (develop or main), labels, and structured description
allowed-tools: Bash, Read, Grep, Glob
user-invocable: true
argument-hint: "[optional PR title override]"
---

# Create Pull Request (Git Flow)

Create a PR with automatic base branch detection and labeling.

## Workflow

### 1. Pre-flight checks

```bash
BRANCH=$(git branch --show-current)
echo "Current branch: $BRANCH"
git status
```

- STOP if on `main` or `develop` - can't PR from protected branches
- STOP if there are uncommitted changes - commit first

### 2. Auto-detect base branch

Based on current branch prefix:

| Current branch | PR base |
|---------------|---------|
| `feat/*` | `develop` |
| `fix/*` | `develop` |
| `refactor/*` | `develop` |
| `style/*` | `develop` |
| `perf/*` | `develop` |
| `test/*` | `develop` |
| `docs/*` | `develop` |
| `chore/*` | `develop` |
| `ci/*` | `develop` |
| `release/*` | `main` |
| `hotfix/*` | `main` |

### 3. Analyze all changes

```bash
BASE="develop"  # or "main" based on above
git log $BASE..HEAD --oneline
git diff $BASE...HEAD --stat
git diff $BASE...HEAD
```

Review ALL commits in the branch, not just the latest.

### 4. Auto-detect labels

| Branch prefix | Label |
|---------------|-------|
| `feat/` | `enhancement` |
| `fix/` | `bug` |
| `hotfix/` | `bug` |
| `docs/` | `documentation` |
| `refactor/` | `refactoring` |
| `chore/` | `maintenance` |
| `perf/` | `performance` |
| `release/` | `release` |

### 5. Push and create PR

```bash
git push -u origin HEAD
```

```bash
gh pr create --base "$BASE" --title "<title>" --label "$LABELS" --body "$(cat <<'EOF'
## Summary

<1-3 bullet points>

## Changes

<list of changes by area>

## Test plan

- [ ] Build passes (`npm run build`)
- [ ] Lint passes (`npm run lint`)
- [ ] <manual verification steps>

## Release notes

<one-liner for changelog, or "N/A">

---
Generated with [Claude Code](https://claude.com/claude-code)
EOF
)"
```

If labels don't exist on the repo, create the PR without labels.

### 6. Output

Display:
- PR URL
- Title
- Base branch <- Head branch
- Labels applied
