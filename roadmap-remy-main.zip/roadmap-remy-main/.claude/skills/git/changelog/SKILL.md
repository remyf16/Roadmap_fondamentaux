---
name: changelog
description: Generate, update, or preview the CHANGELOG.md from conventional commits history
allowed-tools: Bash, Read, Grep, Glob, Edit, Write
user-invocable: true
argument-hint: "[preview|update|init|since:<tag-or-ref>]"
---

# Changelog Management

Generate, update, or preview the CHANGELOG.md based on conventional commits history.

This skill works independently of the release workflow. Use it to:

- Preview what will be in the next changelog entry
- Manually update the changelog outside of a release cycle
- Initialize a changelog for the first time
- Generate changelog entries for a specific range of commits

## Workflow

### 1. Read project config

```bash
cat .versionrc.json
```

Extract the `types` mapping to know which commit types map to which sections and which are hidden.

### 2. Determine the mode

Based on `$ARGUMENTS`:

| Argument      | Action                                                             |
| ------------- | ------------------------------------------------------------------ |
| (none)        | Same as `preview`                                                  |
| `preview`     | Show what the next changelog entry would contain (no file changes) |
| `update`      | Write the changelog entry to `CHANGELOG.md`                        |
| `init`        | Create `CHANGELOG.md` from scratch with full history               |
| `since:<ref>` | Preview changes since a specific tag or commit ref                 |

### 3. Find the commit range

```bash
LATEST_TAG=$(git describe --tags --abbrev=0 2>/dev/null || echo "")
CURRENT_VERSION=$(node -p "require('./package.json').version")
echo "Current version: $CURRENT_VERSION"
echo "Latest tag: $LATEST_TAG"
```

- If a tag exists: range is `$LATEST_TAG..HEAD`
- If `since:<ref>` argument: range is `<ref>..HEAD`
- If `init` mode: use full history
- If no tags exist: use full history

### 4. Collect and parse commits

```bash
git log $RANGE --format="%H|%s|%b%n---END---" --no-merges
```

Parse each commit:

- Extract `type(scope): description` from subject
- Detect `BREAKING CHANGE:` in body or `!` after type
- Group by type according to `.versionrc.json` sections

### 5. Generate changelog entry

Build the entry following this structure:

```markdown
## [Unreleased]

### Nouvelles fonctionnalités

- **scope:** description ([hash](commit-url))

### Corrections de bugs

- **scope:** description ([hash](commit-url))

### Performances

- description ([hash](commit-url))

### Refactoring

- description ([hash](commit-url))

### Reverts

- description ([hash](commit-url))

### BREAKING CHANGES

- **scope:** description
```

Rules:

- Use section names from `.versionrc.json` `types[].section`
- Skip types where `hidden: true` UNLESS the user passed `--all` in arguments
- Omit empty sections entirely
- Use short commit hash (7 chars) with link if `commitUrlFormat` is configured
- Group breaking changes in their own section at the end
- If no visible commits found, say so explicitly

### 6. Execute based on mode

#### Mode: `preview` (default)

Display the generated entry in the terminal output. Do NOT modify any files.

Show:

- The formatted changelog entry
- Stats: number of commits by type
- Suggested next version (patch if only fixes, minor if features, major if breaking)

#### Mode: `update`

1. Check if `CHANGELOG.md` exists
   - If not, create it with the header from `.versionrc.json`
2. Read existing changelog
3. Insert new entry after the header (before the first `## [` line)
4. Write the updated file
5. Stage the file:
   ```bash
   git add CHANGELOG.md
   ```
6. Show diff of what was added

#### Mode: `init`

1. Collect ALL commits (full history)
2. Group by tags/versions if tags exist
3. Generate full changelog with all versions
4. Write to `CHANGELOG.md`
5. Stage the file:
   ```bash
   git add CHANGELOG.md
   ```

#### Mode: `since:<ref>`

Same as `preview` but with the specified ref as start of range.

```bash
git log <ref>..HEAD --format="%H|%s|%b%n---END---" --no-merges
```

### 7. Output

#### For `preview` / `since:<ref>`:

Display:

- Formatted changelog entry (markdown)
- Commit count by section
- Suggested version bump type
- Reminder: use `/release` to create an actual release with changelog

#### For `update`:

Display:

- Formatted changelog entry added
- File path modified
- File staged for commit
- Reminder: commit with `/commit` or include in next release

#### For `init`:

Display:

- Full changelog generated
- Number of versions/entries created
- File path created
- File staged for commit
