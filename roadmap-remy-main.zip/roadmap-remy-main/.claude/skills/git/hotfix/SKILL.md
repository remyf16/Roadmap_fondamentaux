---
name: hotfix
description: Create a hotfix branch from main, apply fix, PR to main and merge back to develop
allowed-tools: Bash, Read, Grep, Glob, Edit, Write
user-invocable: true
argument-hint: "[description of the fix]"
---

# Hotfix Workflow (Git Flow)

Create a hotfix from `main`, apply the fix, release a patch, merge to `main` AND back to `develop`.

## Workflow

### 1. Find latest state of main

```bash
git checkout main
git pull origin main 2>/dev/null || true
LATEST_TAG=$(git describe --tags --abbrev=0 2>/dev/null || echo "none")
echo "Latest release: $LATEST_TAG"
```

### 2. Create hotfix branch from main

```bash
git checkout -b hotfix/<name-from-arguments>
```

### 3. Apply the fix

Help the user implement the fix. Use standard development tools.

### 4. Verify

```bash
npm run lint
npm run build
```

### 5. Commit the fix

```bash
git add <files>
git commit -m "$(cat <<'EOF'
fix(<scope>): <description>

Co-Authored-By: Claude <noreply@anthropic.com>
EOF
)"
```

### 6. Create patch release

```bash
npm run release:patch
```

### 7. Push and create PR to main

```bash
git push -u origin HEAD
gh pr create --base main --title "hotfix: <description>" --label "bug" --body "$(cat <<'EOF'
## Hotfix

### Problem
<description of the bug>

### Fix
<description of the fix>

### Release
- Patch version bump included
- Tag created

---
Generated with [Claude Code](https://claude.com/claude-code)
EOF
)"
```

### 8. Remind about merge back to develop

After the PR is merged to `main`, remind the user:

```bash
git checkout develop
git merge main
git push origin develop
```

### 9. Output

Display:

- Hotfix branch name
- Base: `main` (tag: <latest>)
- New version
- PR URL to `main`
- Reminder: merge back to `develop` after merge
