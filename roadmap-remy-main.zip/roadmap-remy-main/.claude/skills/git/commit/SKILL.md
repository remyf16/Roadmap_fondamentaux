---
name: commit
description: Smart commit - analyzes changes, generates conventional commit, validates with commitlint
allowed-tools: Bash, Read, Grep, Glob
user-invocable: true
argument-hint: "[optional commit message override]"
---

# Smart Commit

Analyze changes and create a conventional commit with automatic type/scope detection.

## Workflow

### 1. Analyze changes

```bash
git status
git diff --staged --stat
git diff --stat
git branch --show-current
```

### 2. Stage files

If nothing is staged:

- Identify all modified/added files
- Group by area to determine scope
- Stage relevant files (never `.env*`, `*.secret`, `node_modules/`)
- Prefer specific files over `git add -A`

### 3. Auto-detect type and scope

Based on the files changed:

| Files changed                  | Type     | Scope      |
| ------------------------------ | -------- | ---------- |
| `src/components/**`            | feat/fix | components |
| `src/store/**`                 | feat/fix | store      |
| `src/hooks/**`                 | feat/fix | ui         |
| `src/views/**`                 | feat/fix | ui         |
| `*.css`, `tailwind*`           | style    | styles     |
| `package.json`, `vite.config*` | chore    | config     |
| `package-lock.json` only       | chore    | deps       |
| `*.test.*`, `*.spec.*`         | test     | (auto)     |
| `*.md`, `CHANGELOG*`           | docs     | (auto)     |
| `.claude/**`                   | chore    | config     |
| `src/lib/**`                   | feat/fix | flow       |

If `$ARGUMENTS` is provided, use it as the commit message directly (still validate format).

### 4. Generate message

Format: `type(scope): description`

Rules:

- Subject in lower-case, imperative mood
- No period at the end
- Max 72 characters for header
- If multiple scopes are affected, omit scope or use the dominant one
- For breaking changes: `type(scope)!: description`

Add body if the change is complex (> 5 files or non-obvious):

```
type(scope): short description

Longer explanation of what changed and why.

BREAKING CHANGE: description (if applicable)
```

### 5. Validate and commit

```bash
echo "type(scope): message" | npx commitlint
git commit -m "$(cat <<'EOF'
type(scope): message

Co-Authored-By: Claude <noreply@anthropic.com>
EOF
)"
```

### 6. Post-commit summary

Display:

- Commit hash (short)
- Files changed count
- Commit message
- Ask if user wants to push (`git push -u origin HEAD`)
