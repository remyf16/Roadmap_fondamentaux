---
name: release
description: Create a release branch from develop, bump version, changelog, tag, and PR to main
allowed-tools: Bash, Read, Grep, Glob
user-invocable: true
argument-hint: "[patch|minor|major|first|dry]"
---

# Automated Release (Git Flow)

Create a release following Git Flow: branch from `develop`, bump version, merge to `main`, merge back to `develop`.

## Workflow

### 1. Pre-flight checks

```bash
git status
git branch --show-current
```

- STOP if there are uncommitted changes
- Must be on `develop` or a `release/*` branch

### 2. Create release branch from develop

```bash
git checkout develop
git pull origin develop 2>/dev/null || true
```

Preview the release first:

```bash
npm run release:dry
```

Show the user what version will be bumped to.

Then create the release branch:

```bash
git checkout -b release/v<next-version>
```

### 3. Execute the release

Based on `$ARGUMENTS`:

| Argument | Command                                      |
| -------- | -------------------------------------------- |
| (none)   | `npm run release` (auto-detect from commits) |
| `patch`  | `npm run release:patch`                      |
| `minor`  | `npm run release:minor`                      |
| `major`  | `npm run release:major`                      |
| `first`  | `npm run release:first`                      |
| `dry`    | `npm run release:dry` (stop here)            |

```bash
npm run release
```

### 4. Push release branch and create PR to main

```bash
git push -u origin HEAD
gh pr create --base main --title "release: v<version>" --label "release" --body "$(cat <<'EOF'
## Release v<version>

### Changelog
<extract from CHANGELOG.md>

### Checklist
- [ ] Build passes
- [ ] Lint passes
- [ ] Version bumped in package.json
- [ ] CHANGELOG.md updated
- [ ] Tag created

---
Generated with [Claude Code](https://claude.com/claude-code)
EOF
)"
```

### 5. After merge to main

Remind the user that after merging the PR to `main`, they need to:

1. Push the tag: `git push --follow-tags origin main`
2. Merge `main` back into `develop`:
   ```bash
   git checkout develop
   git merge main
   git push origin develop
   ```

Or offer to create a GitHub Release:

```bash
VERSION=$(node -p "require('./package.json').version")
gh release create "v$VERSION" --title "v$VERSION" --notes-from-tag --latest
```

### 6. Output

Display:

- Release branch name
- New version number
- PR URL (to main)
- Changelog excerpt
- Next steps reminder (merge + tag + merge back)
