---
name: branch
description: Create a properly named git branch from develop following Git Flow conventions
allowed-tools: Bash, Read
user-invocable: true
argument-hint: "[type/name or description]"
---

# Create Branch

Create a new git branch following Git Flow conventions.

## Workflow

### 1. Parse arguments

From `$ARGUMENTS`, determine:
- **type**: feat, fix, refactor, docs, chore, style, perf, test, ci
- **name**: kebab-case description

Examples of valid input:
- `feat/kanban-filters` -> use as-is
- `add user avatar component` -> `feat/add-user-avatar`
- `fix the timeline bug` -> `fix/timeline-bug`
- `update dependencies` -> `chore/update-deps`

### 2. Validate current state

```bash
git status
git branch --show-current
```

- If there are uncommitted changes, warn the user and ask to stash or commit first

### 3. Ensure develop exists

```bash
git branch --list develop
```

If `develop` doesn't exist, create it:
```bash
git checkout main
git checkout -b develop
git push -u origin develop
```

### 4. Create from develop

```bash
git checkout develop
git pull origin develop 2>/dev/null || true
git checkout -b <type>/<name>
```

### 5. Output

Display:
- Branch name created
- Base branch (`develop`)
- Reminder: code -> commit -> push -> PR vers `develop`
