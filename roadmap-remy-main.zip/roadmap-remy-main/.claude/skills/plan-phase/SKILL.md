---
name: plan-phase
description: Decomposer une feature en taches d'implementation. Lit la spec feature, cree un PLAN.md avec taches ordonnees et dependances.
argument-hint: "<feature-slug> - e.g. 'dark-mode'"
allowed-tools:
  - Read
  - Grep
  - Glob
  - Write
  - Bash
  - AskUserQuestion
  - TodoWrite
---

# Skill : Plan Phase

Decomposition d'une feature en taches d'implementation. Deuxieme etape du workflow :

```
/new-feature → /plan-phase → /implement
```

## Workflow

### 1. Charger la spec feature

Lire la spec feature :

```
Read: .claude/features/$ARGUMENTS.md
```

Si le fichier n'existe pas :

- Lister les features disponibles : `Glob: .claude/features/*.md`
- Demander a l'utilisateur de preciser avec AskUserQuestion
- Si aucune feature n'existe, suggerer de lancer `/new-feature` d'abord

Extraire de la spec :

- Contexte et objectif
- Requirements (liste des checkbox)
- Zones impactees (composants, store, types, hooks)
- Notes techniques

### 2. Explorer le codebase

Comprendre les patterns existants pour les respecter :

```
Read: src/types/models.ts
Glob: src/store/slices/*.ts
Glob: src/components/**/*.tsx
Read: src/store/index.ts
```

Identifier :

- Comment les composants existants sont structures
- Comment les slices sont definies (actions, selectors)
- Les patterns d'import et d'export
- Les conventions de nommage

### 3. Decomposer en taches

**Regles de granularite (CRITIQUE)** :

Chaque tache sera executee par `/implement` dans une seule session.
Pour eviter la saturation de contexte, les taches DOIVENT etre petites.

**Taille cible par tache :**

- **1-3 fichiers** crees ou modifies (jamais plus)
- **2-5 criteres d'acceptation** (testables, specifiques)
- **1 concept** implemente (un type, un slice, un composant, un hook)

**Regles de decoupage :**

- Types/interfaces = 1 tache (models.ts + exports)
- Nouveau slice Zustand = 1 tache (slice + ajout au store index)
- Composant UI simple = 1 tache (composant + integration parent)
- Composant UI complexe = 2-3 taches (squelette, logique, styles)
- Hook custom = 1 tache (hook + usage dans 1 composant)
- Integration entre concerns = 1 tache dediee (wiring)

**Anti-patterns (NE PAS FAIRE) :**

- NE PAS creer une tache qui touche types + store + composant
- NE PAS creer une tache qui cree 4+ fichiers
- NE PAS melanger creation de types et implementation de logique
- NE PAS bundler des concerns non-lies

### 4. Ordonner par dependance

Ordre typique :

1. **Types** : interfaces et types dans models.ts
2. **Store** : slices Zustand (depend des types)
3. **Hooks** : custom hooks (depend du store)
4. **Composants fondation** : composants de base reutilisables
5. **Composants features** : composants specifiques a la feature
6. **Integration** : assemblage et wiring dans les vues
7. **Styles/Polish** : ajustements visuels finaux

### 5. Ecrire le plan

Creer `.claude/plans/{slug}/PLAN.md` avec cette structure :

```markdown
# Plan : {Nom de la feature}

## Overview

- **Feature** : [Lien vers spec](.claude/features/{slug}.md)
- **Taches** : {count} taches
- **Status** : planning

## Task List

### Types & Interfaces

#### TASK-001 : {Description courte}

- **Status** : pending
- **Stack** : frontend
- **Files** :
  - Modify : `src/types/models.ts`
- **Acceptance** :
  - [ ] {Critere 1}
  - [ ] {Critere 2}
- **Depends** : none
- **Done** : -
- **Notes** : -

---

### Store

#### TASK-002 : {Description courte}

...

### Components

#### TASK-003 : {Description courte}

...

## Dependency Graph

(graph ASCII visuel des dependances entre taches)

## Summary

| Groupe      | Taches | Status       |
| ----------- | ------ | ------------ |
| Types       | N      | 0/N done     |
| Store       | N      | 0/N done     |
| Components  | N      | 0/N done     |
| Integration | N      | 0/N done     |
| **Total**   | **N**  | **0/N done** |
```

### 6. Output

Afficher a l'utilisateur :

- Nombre total de taches
- Graph de dependances
- Ordre d'implementation recommande
- **Prochaine etape** : `Lancez /implement 1 pour commencer l'implementation`
