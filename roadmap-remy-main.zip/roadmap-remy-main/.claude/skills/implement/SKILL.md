---
name: implement
description: Implementer une tache du plan courant. Lit le plan, code en suivant les conventions, valide avec lint/build, met a jour le statut.
argument-hint: "<task-number> - e.g. '1' ou 'TASK-001'"
allowed-tools:
  - Read
  - Grep
  - Glob
  - Write
  - Edit
  - Bash
  - Task
  - TodoWrite
  - AskUserQuestion
---

# Skill : Implement

Implementation d'une tache depuis le plan courant. Troisieme etape du workflow :

```
/new-feature → /plan-phase → /implement
```

## Regles critiques

1. **TOUJOURS lire le code existant avant d'ecrire** - comprendre les patterns
2. **SUIVRE les conventions du projet** - composants fonctionnels, Zustand, strict TS
3. **1 tache = 1 concept** - ne pas deborder sur les taches suivantes
4. **VALIDER avant de terminer** - lint + build doivent passer
5. **METTRE A JOUR le plan** - marquer la tache done avec timestamp

## Workflow

### 1. Trouver le plan

Chercher le plan le plus recent :

```
Glob: .claude/plans/*/PLAN.md
```

Prendre le plan le plus recemment modifie. Si plusieurs plans existent et que l'argument contient un slug (ex: `/implement dark-mode/1`), utiliser ce slug.

### 2. Lire la tache cible

Lire le PLAN.md et trouver la tache par :

- Numero simple : `$ARGUMENTS` = `1` → chercher `TASK-001`
- ID complet : `$ARGUMENTS` = `TASK-003` → chercher directement
- Zero-pad : `1` → `001`, `12` → `012`

Extraire :

- Description et scope
- Fichiers a creer/modifier
- Criteres d'acceptation
- Dependances

### 3. Verifier les dependances

Pour chaque tache dans le champ `Depends` :

- Verifier que son status est `done`
- Si une dependance n'est pas done → **STOP**
- Informer l'utilisateur : "TASK-00X depend de TASK-00Y qui n'est pas terminee"
- Suggerer : "Lancez `/implement Y` d'abord"

### 4. Explorer le code existant

Avant d'ecrire du code, comprendre les patterns en place :

```
Read: src/types/models.ts
Read: src/store/index.ts
```

Pour les composants, lire un composant existant similaire :

```
Glob: src/components/**/*.tsx
```

Identifier :

- Les imports standards
- Le pattern de composant (props interface, export default)
- Le pattern de slice (StateCreator, actions)
- Le style Tailwind utilise

### 5. Implementer

Ecrire le code en suivant ces conventions :

**TypeScript** :

- Strict mode, pas de `any`
- Interfaces pour les props (pas de `type` pour les props)
- Types explicites pour les fonctions exportees
- Imports groupes : external > internal > types

**React** :

- Composants fonctionnels uniquement
- Un composant par fichier
- Props typees via interfaces
- `clsx` pour la composition de classes Tailwind
- Hooks React 19 si applicable (use, useActionState, useOptimistic)

**Zustand** :

- Slices pattern avec `StateCreator`
- Actions nommees en camelCase
- Pas de Context pour le state global

**Tailwind CSS 4** :

- Classes utilitaires directement
- `clsx` pour les classes conditionnelles
- Pas de CSS custom sauf exception justifiee

**Code en anglais, UI en francais** :

- Variables, fonctions, types : anglais
- Labels, tooltips, placeholders : francais si l'app est en francais

### 6. Valider

Executer les checks :

```bash
npm run lint
npm run build
npm run test:run
```

Si lint echoue → corriger les erreurs, re-run.
Si build echoue → corriger les erreurs, re-run.
Si tests echouent → corriger les erreurs, re-run.

**Strategie de tests** :

1. D'abord lancer uniquement les tests du fichier/composant modifie : `npx vitest run src/path/to/file.test.tsx`
2. Si ca passe, lancer la suite complete : `npm run test:run`

**Ne JAMAIS marquer la tache done si lint, build ou tests echouent.**

### 7. Mettre a jour le plan

Editer `.claude/plans/{slug}/PLAN.md` :

1. Changer le status de `pending` a `done`
2. Ajouter le timestamp : `**Done** : {YYYY-MM-DDTHH:MM:SSZ}`
3. Ajouter des notes : decisions prises, patterns suivis, deviations
4. Cocher les criteres d'acceptation remplis
5. Mettre a jour le tableau Summary

### 8. Output

Afficher a l'utilisateur :

- Fichiers crees/modifies (avec nombre de lignes)
- Resultat lint : pass/fail
- Resultat build : pass/fail
- Criteres d'acceptation coches
- **Prochaine etape** :
  - S'il reste des taches → `Lancez /implement {N+1}`
  - Si c'etait la derniere → "Toutes les taches sont terminees ! Lancez /commit pour committer."

## Gestion d'erreurs

- **Dependance non done** : Stop, informer, suggerer l'ordre
- **Lint/type errors** : Corriger avant de marquer done
- **Build errors** : Corriger avant de marquer done
- **Spec ambigue** : Demander via AskUserQuestion, documenter la decision dans Notes
- **Fichier inexistant** : Si un fichier a modifier n'existe pas, verifier le plan et adapter
