---
name: new-feature
description: Cadrer une nouvelle feature. Explore le codebase, identifie les zones impactees, produit une spec dans .claude/features/
argument-hint: "<description de la feature>"
allowed-tools:
  - Read
  - Grep
  - Glob
  - Write
  - Bash
  - Task
  - AskUserQuestion
  - TodoWrite
---

# Skill : New Feature

Cadrage et specification d'une nouvelle feature. C'est la premiere etape du workflow :

```
/new-feature → /plan-phase → /implement
```

## Workflow

### 1. Recevoir la demande

La description de la feature est dans `$ARGUMENTS`.

Si `$ARGUMENTS` est vide, demander a l'utilisateur avec AskUserQuestion :

- "Quelle feature voulez-vous ajouter ?"

### 2. Explorer le codebase

Comprendre l'etat actuel du projet avant de cadrer :

```
Glob: src/components/**/*.tsx
Glob: src/store/slices/*.ts
Glob: src/types/*.ts
Read: src/types/models.ts
```

Identifier :

- Les composants existants et leur organisation
- Les slices Zustand et les actions disponibles
- Les types et interfaces definis
- Les hooks custom existants

### 3. Identifier les zones impactees

Pour la feature demandee, determiner :

- **Composants** : quels composants existants modifier, quels nouveaux creer
- **Store** : quels slices toucher, quelles nouvelles actions
- **Types** : quels types modifier ou ajouter dans `models.ts`
- **Styles** : quel impact Tailwind (nouvelles classes, theme)
- **Hooks** : nouveaux hooks necessaires
- **Vues** : impact sur TimelineView, KanbanView, GraphView

### 4. Clarifier le scope

Si la feature est ambigue, poser des questions avec AskUserQuestion :

- Perimetre exact (in scope / out of scope)
- Comportement UX attendu
- Priorite par rapport aux features existantes

### 5. Generer la spec

Creer un slug kebab-case depuis le nom de la feature.
Exemples : "dark mode" → `dark-mode`, "export CSV" → `export-csv`

Ecrire le fichier `.claude/features/{slug}.md` :

```markdown
# Feature : {Nom de la feature}

**Slug** : {slug}
**Date** : {YYYY-MM-DD}
**Status** : draft

## Contexte

{Pourquoi cette feature est necessaire. Quel probleme elle resout.}

## Scope

### In scope

- {Fonctionnalite 1}
- {Fonctionnalite 2}

### Out of scope

- {Ce qui n'est PAS inclus}

## Requirements

- [ ] {Requirement 1 - verifiable}
- [ ] {Requirement 2 - verifiable}

## Zones impactees

| Zone       | Fichiers               | Action           |
| ---------- | ---------------------- | ---------------- |
| Components | `src/components/...`   | Creer / Modifier |
| Store      | `src/store/slices/...` | Creer / Modifier |
| Types      | `src/types/models.ts`  | Modifier         |
| Hooks      | `src/hooks/...`        | Creer            |
| Styles     | `src/index.css`        | Modifier         |

## UX

{Description du comportement utilisateur attendu.
Comment l'utilisateur interagit avec la feature.
Quel feedback visuel.}

## Notes techniques

{Considerations techniques : performance, accessibilite,
compatibilite avec les libs existantes (@xyflow, @dnd-kit, Zustand).}
```

### 6. Output

Afficher a l'utilisateur :

- Resume de la feature
- Zones impactees identifiees
- Chemin du fichier spec cree
- **Prochaine etape** : `Lancez /plan-phase {slug} pour creer le plan d'implementation`
